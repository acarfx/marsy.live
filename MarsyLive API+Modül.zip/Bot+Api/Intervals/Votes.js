const { EmbedBuilder } = require('discord.js');
const Guilds = require('../Databases/Models/Discord/Guilds');
const Votes = require('../Databases/Models/Discord/Votes');
const { genEmbed } = require('../Bot/Structures/genEmbed');

var CronJob = require('cron').CronJob;

let Weekly = new CronJob('00 00 00 * * 1', async function() { 
            let Data = await Guilds.find().populate([
                {path: "rawVotes"}
            ])

            Data = Data.filter(x => x.rawVotes && x.rawVotes > 0);

            if(Data.length > 0) {
                for (let index = 0; index < Data.length; index++) {
                    const guild = Data[index];
                
                    guild.total_votes += guild.rawVotes || 0;
                    guild.point += guild.rawVotes / 2;

                    await guild.save();

                    await Votes.deleteMany({guild: guild._id.toString()});
                    
                    let guild_data = _botclient.guilds.cache.get(guild.guildId);
                    if(guild_data) {
                        let owner = await guild_data.fetchOwner()
                        if(owner) {

                                let embed = new genEmbed()
                                .setDescription(`Merhaba ${owner.user.username}!

Bu hafta sunucumuzda gerçekleşen oylar sıfırlandı! Her hafta düzenli olarak oylarımızı sıfırlayarak herkesin eşit bir başlangıç yapmasını ve rekabetin adil bir şekilde devam etmesini sağlıyoruz.

Bu, sunucumuza olan katkılarınızı her hafta ödüllendirme fırsatı sunar. Yeni bir haftanın başlangıcında, sunucumuza getirdiğiniz desteklerin ve oyların puanlarını kazanmaya başlayabilirsiniz.

Hatırlatma: Her oy, sunucunuzun büyümesine katkıda bulunan bir adımdır. Sizlerle birlikte her geçen gün daha da güçleniyoruz.

Eğer bu konuda herhangi bir sorunuz veya geri bildiriminiz varsa, lütfen bize bildirin.

Keyifli bir hafta geçirmeniz dileğiyle!

Saygılarımla,

Marsy'den
${guild_data.name} Yönetimine`)
.setImage("https://cdn.discordapp.com/attachments/1181382930635948072/1183330233835860008/marsy_live_banner_w_3.png?ex=6587f128&is=65757c28&hm=c7e3fd49536c9de839f249821195b1b6aff2decaeb30133da32f5fbbfe03ecb3&")
.setFooter({
    text: `Şu ana kadar aldığınız toplam oylar: ${guild.total_votes}, toplam puan: ${guild.point}.`
})



                        owner.send({embeds: [ embed ]}).catch(err => {

                        })


                        }
                    }


                }
            }
            

}, null, true, 'Europe/Istanbul');

Weekly.start();
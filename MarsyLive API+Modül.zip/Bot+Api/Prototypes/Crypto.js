const crypto = require('crypto');


/**
 * Şifreleme işlemi yapmakta.
 * @param {String} text 
 * @returns 
 */
function encrypt(text){
    const cipher = crypto.createCipher('aes192', 'a_secret_key');
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}
  
/**
 * Şifrelenmiş şifreyi çözme
 * @param {String} encryptedText 
 * @returns 
 */

function decrypt(encryptedText){
    const decipher = crypto.createDecipher('aes192', 'a_secret_key');
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

module.exports = {
    encrypt,
    decrypt
}
const splitText = global.splitText = function(text, limit = 1950) {
    const chunks = [];
    let currentIndex = 0;
    while (currentIndex < text.length) {
        chunks.push(text.substring(currentIndex, currentIndex + limit));
        currentIndex += limit;
    }
    return chunks;
}

const boldText = global.boldText = function(text) {
    return String(text).replace(/([0-9])/g, d => {
        return {
                "0": "𝟎",
                "1": "𝟏",
                "2": "𝟐",
                "3": "𝟑",
                "4": "𝟒",
                "5": "𝟓",
                "6": "𝟔",
                "7": "𝟕",
                "8": "𝟖",
                "9": "𝟗"
               
        }[d];
    });
}
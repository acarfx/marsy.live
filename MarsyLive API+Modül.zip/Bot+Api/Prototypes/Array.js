Array.prototype.last = function () {
    return this[this.length - 1];
};

Array.prototype.listed = function () {
    return this.length > 1 ? this.slice(0, -1).map((x) => `${x}`).join(", ") + " ve " + this.map((x) => `${x}`).slice(-1) : this.map((x) => `${x}`).join("");
};

Array.prototype.chunk = function(chunk_size) {
    let myArray = Array.from(this);
    let tempArray = [];
    for (let index = 0; index < myArray.length; index += chunk_size) {
      let chunk = myArray.slice(index, index + chunk_size);
      tempArray.push(chunk);
    }
    return tempArray;
  };
  
Array.prototype.shuffle = function () {
    let i = this.length;
    while (i) {
      let j = Math.floor(Math.random() * i);
      let t = this[--i];
      this[i] = this[j];
      this[j] = t;
    }
    return this;
};

Array.prototype.random = function() {
    const randomIndex = Math.floor(Math.random() * this.length);
    return this[randomIndex];
};

const {PermissionsBitFlags, Client, ChannelFlags, ChannelFlagsBitField, ChannelType, PermissionsBitField, Message, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, ButtonStyle } = require('discord.js');
const { Command } = require("../../../Structures/Command");
const util = require('util');
const { genEmbed } = require('../../../Structures/genEmbed');
const { createTranscript } = require("discord-html-transcripts");

const mongoose = require('mongoose');   
const Ticket = require('../../../../Databases/Models/Other/Tickets');


var parentCategory = "1187215395535462400";
var LogChannelId = "1187215433967870052";
var KapatacakRol = "1181394336236187730";
let Departmanlar = [
    {label: "Genel Sorular", description: "Cevabını bilmediğiniz soruları burada sorabilirsiniz.", emoji: {id: "939147205867077662"}, value: "d_chat", mentions: [
        "1181394336236187730"
    ]},
    {label: "Sunucu Onaylatma", description: "Marsy'de sunucu onaylatma işlemleri için burayı seçiniz.", emoji: {id: "939147205867077662"}, value: "d_yetkili", mentions: [
        "1181394336236187730"
        
    ]},
    {label: "Kurulum Sorunları", description: "Marsy kurulurken herhangi bir sorun ile karşılaştıysanız bunu seçiniz.", emoji: {id: "939147205867077662"}, value: "d_sesli", mentions: [
       "1181394336236187730"
   ]},
    {label: "Diğer Sorunlar", description: "Bilmediğiniz bir sorunu burada sorabilir ve sonuçlandırabilirsiniz.", emoji: {id: "939147205867077662"}, value: "d_diger", mentions: [
       "1181394336236187730"
    ]},
    {label: "İstek ve Öneri", description: "İstek ve önerileriniz bizim için çok önemli bildirmek için burayı kullanabilirsiniz.", emoji: {id: "939147205867077662"}, value: "d_istek", mentions: [
        "1181394336236187730"
     ]}
]

class command extends Command {
    constructor(client) {
        super(client, {
            name: "destek-kur",
            description: "Bu bir geliştirici komutudur.",
            usage: "Kullanımı çok basittir bence denemelisin.",
            category: "Developer",
            aliases: ["destekkur"],
            enabled: true,
            ignoreUse: ["1178732548571017306"],
            cooldown: 3500,
            permissions: [],
            devOnly: true,
            logged: false,
        });
    }
    /**
     * 
     * @param {Client} client 
     */
    onLoad(client) { 
            /**
             * @param {import('discord.js').Interaction} i
             */
        client.on('interactionCreate', async (i) => {
            let guild = client.guilds.cache.get(i.guild.id)
            if(!guild) return;

            let uye = guild.members.cache.get(i.user.id)
            if(!uye) return;
            if(!i.customId) return;
            if(!i.customId.includes("d_")) return;

            if(i.customId.includes("d_talepal")) {
                let ticket_channel = i.channel
                let ticket_veri = await Ticket.findOne({closed: false, channel: ticket_channel.id})
                let find_departman = Departmanlar.find(x => x.label == ticket_veri.departman)
                
                if(find_departman) {
                    if(!find_departman.mentions.some(r => uye.roles.cache.has(r)) && !uye.permissions.has(PermissionsBitFlags.Administrator)) return İ.reply({
                        content: `Bu destek talebini alabilmek için ${etiketle(guild, find_departman.value)} rol(ler) ihtiyacın var.`,
                        ephemeral: true
                    });
                    let Row = new ActionRowBuilder()
                        .setComponents(
                            new ButtonBuilder()
                                .setCustomId("d_talepal" + ticket_veri.id)
                                .setLabel(`🖐️・ Talep Alınamaz`)
                                .setStyle("Secondary")
                                .setDisabled(true),
                            new ButtonBuilder()
                                .setCustomId("d_talepson" + ticket_veri.id)
                                .setLabel(`🗑️・ Talep Sonlandır`)
                                .setStyle("Secondary")
                    ) 
                    let embed = new genEmbed()
                    .setColor("Green")
                    .setDescription(`<@${i.channel.topic}>, Sizinle aşağıda yazan yetkili en kısa sürede ilgilenecektir.
Sizinle ilgilecek olan yetkili: <@${uye.id}>
Destek talebini alma tarihi: <t:${new String(Date.now()).slice(0, 10)}:R> (<t:${new String(Date.now()).slice(0, 10)}:F>)`);
            await Ticket.updateOne({id: ticket_veri.id}, {$set: { claimid: uye.id }})
            i.update({embeds: [embed], components: [Row], ephemeral: true})
                }
            }

            if(i.customId.includes("d_talepson")) {
                let ticket_channel = i.channel
                let ticket_veri = await Ticket.findOne({closed: false, channel: ticket_channel.id})

                let find_departman = Departmanlar.find(x => x.label == ticket_veri.departman)
                if(find_departman) {
                    if(ticket_veri && ticket_veri.claimid) {
                        let kitleyen = guild.members.cache.get(ticket_veri.claimid)
                        if(kitleyen && uye.id != kitleyen.id && !uye.permissions.has(8) && !uye.roles.cache.has(KapatacakRol))  return i.reply({content: `Bu talebi sadece ${kitleyen} yetkilisi kapatabilir. Eğer ki kapatmak istiyorsanız <@&${KapatacakRol}> rolü ile iletişime geçiniz.`, ephemeral: true})
                    }

                    let embed = new genEmbed()
                    .setColor("Red")
                    .setDescription(`<@${ticket_channel.topic}>, ${uye.id == ticket_channel.topic ? `destek talebiniz başarıyla kapatıldı 5 saniye sonra otomatik olarak silinecektir.` : `Destek talebiniz ${uye} yetkilisi tarafından sonlandırıldı.
Güvenlik nedeniyle kayıtları tutularak kanalınız 5 saniye içerisinde silinecektir.`}`);
                let endEmbed = new genEmbed()
                    .setColor("Fuchsia")
                    .setDescription(`Aşağıda bulunan dosya ile destek talebini detaylı bir şekilde inceleyebilirsiniz.

**Destek Talebi Bilgileri**
\`Destek Talebi Numarası      :\` #${ticket_veri.id}
\`Destek Talebi Konusu        :\` ${find_departman.label}
\`Destek Talebini Alan        :\` ${ticket_veri.claimid ? `<@${ticket_veri.claimid}>` : `Yok!`}
\`Destek Talebini Oluşturan   :\` <@${ticket_channel.topic}>
\`Destek Talebini Sonlandıran :\` ${uye.id == ticket_channel.topic ? "Kendisi" : uye} (\`${uye.user.tag}\`)

**NOT**
Mesaja ek olarak verilen "transcript-${ticket_channel.name}.html" isimli dosyayı indirerek destek talebinin kanal kayıtlarını inceleyebilirsiniz. Örnek resim aşağıdadır onu kontrol edebilirsiniz.
`).setImage("https://cdn.discordapp.com/attachments/1028298599865532506/1106392556037754891/image.png");
                await Ticket.updateOne({id: ticket_veri.id}, {$set: { closed: true }})
                const attachment = await createTranscript(ticket_channel, {
                    limit: -1,
                    returnBuffer: true,
                    fileName: `transcript-${ticket_channel.name}.html`,
                })

                let log_channel = guild.channels.cache.get(LogChannelId)
                if(log_channel) log_channel.send({
                    content: `${find_departman.label} - <@${ticket_channel.topic}>`,
                    embeds: [endEmbed],
                    files: [attachment]
                })
                i.update({embeds: [embed],content: null, components: [], ephemeral: true})
                setTimeout(() => ticket_channel.delete().catch(err => {}), 5000)
                }
            }

            if(i.customId.includes("d_evet_")) {
                let departman = i.customId.replace("d_evet_", "")
                let find_departman = Departmanlar.find(x => departman == x.value)
                if(find_departman) {
                    let id = create_id();
                    let perm = [
                        { id: guild.roles.everyone.id, 
                            deny: [PermissionsBitField.Flags.ViewChannel, ], 
                            allow: [
                                PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles,PermissionsBitField.Flags.ReadMessageHistory
                            ] },
                        { id: uye.user.id, allow: [PermissionsBitField.Flags.ViewChannel] }
                    ];
                    let mentions_roles = find_departman.mentions || []
                    for (let index = 0; index < mentions_roles.length; index++) {
                        let rol = guild.roles.cache.get(mentions_roles[index])
                        if(rol) perm.push({
                            id: rol,
                            allow: [
                                PermissionsBitField.Flags.ViewChannel,
                                

                                
                            ]
                        })
                    }

                    await guild.channels.create({
                        name: `destek-${id}`,
                        type: ChannelType.GuildText,
                        parent: parentCategory,
                        topic: uye.user.id,
                        permissionOverwrites: perm,
                    }).then(async (kanal) => {
                        await Ticket.updateOne({id: id}, {$set: { memberid: uye.id, channel: kanal.id, departman: find_departman.label, date: Date.now() }}, {upsert: true})
                        let Embed = new genEmbed()
                        .setColor("Orange")
                        .setDescription(`${uye.user.tag}, bir yetkili en kısa sürede size yardımcı olacaktır.
Sizinle ilgilecek olan yetkili: **Şuanda hiçbir yetkili talebi almadı.**`);
                        i.update({content: `Başarıyla #${id} numaralı destek talebiniz oluşturuldu. Kanala gitmek için <#${kanal.id}> tıklayınız. `, embeds: [], components: [], ephemeral: true})
                        let Row = new ActionRowBuilder()
                        .setComponents(
                            new ButtonBuilder()
                                .setCustomId("d_talepal" + id)
                                .setLabel(`🖐️・ Talep Al`)
                                .setStyle("Secondary"),
                            new ButtonBuilder()
                                .setCustomId("d_talepson" + id)
                                .setLabel(`🗑️・ Talep Sonlandır`)
                                .setStyle("Secondary")
                        )  
                        kanal.send({
embeds: [Embed],
components: [Row],
content: `Merhaba ${uye},
Başarıyla #${id} numaralı **${find_departman.label}** kategorisindeki destek talebiniz oluşturuldu. Sorununuzu kısa bir cümle ile özetleyin, yetkililerimiz en kısa süre içerisinde sizinle ilgilenecektir!

İlgilenmesi gereken rol(ler): ${etiketle(guild, departman)}`})
                    })

                    return;
                } 
                i.update({content: `İşlem sırasında bir hata oluştu. Lütfen sunucu sahibi ile iletişime geçin!`, embeds: [], components: []})
            }

            // Destek Talebi İptal Etme Yeri
            if(i.customId == "d_hayir") {
                let Row = new ActionRowBuilder().setComponents(
                    new ButtonBuilder()
                        .setCustomId("d_evet")
                        .setLabel("Evet")
                        .setEmoji("1095460727466233967")
                        .setStyle("Secondary")
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId("d_hayir")
                        .setLabel("Hayır")
                        .setEmoji("947548354756370472")
                        .setStyle("Success")
                        .setDisabled(true),
                )
                i.update({embeds: [
                    new genEmbed().setDescription(`Destek talebi açmaktan vaz geçtiniz. Tekrardan destek talebi açmak için bulunduğunuz menüden sorununuzu belirterek açabilirsiniz.`)
                ], components: [Row]})
            }

            // Destek Talebi Oluşturma Yeri
            let find_departman = Departmanlar.find(x => i.values == x.value)
            if(find_departman) {
                let Get_Tickets = await Ticket.findOne({closed: false, memberid: uye.user.id})
                if(Get_Tickets) return i.reply({content: `Destek talepleriniz arasında şuan aktif <#${Get_Tickets.channel}> kanalı görünüyor. Eğer ki kanal görünmüyor ise bir yöneticiye başvurun.`, ephemeral: true});
                
                let Row = new ActionRowBuilder().setComponents(
                    new ButtonBuilder()
                        .setCustomId(`d_evet_${i.values}`)
                        .setLabel("Evet")
                        .setEmoji("1095460727466233967")
                        .setStyle("Secondary"),
                    new ButtonBuilder()
                        .setCustomId("d_hayir")
                        .setLabel("Hayır")
                        .setEmoji("947548354756370472")
                        .setStyle("Secondary")
                )

                let Embed = new genEmbed()
                .setColor("Orange")
                .setDescription(`Merhaba ${uye.user.tag}!

${find_departman.label} kategorisinde bir destek talebi oluşturmak istediğinize emin misiniz? Bu destek sistemi amacına uygun kullanılmadığında ceza-i işlem uygulanacaktır!`)

                i.reply({embeds: [Embed], components: [Row], ephemeral: true})
            } // Bitiş Açma :D
        })
    }
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {Array} args 
     * @param {genEmbed} genEmbed 
     * @returns 
     */
    async onRequest (client, message, args, genEmbed) {
      
    let Embed = new genEmbed().setColor("#00130c")
    let Row = new ActionRowBuilder()
    .setComponents(
        new StringSelectMenuBuilder()
        .setPlaceholder("Sorununuzu menü içerisinde seçebilirsiniz.")
        .setOptions(Departmanlar)
        .setCustomId("d_departman")
    )
    message.channel.send({components: [Row], embeds: [Embed.setDescription(`Destek sistemine hoş geldiniz. Aşağıdaki seçeneklerden birini seçerek destek talebi oluşturabilirsiniz.\n\nDestek taleplerini gereksiz kullanmak sunucudan uzaklaştırılmanıza sebep olabilir.`)]})

    }
}

function cleanString(text) {
    if (typeof (text) === "string") return text.replace(/`/g, "`" + String.fromCharCode(8203)).replace(/@/g, "@" + String.fromCharCode(8203));
    else return text;
}

module.exports = command

function create_id(length = 9999999, plus = 100000) {
    return Math.floor(Math.random() * 9999999) + 100000;
}

function etiketle(guild, departman) {
    let find_departman = Departmanlar.find(x => x.value == departman)
    if(!find_departman) return false;
    let rolümdenaşağıkasımpaşa = []
    for (let index = 0; index < find_departman.mentions.length; index++) {
        let role = guild.roles.cache.get(find_departman.mentions[index])
        if(role) rolümdenaşağıkasımpaşa.push(`<@&${role.id}>`)
    }
    return rolümdenaşağıkasımpaşa.listed()
}

const { PermissionsBitField, Client, Message } = require('discord.js');
const { Command } = require("../../../Structures/Command");
const util = require('util');
const { genEmbed } = require('../../../Structures/genEmbed');

class command extends Command {
    constructor(client) {
        super(client, {
            name: "eval",
            description: "Bu bir geliştirici komutudur.",
            usage: "Kullanımı çok basittir bence denemelisin.",
            category: "Developer",
            aliases: ["ev"],
            enabled: true,
            ignoreUse: ["1178732548571017306"],
            cooldown: 3500,
            permissions: [],
            devOnly: true,
            logged: false,
        });
    }
    /**
     * 
     * @param {Client} client 
     */
    onLoad(client) { 


    }
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {Array} args 
     * @param {genEmbed} genEmbed 
     * @returns 
     */
    async onRequest (client, message, args, genEmbed) {
        if (!args[0]) return message.reply({embeds: [new genEmbed().setDescription(`Herhangi bir kod belirtilmedi.`)]}).then(msg => {
            setTimeout(() => {
                msg.delete().catch(err => {})
            }, 5000)
        }); 
        
        try {
            const code = message.content.split(' ').slice(1).join(' ');
            let evaled = cleanString(await eval(code));
            if (typeof evaled !== "string") evaled = util.inspect(evaled).replace(client.token, "Yasaklı komut")
            const parts = splitText(evaled, 1949);

            for (const part of parts) {
                await message.channel.send({content: `\`\`\`js
${part}
\`\`\``});
            }
        } catch (err) {
            message.channel.send(`\`EX-ERR\` \`\`\`xl\n${cleanString(err)}\n\`\`\``)
        }

    }
}

function cleanString(text) {
    if (typeof (text) === "string") return text.replace(/`/g, "`" + String.fromCharCode(8203)).replace(/@/g, "@" + String.fromCharCode(8203));
    else return text;
}

module.exports = command
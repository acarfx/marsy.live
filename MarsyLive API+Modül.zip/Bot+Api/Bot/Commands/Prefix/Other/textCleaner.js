
const { Command } = require("../../../Structures/Command");
class command extends Command {
    
    constructor(client) {
        super(client, {
            name: "temizle",
            description: "Bu komut kullanıldığı kanalın mesajlarını temizler.",
            usage: "temizle <1-100>",
            category: "Misc",
            aliases: ["clear","sil"],
            enabled: true,
            cooldown: 10000,
            ignoreUse: ["1178732548571017306"],
            permissions: [],
            devOnly: false,
            logged: true,
        });
    }
    
    onLoad(client) { 

        
    }

    async onRequest (client, message, args, genEmbed) {
        if(!message.member.checkPermissions([])) return;


        if(!args[0]) return message.reply({content: `Silebileceğim mesaj sayısını bana belirtin.`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));
        if(isNaN(args[0])) return message.reply({content: `Belirtilen miktar harf olamaz. Lütfen geçerli miktar için bir rakam giriniz. (En az: 1 / En fazla: 100)`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));
        let Count = args[0] || 1
        
        if(Count < 1) return message.reply({content: `Belirtilen miktar sıfırın altında olduğu için işleminize devam edilemiyor.`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));
        if(Count > 100) return message.reply({content: `Belirtilen miktar yüzün üstünde olduğu için işleminize devam edilemiyor.`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));

        Count++
        
        const fetchMessage = await message.channel.messages.fetch({ limit: Count > 100 ? 100 : Count });
        let messages = fetchMessage.filter(x => x.createdTimestamp < (Date.now()))
        if(messages) {
            
            let msg = await message.channel.send({content: `Mesaj temizleme isteği işleme alındı. Lütfen bekleyin!`})
            await message.channel.bulkDelete(messages)
            .then(async (x) => {
               
                setTimeout(() => message.delete().catch(err => {}), 7500);
                msg.edit({content: `Başarıyla ${message.channel} kanalında toplamda **${x.size}** mesaj kaldırıldı.`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));
            })
            .catch(err => {
                message.react(message.guild.findEmoji(emojiler.Deny)).catch(err => {});
                setTimeout(() => message.delete().catch(err => {}), 7500);
                console.log(err)
                msg.edit({content: `Silinebilecek bir mesaj bulunamadı.`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));
            })
           
        } else {
            message.react(message.guild.findEmoji(emojiler.Deny)).catch(err => {});
            setTimeout(() => message.delete().catch(err => {}), 7500);
            msg.edit({content: `Mesaj temizleme işlemi tamamlanamadı. Lütfen sunucu sahibine veya geliştiriciye bildirin.`}).then(x => setTimeout(() => x.delete().catch(err => {}),7500));
        }
    }
}


module.exports = command
const { SlashCommandBuilder, Interaction, Client, ActionRowBuilder, ButtonBuilder,
InteractionCollector, ComponentType,    
StringSelectMenuBuilder, ModalBuilder, TextInputStyle, TextInputBuilder,ButtonStyle, Collection, PermissionFlagsBits } = require("discord.js");
const { genEmbed } = require("../../../Structures/genEmbed");
const Global = require("../../../../Settings/Global");
const { ACAR } = require("../../../Structures/Client");
const GuildSettings = require("../../../../Databases/Models/Discord/Settings/Guilds");
const Guilds = require("../../../../Databases/Models/Discord/Guilds");
const reactedUsers = new Collection();

module.exports = {
    data: new SlashCommandBuilder()
    .setName('puan')
    .setDescription('Sunucu sahibiyseniz sunucunuzun puanını ve kazancınızı görüntülersiniz.'),
    /**
     * @param {Interaction} interaction
     * @param {ACAR} client
     * @param {Object} settings
     */

    async onRequest(interaction, client, settings) {
        let member = interaction.guild.members.cache.get(interaction.user.id);
        if(member.id != member.guild.ownerId) return await interaction.reply({content: `Bunu sadece sunucu sahibi kullanabilir.`, ephemeral: true});

        const embed = new genEmbed().setFooter({text: `discord.gg/marsy`})
        if(!interaction.guildId) return await interaction.reply({embeds: [
            embed.setDescription(`Bu komutu kullanabilmeniz için sahibi olduğunuz bir sunucu üzerinde denemelisiniz.`)
            
        ], ephemeral: true})

        let setting = await client.fetchSettings(interaction.guildId)
        if(!setting) return await interaction.reply({embeds: [
            embed
            .setDescription(`Güncellemeleriniz araştırılırken herhangi bir problem oluştu. Lütfen bot sahibine bildiriniz!`)
        ], ephemeral: true});

    
        let guild_data = await Guilds.findOne({guildId: interaction.guild.id});
        if(!guild_data) return await interaction.reply({embeds: [
            embed
            .setDescription(`Güncellemeleriniz araştırılırken herhangi bir problem oluştu. Lütfen bot sahibine bildiriniz!`)
        ], ephemeral: true});



        await interaction.reply({
            content: `Sunucunuzun topladığı toplam oyunuz **${guild_data.total_votes || 0}**, sizin sunucu puanınız ise **${guild_data.point || 0}** ve kazancınız **daha belirtilmedi**`,
            ephemeral: true
        })




    }
}


function emojiGöster(name) {
    return client.emojis.cache.find(x => x.name == name)
}

function progressBar(value, maxValue, size, veri) {
    let renk = {
        başlamaBar: "acar_baslangicbar",
        doluBar: "acar_dolubar",
        doluBitişBar: "acar_dolubitisbar",
        boşBitişBar:"acar_bosbitis",
        boşBar: "acar_bosbar",
        başlangıçBar: "acar_bosbaslama"
    };

    if(veri < 0) value = 0
    const progress = Math.round(size * ((value / maxValue) > 1 ? 1 : (value / maxValue)));
    const emptyProgress = size - progress > 0 ? size - progress : 0;
    let progressStart;
    if(veri <= 0) progressStart = `${emojiGöster(renk.başlangıçBar)}`
    if(veri > 0) progressStart = `${emojiGöster(renk.başlamaBar ? renk.başlamaBar : renk.başlamaBar)}`
    const progressText = `${emojiGöster(renk.doluBar)}`.repeat(progress);
    const emptyProgressText = `${emojiGöster(renk.boşBar)}`.repeat(emptyProgress)
    const bar = progressStart + progressText + emptyProgressText + `${emptyProgress == 0 ? `${emojiGöster(renk.doluBitişBar)}` : `${emojiGöster(renk.boşBitişBar)}`}`;
    return bar;
};

/**
 * 
                    
 */
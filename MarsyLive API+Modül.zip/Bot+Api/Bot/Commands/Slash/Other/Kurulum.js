const { SlashCommandBuilder, Interaction, Client, ActionRowBuilder, ButtonBuilder,
InteractionCollector, ComponentType,    
StringSelectMenuBuilder, ModalBuilder, TextInputStyle, TextInputBuilder,ButtonStyle, Collection, PermissionFlagsBits } = require("discord.js");
const { genEmbed } = require("../../../Structures/genEmbed");
const Global = require("../../../../Settings/Global");
const { ACAR } = require("../../../Structures/Client");
const GuildSettings = require("../../../../Databases/Models/Discord/Settings/Guilds");
const Guilds = require("../../../../Databases/Models/Discord/Guilds");
const reactedUsers = new Collection();

module.exports = {
    data: new SlashCommandBuilder()
    .setName('kurulum')
    .setDescription('Sunucu sıralama sayfasında göstermek için yapmanız gereken kurulum komutu.'),
    /**
     * @param {Interaction} interaction
     * @param {ACAR} client
     * @param {Object} settings
     */

    async onRequest(interaction, client, settings) {
        let member = interaction.guild.members.cache.get(interaction.user.id);
        if(!member.permissions.has(PermissionFlagsBits.Administrator)) return await interaction.reply({content: `Bunu sadece sunucu sahibi ve sunucu yöneticileri kullanabilir.`});

        const embed = new genEmbed().setFooter({text: `discord.gg/marsy`})
        if(!interaction.guildId) return await interaction.reply({embeds: [
            embed.setDescription(`Bu komutu kullanabilmeniz için sahibi olduğunuz bir sunucu üzerinde denemelisiniz.`)
            
        ], ephemeral: true})

        let setting = await client.fetchSettings(interaction.guildId)
        if(!setting) return await interaction.reply({embeds: [
            embed
            .setDescription(`Güncellemeleriniz araştırılırken herhangi bir problem oluştu. Lütfen bot sahibine bildiriniz!`)
        ], ephemeral: true});

    
        let data = await client.fetchSettings(interaction.guild.id);
        let guild_data = await Guilds.findOne({guildId: interaction.guild.id});
        if(data && guild_data) {
     
            let row = new ActionRowBuilder()
            .setComponents(
                new ButtonBuilder()
                .setCustomId("onay_verildi")
                .setLabel("Onaylıyorum!")
                .setEmoji("947548332815945778")
                .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                .setCustomId("onay_verilmedi")
                .setEmoji("947548354756370472")
                .setLabel("Onaylamıyorum!")
                .setStyle(ButtonStyle.Secondary)
            )


            let rowiki = new ActionRowBuilder()
            .setComponents(
                new ButtonBuilder()
                .setCustomId("oyyorumpanel")
                .setLabel("Oy & Yorum Paneli")
                .setEmoji("1183387240802558022")
                .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                .setCustomId("siralamaayar")
                .setLabel(guild_data.isRanking ? "Sıralamada Gizle" : "Sıralamada Göster")
                .setEmoji(guild_data.isRanking ? `1183493057111412828` : `1183493173046169630`)
                .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                .setCustomId("onay_verildi")
                .setEmoji("1183493058843660420")
                .setLabel("Sunucu Bilgilerini Düzenle")
                .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                .setURL(`https://marsy.live/?_ref=discord_setup&g=${interaction.guild.id}&u=${interaction.user.id}`)
                .setStyle(ButtonStyle.Link)
                .setEmoji("1183353237529690142")
                .setLabel("Marsy.Live"),
            )


            
            let embed = new genEmbed();
            

      

            if(data.setup && data.setup.finish) {
                let total_user = interaction.guild.memberCount;
                let total_voice = interaction.guild.members.cache.filter(x => !x.user.bot && x.voice && x.voice.channel).size
                interaction.reply({embeds: [
                    embed.setDescription(`Görünüşe göre sunucunuzun ayarlarını yapmış bulunmaktasınız.

Aşağı da sunucunuza ait gereksinim belirtileri bulunmaktadır
Bu gereksinimleri tamamlayarak hem sunucu sıralaması hemde sunucu listesine sunucunuzu çıkartabilirsiniz.

**Gereksinim Bilgileri:**
> Eğer ki 100 üye gereksinimi tamamladıysanız "Sunucular" sayfasına sunucunuz gelecektir.
> Eğer ki 15 ses gereksinimi tamamladıysanız sıralama sayfasına sunucunuz gelecektir.

`)
.addFields([
    {name: `100 Üyeye Sahip Ol!`, value: `
${total_user >= 100 ? emojiGöster("marsy_okey") : emojiGöster("marsy_users")} ${progressBar(total_user, 100, 6, total_user)} \`${total_user < 100 ? `${total_user} / 100` : `Tamamlandı!`}\``},
{name: `15 Sese Sahip Ol!`, value: `
${total_voice >= 15 ? emojiGöster("marsy_okey") : emojiGöster("marsy_mic")} ${progressBar(total_voice, 15, 6, total_voice)} \`${total_voice < 15 ? `${total_voice} / 15` : `Tamamlandı!`}\``}
])
.setImage("https://cdn.discordapp.com/attachments/1181382930635948072/1183330233835860008/marsy_live_banner_w_3.png?ex=6587f128&is=65757c28&hm=c7e3fd49536c9de839f249821195b1b6aff2decaeb30133da32f5fbbfe03ecb3&")
                ], components: [rowiki], ephemeral: true})
            } else {
               interaction.reply({embeds: [embed
                .setDescription(`Merhaba ${member},
                
Marsy gezegenine katılabilmen ve sıralamada yer alabilmen için aşağıdaki kurallara ve şartlara uymalısın.

**Katılım şartları ve kuralları:**
> Sunucuya katılabilmek için en az 100 üyeye ihtiyacınız vardır.
> Sunucu ses sıralamasına katılabilmeniz içinde 15 sese ihtiyacınız vardır.
> Sunucuda token ile bastırılmış ses veya üye sayısı yasaktır.
> Küfürlü sunucu ismi ve açıklamalar kullanmak yasaktır.
> Kişisel bilgi paylaşımı, kötü içerikler ve sunucu isminde veya açıklamalarında özel bilgiler yer edinmesi yasaktır.
> Sunucu resminde müstehcen, ifşa, vesikalık ve kişisel bilgi içeren fotoğrafları paylaşmak yasaktır.
> Sunucu içerisinde oy ve yorum paneli kurulduktan sonra ordaki tüm sorumluluklar sunucu sahibinindir.`)
                .setFooter({text: `Lütfen aşağıdaki "Onaylıyorum!" butonuna tıklayarak kuralları kabul ettiğinizi belirtin. Eğer ki kabul sonrası yukarıda yazan kural dışı işlem olursa sunucunuz tamamiyle websitemizden uzaklaştırılacaktır.`})
                .setImage("https://cdn.discordapp.com/attachments/1181382930635948072/1183330233835860008/marsy_live_banner_w_3.png?ex=6587f128&is=65757c28&hm=c7e3fd49536c9de839f249821195b1b6aff2decaeb30133da32f5fbbfe03ecb3&")
            ], components: [row], ephemeral: true})
            }

            const filter = (i) => {
                if (i.user.id === member.id && !reactedUsers.has(i.user.id)) {
                    reactedUsers.set(i.user.id, true);
                    return true;
                }
                return false;
            };

          
            const collector = interaction.channel.createMessageComponentCollector({filter, time: 60000});            

            /**
             * @param {Interaction} i
             */
            collector.on('end', async (i, a) => {
                if(a == "time") {
                    reactedUsers.delete(member.id)
                }
            })
            collector.on('collect', async (i) => {
                    if(i.member.id != member.id) return await i.reply({content: `Bu işleme ${member} devam edebilir. Lütfen sizin olmayan işlere dokunmayın!`, ephemeral: true});
                

                    if(i.customId == "oyyorumpanel") {
                        reactedUsers.delete(i.member.id)
                        await i.update({embeds: [], content: `${client.getEmoji("marsy_accept")} Başarıyla oy ve yorum paneli kuruluyor. Tekrar kurmak için bu işlemi tekrarlayın! `,  components: []})
                        let msg = await interaction.channel.send({content: `Oy & Yorum paneli kurulurken lütfen bekleyin! ${client.getEmoji("marsy_time")}`});
                        data.settings.serverListChannel = undefined;
                        data.settings.serverListId = undefined;
                        await client.fetch_oy(msg);
                        await data.save().catch(err => {});

                    }


                    if(i.customId == "siralamaayar") {
                        
                        if(guild_data.isRanking) {
                            guild_data.isRanking = false
                        } else {
                            guild_data.isRanking = true
                        }
                       
                        await guild_data.save();

                        rowiki.components[1].setLabel(guild_data.isRanking ? "Sıralamada Gizle" : "Sıralamada Göster");
                        rowiki.components[1].setEmoji(guild_data.isRanking ? `1183493057111412828` : `1183493173046169630`);
                        
                        await i.update({components: [rowiki]});
                        reactedUsers.delete(member.id)

                    }

                    if(i.customId == "onay_verildi") {
                        row.components[0].setDisabled(true);
                        row.components[1].setDisabled(true);
                        const Modal = new ModalBuilder()
                        .setCustomId(`sunucu_onay_sayfasi`)
                        .setTitle(`${i.guild.name}`)

                        .setComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                .setCustomId(`description`)
                                .setLabel(`Sunucunuz İçin Açıklama`)
                                .setPlaceholder(`Örn: Marsy'de yolda yürüyerek arkadaşlık edinebilirsiniz.`)
                                .setMinLength(75)
                                .setMaxLength(720)
                                .setRequired(false)
                                .setStyle(TextInputStyle.Paragraph)
                            ),
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                .setCustomId(`purpose`)
                                .setLabel(`Sunucunuzun Amacını Açıklayın`)
                                .setPlaceholder(`Örn: Marsy'i arkadaşlık kurulsun amacıyla açtık ve burda üyelere etkinlikler tasarlamak istiyoruz.`)
                                .setRequired(true)
                                .setMinLength(50)
                                .setMaxLength(512)
                                .setStyle(TextInputStyle.Paragraph)
                            )
                        );

                        await i.showModal(Modal);
                        reactedUsers.delete(member.id)
                    }

                    if(i.customId == "onay_verilmedi") {
                        reactedUsers.delete(member.id)
                        row.components[0].setDisabled(true);
                        row.components[1].setDisabled(true);
                        await i.update({embeds: [], content: `Marsy kabul etmediğiniz için çok üzgün. En kısa zamanda sizi aramızda görmek isteriz!`,  components: [row]})
                    }
                    
            });


        } else {
            await interaction.reply({content: `${client.getEmoji("marsy_info")} Sunucunuza botu daha yeni çağırmışsınız! Marsy Daha Burayı Keşfedemedi :(`, ephemeral: true});
        }

    }
}


function emojiGöster(name) {
    return client.emojis.cache.find(x => x.name == name)
}

function progressBar(value, maxValue, size, veri) {
    let renk = {
        başlamaBar: "acar_baslangicbar",
        doluBar: "acar_dolubar",
        doluBitişBar: "acar_dolubitisbar",
        boşBitişBar:"acar_bosbitis",
        boşBar: "acar_bosbar",
        başlangıçBar: "acar_bosbaslama"
    };

    if(veri < 0) value = 0
    const progress = Math.round(size * ((value / maxValue) > 1 ? 1 : (value / maxValue)));
    const emptyProgress = size - progress > 0 ? size - progress : 0;
    let progressStart;
    if(veri <= 0) progressStart = `${emojiGöster(renk.başlangıçBar)}`
    if(veri > 0) progressStart = `${emojiGöster(renk.başlamaBar ? renk.başlamaBar : renk.başlamaBar)}`
    const progressText = `${emojiGöster(renk.doluBar)}`.repeat(progress);
    const emptyProgressText = `${emojiGöster(renk.boşBar)}`.repeat(emptyProgress)
    const bar = progressStart + progressText + emptyProgressText + `${emptyProgress == 0 ? `${emojiGöster(renk.doluBitişBar)}` : `${emojiGöster(renk.boşBitişBar)}`}`;
    return bar;
};

/**
 * 
                    
 */
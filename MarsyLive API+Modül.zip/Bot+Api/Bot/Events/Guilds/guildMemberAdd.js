const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, Guild, AuditLogEvent, GuildMember } = require('discord.js');
const { Event } = require('../../Structures/Event');
const { genEmbed } = require('../../Structures/genEmbed');
const Guilds = require('../../../Databases/Models/Discord/Settings/Guilds');
const { ACAR } = require('../../Structures/Client');

class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.GuildMemberAdd;
    }    
    /**
     * @param {ACAR} client
     * @param {GuildMember} member 
     */
    async onLoad(member) {
   

       

      
    }   
}    


module.exports = event;
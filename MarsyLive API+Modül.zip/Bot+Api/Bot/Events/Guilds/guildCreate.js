const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, Guild, AuditLogEvent, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const { Event } = require('../../Structures/Event');
const { genEmbed } = require('../../Structures/genEmbed');
const Guilds = require('../../../Databases/Models/Discord/Settings/Guilds');
const { ACAR } = require('../../Structures/Client');
class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.GuildCreate;
    }    
    /**
     * @param {ACAR} client
     * @param {Guild} guild 
     */
    async onLoad(guild) {
        try {
            let auditlogs = await guild.fetchAuditLogs({type: AuditLogEvent.BotAdd, limit: 1})
            let user = auditlogs.entries.first()
            if(user && user.executor) {
                    let embed = new genEmbed();
                    let settings = await client.fetchSettings(guild.id);
                    if(settings) {
                        settings.added_by = user.executor.id;
                        await settings.save();
                    }
    
            }
        } catch (error) {
            await client.fetchSettings(guild.id);
        }


        let owner = await guild.fetchOwner({})
        if(owner) {

            let Row = new ActionRowBuilder().setComponents(
                new ButtonBuilder()
                .setURL(`https://marsy.live/?_ref=discord&g=${guild.id}&u=${owner.id}`)
                .setStyle(ButtonStyle.Link)
                .setEmoji("1183353237529690142")
                .setLabel("Marsy.Live"),
                new ButtonBuilder()
                .setURL(`https://discord.gg/marsy`)
                .setStyle(ButtonStyle.Link)
                .setEmoji("1183353994970673232")
                .setLabel("Discord")
            );
            
            let Embed = new genEmbed()
            .setAuthor({name: client.user.username, iconURL: client.user.displayAvatarURL()})
            .setImage("https://cdn.discordapp.com/attachments/1181382930635948072/1183330233835860008/marsy_live_banner_w_3.png?ex=6587f128&is=65757c28&hm=c7e3fd49536c9de839f249821195b1b6aff2decaeb30133da32f5fbbfe03ecb3&")
            .setDescription(`Sevgili ${client.user.username} dostumuzla tanışın! 🚀

Marsy Sıralama Sistemi, Discord sunucularınızda etkileşimi ve rekabeti teşvik etmek için tasarlanmış bir özel bot sistemidir.
Hem sunucu sahiplerine hem de üyelere eğlenceli ve kazançlı bir deneyim sunar.

**📊 Sıralama Sistemi:**
Marsy Sıralama Sistemi, sunucudaki etkinliklere ve sohbetlere göre kullanıcıları sıralar. Marsy genelindeki tüm sunucuları \`/server-list\` komutu ile gösterip kapatabilirsin.

**⚙️ Kurulum:**
Sıralama sistemini hemen kurmak için \`/kurulum\` komutunu kullanın. Bot, gerekli izinleri otomatik olarak ayarlar ve sunucunuzun özelliklerine uygun bir şekilde yapılandırılır. Sıralamaya girebilmeniz için en az 15 ses aktifliğiniz olmalıdır. Ayrıca, normal sunucu listesine girebilmeniz için 100 üyeye sahip olmalısınız; aksi takdirde sıralamada görünmezsiniz.

**💬 Yorum Sistemi:**
Kurulumun ardından oluşturulan panele eklenen "Yorum Yap" düğmesi veya site üzerinden yapılan girişler aracılığıyla sunucu üyeleri, oylarını ve yorumlarını paylaşma imkanına sahiptir. Bu yorumlar, toplanan puanlarla ödüllendirilir ve sunucu sahipleri, bu puanları biriktirerek sunucularını öne çıkarmak, reklam avantajları elde etmek veya hediyeler kazanmak için kullanabilirler.

**🌟 Oy Toplama Sistemi:**
Kurulumun ardından oluşturulan panele eklenen "Oy Ver" düğmesi veya site üzerinden yapılan girişler aracılığıyla sunucu üyeleri, oylarını ve yorumlarını paylaşma imkanına sahiptir. Bu oylar, toplanan puanlarla ödüllendirilir ve sunucu sahipleri, bu puanları biriktirerek sunucularını öne çıkarmak, reklam avantajları elde etmek veya hediyeler kazanmak için kullanabilirler.


**🌌 Unutulmaz Bir Uzay Macerasına Katılın!**
Marsy Sıralama Sistemi ile sunucunuzdaki etkileşimi ve rekabeti artırın. Hem sunucu sahiplerine hem de üyelere benzersiz bir deneyim sunarak Mars'ın sınırlarını zorlayın.
Uzay yolculuğumuzda sizinle birlikte olmaktan heyecan duyuyoruz!

Herhangi bir sorunuz veya geri bildiriminiz varsa aşağı da bulunan "Discord" düğmesi ile sunucumuza katılıp bizlere bildirebilirsiniz.

Sevgiler,
Marsy Ailesi 💫`)
            owner.send({
                embeds: [ Embed ],
                components: [ 
                    Row
                ]
            });

        }
    }   
}    


module.exports = event;
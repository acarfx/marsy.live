const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, Guild, AuditLogEvent } = require('discord.js');
const { Event } = require('../../Structures/Event');
const { genEmbed } = require('../../Structures/genEmbed');
const Guilds = require('../../../Databases/Models/Discord/Settings/Guilds');
const { ACAR } = require('../../Structures/Client');
class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.GuildDelete;
    }    
    /**
     * @param {ACAR} client
     * @param {Guild} guild 
     */
    async onLoad(guild) {
        let settings = await client.fetchSettings(guild.id);
        if(settings) {
            if(guild.memberCount <= 1000 && guild.members.cache.has(_selfclient.user.id)) { 
                    let find_guild = _selfclient.guilds.cache.get(guild.id)
                    if(find_guild) find_guild.leave();
            }
            await settings.deleteOne();
        }
    }   
}    


module.exports = event;
const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, GuildMember, PermissionFlagsBits, Message } = require('discord.js');
const { Event } = require('../../Structures/Event');
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const { genEmbed } = require('../../Structures/genEmbed');
const cooldown = new Collection();
const ms = require('ms');
class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.InteractionCreate;
    }    
    /**
     * 
     * @param {import('discord.js').Interaction} interaction 
     * @returns 
     */
    async onLoad(interaction) {
            if (!interaction.isCommand()) return;

            

            const adapter = new FileSync('./Settings/System.json')
            const db = low(adapter);
            const _value = await db.value() || {};
            const Settings = _value.Settings.BOT;
            const system = global.system = Settings;

            if (!interaction.channel || interaction.channel.type == ChannelType.DM) return;
            const command = client.slashcommands.get(interaction.commandName);
            if (!command) return;
            const settings = await client.fetchSettings(interaction.guild.id);

            await command.onRequest(interaction, client, settings);
       
    }   
}    


/**
 * 
 * @param {Array} arr 
 * @returns { String }
 */
function random_arr(arr) {
    const rastgeleIndex = Math.floor(Math.random() * arr.length);
    return arr[rastgeleIndex];
}


/**
 * ! Bir kullanıcının yetkisini kontrol eder ve true false döndürür.
 * @param {Array} roles
 * @param {Object} options
 * @returns {Boolean}
 */
GuildMember.prototype.checkPermissions = function(roles = [], options = {
    Developer: true,
    Owner: true,
    Administrator: true,
    Roles: true,
}) {    
        if(options.Owner && this.id == this.guild.ownerId) return true;
        if(options.Developer && system.Developers.includes(this.id)) return true;
        if(options.Administrator && this.permissions.has(PermissionFlagsBits.Administrator)) return true;
        if(options.Roles && roles.some(x => this.roles.cache.has(x))) return true;
        
        return false;
};

module.exports = event;
const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, GuildMember, PermissionFlagsBits, Message } = require('discord.js');
const { Event } = require('../../Structures/Event');
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const { genEmbed } = require('../../Structures/genEmbed');
const cooldown = new Collection();
const ms = require('ms');
class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.MessageCreate;
    }    
    /**
     * 
     * @param {Message} message 
     * @returns 
     */
    async onLoad(message) {
            
            const adapter = new FileSync('./Settings/System.json')
            const db = low(adapter);
            const _value = await db.value() || {};
            const Settings = _value.Settings.BOT;
            const system = global.system = Settings;

            if (message.author.bot || !Settings.Prefixs.some(x => message.content.startsWith(x)) || !message.channel || message.channel.type != 0) return;

            const content = message.content;
            const prefixUsed = Settings.Prefixs.find(prefix => content.toLowerCase().startsWith(prefix.toLowerCase()));
            if (!prefixUsed) return;
            

            const args = content.slice(prefixUsed.length).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();
            const command = client.commands.get(commandName) || client.aliases.get(commandName);
            if(command) {
                
                if(command.devOnly && !message.member.checkPermissions([], {
                    Developer: true,
                    Owner: false,
                    Administrator: false,
                    Roles: false
                })) return message.reply({embeds: [new genEmbed().setDescription(`Bu komut sadece geliştiriciler için kullanılabilir. Bu komutu kullanmak için yeterli yetkiye sahip değilsin.`)]}).then(msg => {
                        setTimeout(() => {
                            msg.delete().catch(err => {})
                        }, 7500)
                        
                });

                if(command.ignoreUse && command.ignoreUse.length > 0 && !command.ignoreUse.some(guild => message.guild.id == guild)) {
                    return;
                }

                if(command.inVoiceChannel && !message.member.voice && !message.member.voice.channel) return message.reply({embeds: [new genEmbed().setDescription(`Bu komutu kullanabilmek için bir ses kanalına katılmalısın.`)]}).then(msg => {
                    setTimeout(() => {
                        msg.delete().catch(err => {})
                    }, 5000)
                });

                if(command.cooldown && cooldown.has(`${command.name}_${message.author.id}`)) return message.reply({embeds: [new genEmbed().setDescription(`Bu komutu <t:${String(cooldown.get(`${command.name}_${message.author.id}`)).slice(0, 10)}:R> kullanabilirsiniz.`)]}).then(msg => {
                    setTimeout(() => {
                        msg.delete().catch(err => {})
                    }, 5000)
                });

                const getSettings = await client.fetchSettings(message.guild.id);
                command.onRequest(client, message, args, genEmbed);

                if(!message.member.checkPermissions([], { Owner: true, Developer: true, Administrator: true, Roles: false })) {
                    cooldown.set(`${command.name}_${message.author.id}`, Date.now() + command.cooldown)
                    setTimeout(() => {
                        cooldown.delete(`${command.name}_${message.author.id}`)
                    }, command.cooldown);
                };

            }



       
    }   
}    


/**
 * 
 * @param {Array} arr 
 * @returns { String }
 */
function random_arr(arr) {
    const rastgeleIndex = Math.floor(Math.random() * arr.length);
    return arr[rastgeleIndex];
}


/**
 * ! Bir kullanıcının yetkisini kontrol eder ve true false döndürür.
 * @param {Array} roles
 * @param {Object} options
 * @returns {Boolean}
 */
GuildMember.prototype.checkPermissions = function(roles = [], options = {
    Developer: true,
    Owner: true,
    Administrator: true,
    Roles: true,
}) {    
        if(options.Owner && this.id == this.guild.ownerId) return true;
        if(options.Developer && system.Developers.includes(this.id)) return true;
        if(options.Administrator && this.permissions.has(PermissionFlagsBits.Administrator)) return true;
        if(options.Roles && roles.some(x => this.roles.cache.has(x))) return true;
        
        return false;
};

module.exports = event;
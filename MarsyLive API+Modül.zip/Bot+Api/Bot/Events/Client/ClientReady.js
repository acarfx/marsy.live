const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, PermissionFlagsBits } = require('discord.js');
const { Event } = require('../../Structures/Event');
const GuildSettings = require('../../../Databases/Models/Discord/Settings/Guilds');
const Guilds = require('../../../Databases/Models/Discord/Guilds');
const Users = require('../../../Databases/Models/Users');


class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.ClientReady;
    }    

    async onLoad() {
        client.logger.log(`${client.user.tag} - Bot Client Online!`, "ready");
        await client.user.setActivity({name: "marsy'nin gezegeninde bulunan koşu", type: 5})
        await client.user.setStatus("dnd");

        await check_user_server();
        setInterval(async () => {
            await check_user_server();
        }, 1000 * 60 * 10);

        setInterval(async () => {
            await server_list_renew();
        }, 10000);
        /**
         * 
         * 
         *      const fetchSlash = await client.application.commands.fetch()
                setInterval(async () => {
                    await server_list_renew();
                }, 10000)
        
                await Promise.all(fetchSlash.map(async slash => {
                    await client.application.commands.delete(slash.id) 
                }))

         */
    

    }   
}



async function check_user_server() {
    const GUILD_ID = "1178732548571017306";
    const ROLE_ID = "1181392561479372841";
    const OWNER_ROLE_ID = "1185378584399974460";

    const users = await Users.find();
    const guild = client.guilds.cache.get(GUILD_ID);
    if(!guild) return;

    let owner_roles = guild.roles.cache.get(OWNER_ROLE_ID);
    if(owner_roles) {
        for (let index = 0; index < owner_roles.members.size; index++) {
            const member = owner_roles.members[index];
            if(member) {
                let guild_own = await Guilds.findOne({ownerId: member.id});
                if(!guild_own || (guild_own && !client.guilds.cache.get(guild_own.guildId))) {
                    member.roles.remove(OWNER_ROLE_ID);
                }
            }
        }
    }
    

    for (let index = 0; index < users.length; index++) {
        const user = users[index];
        const get_user_guild = guild.members.cache.get(user.discord_id);
        if(user && user.discord_id && get_user_guild && !get_user_guild.roles.cache.has(ROLE_ID)) {
            get_user_guild.roles.add(ROLE_ID);
        };

        const guild_data = await Guilds.findOne({ownerId: user.discord_id});
        if(user && user.discord_id && get_user_guild && (guild_data && client.guilds.cache.get(guild_data.guildId))) {
            get_user_guild.roles.add(OWNER_ROLE_ID)
        };
    }
}

async function server_list_renew() {
    const guild = client.guilds.cache.get("1178732548571017306");
    const data = await Guilds.findOne({guildId: guild.id})

    if(data) {


        const g_data = await GuildSettings.findOne({guild: data._id.toString()});
        if(g_data && g_data.settings) {
           

            if(g_data.settings.serverListChannel && g_data.settings.serverListId) {

                let channel = client.channels.cache.get(g_data.settings.serverListChannel)
                if(channel) {
                    let message;
                    try {
                        message = await channel.messages.fetch(g_data.settings.serverListId)
                        await client.fetch_server_list(message);
                    } catch (error) {
                        g_data.settings.serverListChannel = undefined;
                        g_data.settings.serverListId = undefined;

                        await g_data.save();
                    }
                }

            }

        }
    }
}

module.exports = event;
const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, GuildMember, PermissionFlagsBits, Message, ModalBuilder, TextInputBuilder } = require('discord.js');
const { Event } = require('../../Structures/Event');
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const { genEmbed } = require('../../Structures/genEmbed');
const cooldown = new Collection();
const ms = require('ms');
const Votes = require('../../../Databases/Models/Discord/Votes');
const Comments = require('../../../Databases/Models/Discord/Comments');

class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.InteractionCreate;
    }    
    /**
     * 
     * @param {import('discord.js').Interaction} interaction 
     * @returns 
     */
    async onLoad(interaction) {
            if(!interaction.isButton()) return;
            
            let user = interaction.guild.members.cache.get(interaction.member.id);
            if(!user) return;

            let guild = interaction.guild;
            if(!guild) return;


            if(interaction.customId == "yorum_yap") {
                let data = await client.fetchSettings(guild.id);
                if(!data) return await interaction.reply({ephemeral: true, content: `Bu sunucuda kurulum işlemi gerçekleştirilmemiş. ${client.getEmoji("marsy_info")}`});
                
                let find = await Comments.findOne({
                    guild: data.guild.toString(),
                    userId: user.id
                })

                if(find) return interaction.reply({ content: `Bu sunucu için daha önce ${client.generateStarRating(find.star)} (${find.star} / 5) yıldızında değerlendirme yaptınız.`, ephemeral: true });



                const Modal = new ModalBuilder()
                .setCustomId(`sunucu_yorum_yap`)
                .setTitle(`${guild.name}`)

                .setComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                        .setCustomId(`comment`)
                        .setLabel(`Yorumunuz`)
                        .setPlaceholder(`Örn: Marsy'de en beğendiğim şey kültürleri oldu!!!!!`)
                        .setMinLength(10)
                        .setMaxLength(500)
                        .setRequired(true)
                        .setStyle("Paragraph")
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                        .setCustomId(`star`)
                        .setLabel(`Sunucu 5 üzerinden kaç?`)
                        .setPlaceholder(`Örn: 5`)
                        .setRequired(true)
                        .setMaxLength(1)
                        .setStyle("Short")
                    )
                );

                await interaction.showModal(Modal);
            
            
            }

            if(interaction.customId == "oy_ver") {
                
                let anti_bot_captcha = [
                    {name: "Sarı Kalp", emoji: "💛", value: "capt_skalp"},
                    {name: "Yeşil Kalp", emoji: "💚", value: "capt_ykalp"},
                    {name: "Kırmızı Kalp", emoji: "❤️", value: "capt_kkalp"},
                    {name: "Siyah Kalp", emoji: "🖤", value: "capt_sskalp"},
                    {name: "Mavi Kalp", emoji: "💙", value: "capt_mkalp"},
                    {name: "Pembe Kalp", emoji: "🩷", value: "capt_pkalp"},
                    {name: "Beyaz Kalp", emoji: "🤍", value: "capt_bkalp"},
                    {name: "Mor Kalp", emoji: "💜", value: "capt_mmkalp"},
                    {name: "Gri Kalp", emoji: "🩶", value: "capt_gkalp"}
                ]
            

                let data = await client.fetchSettings(guild.id);
                if(!data) return await interaction.reply({ephemeral: true, content: `Bu sunucuda kurulum işlemi gerçekleştirilmemiş. ${client.getEmoji("marsy_info")}`});
               // if(!data.settings.serverDetailChannel && !data.settings.serverDetailId) return await interaction.reply({ephemeral: true, content: `Bu sunucu kurulum yapmamış!`});
                
                const twoMinutesInMilliseconds = 3 * 60 * 60 * 1000;
                
                const latestVote = await Votes.findOne({
                    guild: data.guild.toString(),
                    author: user.id
                }).sort({ createdAt: -1 });

                if(latestVote) {
                    const currentTime = new Date();
                    const voteTime = latestVote.createdAt.getTime();
                    const remainingTime = voteTime + twoMinutesInMilliseconds - currentTime;
                
                    if (remainingTime > 0) {
                        let zaman = Date.now() + remainingTime;
                   
                        return await interaction.reply({ ephemeral: true, content: `Bu sunucu için birdahaki oyunuzu <t:${String(zaman).slice(0, 10)}:R> kullanabileceksin.` }).catch(err => {});
                    }
                }


                let Row = new ActionRowBuilder()
                                    
                anti_bot_captcha = anti_bot_captcha.shuffle();
                anti_bot_captcha = anti_bot_captcha.slice(0, 5);
                let rand_captcha = anti_bot_captcha.random();
                
                for (let index = 0; index < anti_bot_captcha.length; index++) {
                    const emoji = anti_bot_captcha[index];
                    Row.addComponents(
                        new ButtonBuilder()
                        .setCustomId(emoji.value)
                        .setEmoji(emoji.emoji)
                        .setStyle(ButtonStyle.Secondary)
                    )
                }


                await interaction.reply({content: `Bu sunucuya oy verebilmek için aşağıda bulunan ${rand_captcha.name}'i seçiniz!`, ephemeral: true, components: [ Row ]})

                var filter  = (i) => i.user.id == user.id;

                const collector = interaction.channel.createMessageComponentCollector({
                    filter,
                    max: 1
                })

                collector.on('collect', async (i) => {

                            if(i.customId == rand_captcha.value) {
                                let newVote = new Votes({
                                    guild: data.guild.toString(),
                                    author: user.id
                                })
                
                                await newVote.save().then(async () => {
                                    
                                    await i.update({ephemeral: true, content: `${client.getEmoji("marsy_accept")} Başarıyla ${guild.name} sunucusuna doğru seçim yaparak oy verdiniz. Tebrikler!`, components: []});
                                    await client.fetch_oy(interaction.message);
                                    data.settings.serverDetailChannel = interaction.channel;
                                    data.settings.serverDetailId = interaction.message.id;
                                    await data.save();

                                    if(data.settings.voteRole && interaction.guild.roles.cache.has(data.settings.voteRole)) {
                                        interaction.member.roles.add(data.settings.voteRole).catch(err => {
                                            
                                        })
                                    }
                                   
                                    
                                })
                                .catch(async (err) => {
                                    console.log(err)
                                    return await i.update({ephemeral: true, content: `Bu sunucuya oy verilemez. ${client.getEmoji("marsy_decline")}`, ephemeral: true});
                                })
                            } else {
                                if(i.customId.includes("capt_")) {
                                    await i.update({content: `Hatalı seçim yaptınız. Tekrar oy vermek için "Oy Ver" düğmesini kullanınız! ${client.getEmoji("marsy_decline")}`, components: [], ephemeral: true})
                                }
                            }
                });
            }

    }   
}    


/**
 * 
 * @param {Array} arr 
 * @returns { String }
 */
function random_arr(arr) {
    const rastgeleIndex = Math.floor(Math.random() * arr.length);
    return arr[rastgeleIndex];
}


/**
 * ! Bir kullanıcının yetkisini kontrol eder ve true false döndürür.
 * @param {Array} roles
 * @param {Object} options
 * @returns {Boolean}
 */
GuildMember.prototype.checkPermissions = function(roles = [], options = {
    Developer: true,
    Owner: true,
    Administrator: true,
    Roles: true,
}) {    
        if(options.Owner && this.id == this.guild.ownerId) return true;
        if(options.Developer && system.Developers.includes(this.id)) return true;
        if(options.Administrator && this.permissions.has(PermissionFlagsBits.Administrator)) return true;
        if(options.Roles && roles.some(x => this.roles.cache.has(x))) return true;
        
        return false;
};

module.exports = event;
const {
    Collection,
    Utils,
    escapeMarkdown,
    ChannelFlags,
    ChannelType,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    GuildMember,
    PermissionFlagsBits,
    Message
} = require('discord.js');
const {Event} = require('../../Structures/Event');
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const {genEmbed} = require('../../Structures/genEmbed');
const cooldown = new Collection();
const ms = require('ms');
const GuildData = require('../../../Databases/Models/Discord/Settings/Guilds');
const Guilds = require('../../../Databases/Models/Discord/Guilds');
const Rankings = require('../../../Databases/Models/Discord/Rankings');
const Comments = require('../../../Databases/Models/Discord/Comments');
class event extends Event {
    constructor(client) {
        super(client, {enabled: true});

        this.name = this.Events.InteractionCreate;
    }
    /**
     *
     * @param {import('discord.js').Interaction} interaction
     * @returns
     */
    async onLoad(interaction) {
        if (!interaction.isModalSubmit()) 
            return;
        
        let user = interaction
            .guild
            .members
            .cache
            .get(interaction.member.id);
        if (!user) 
            return;
        
        let guild = interaction.guild;
        if (!guild) 
            return;
        
        let data = await client.fetchSettings(guild.id);

        if (interaction.customId == "sunucu_yorum_yap") {
            const comment = interaction
                .fields
                .getTextInputValue("comment") || undefined;
            let star = interaction
                .fields
                .getTextInputValue("star") || 5;

            if (isNaN(star)) {
                return interaction.reply(
                    {content: `${client.getEmoji("marsy_decline")} Lütfen geçerli bir sayı giriniz.`, ephemeral: true}
                );
            }

            star = parseInt(star);

            if (star > 5 || star < 1) {
                return interaction.reply(
                    {content: `${client.getEmoji("marsy_decline")} Lütfen geçerli bir puan giriniz. En az 1, en fazla 5 olmalıdır.`, ephemeral: true}
                );
            }

            let newComment = new Comments({
                guild: data
                    .guild
                    .toString(),
                userId: user.id,
                userData: {
                    name: user.user.tag,
                    avatar: user.displayAvatarURL({size: 2048})
                },
                content: comment.trim(),
                star
            });

            if (data.settings.commentRole && interaction.guild.roles.cache.has(data.settings.commentRole)) {
                interaction
                    .member
                    .roles
                    .add(data.settings.commentRole)
                    .catch(err => {})
                }

            await newComment
                .save()
                .then(x => {
                    return interaction.reply({
                        content: `${client.getEmoji("marsy_accept")} Başarıyla ${guild
                            .name} sunucusuna ${client
                            .generateStarRating(star)} yıldızlı yorum yaptınız.`,
                        ephemeral: true
                    });
                })

        }

        if (interaction.customId == "sunucu_onay_sayfasi") {
            let embed = new genEmbed()

            if (data) {

                let Row = new ActionRowBuilder().setComponents(
                    new ButtonBuilder().setURL(`https://marsy.live/?_ref=discord_setup_finish&g=${guild.id}&u=${user.id}`).setStyle(ButtonStyle.Link).setEmoji("1183353237529690142").setLabel("Marsy.Live"),
                )

                const description = interaction
                    .fields
                    .getTextInputValue("description") || undefined;
                const purpose = interaction
                    .fields
                    .getTextInputValue("purpose") || undefined;

                let last = data.setup.finish;

                if (data && data.setup && !data.setup.finish) 
                    data.setup.finish = true

                data.setup.edited_by = user.id;
                if (description) 
                    data.settings.description = description;
                data.settings.purpose = purpose;

                let text = `Şuan da websitemizde sunucunuz görüntüleniyor.
Eğer ki görüntülenemesini istemiyorsanız tekrardan \`/kurulum\` komutu ile kapatabilirsiniz.`;
                if (guild.memberCount < 100) 
                    text = `Sunucunuzda 100 üye bulunamadığı için sunucunuz websitemizde görüntülenmiyor.
Otomatik olarak 100 üyeyi geçince görüntülenecektir!`

                await data
                    .save()
                    .then(async () => {
                        await interaction.update({
                            embeds: [embed.setDescription(
                                    `${last
                                        ? `Başarıyla ${guild.name} sunucusunun bilgilerini güncellendin.`
                                        : `Başarıyla ${guild.name} sunucusunun kurulumu <t:${String(Date.now()).slice(
                                            0,
                                            10
                                        )}:R> tamamlandı.`}
    
**Durum:**
${text}`
                                )],
                            components: [Row]
                        })
                    })
            } else {
                await interaction.update(
                    {content: `Sistemde ayar belgelerin bulunamadı. Lütfen site sahibin başvurun!`, embeds: [], components: []}
                )
            }

        }

    }
}

/**
 *
 * @param {Array} arr
 * @returns { String }
 */
function random_arr(arr) {
    const rastgeleIndex = Math.floor(Math.random() * arr.length);
    return arr[rastgeleIndex];
}

/**
 * ! Bir kullanıcının yetkisini kontrol eder ve true false döndürür.
 * @param {Array} roles
 * @param {Object} options
 * @returns {Boolean}
 */
GuildMember.prototype.checkPermissions = function (roles = [], options = {
    Developer: true,
    Owner: true,
    Administrator: true,
    Roles: true
}) {
    if (options.Owner && this.id == this.guild.ownerId) 
        return true;
    if (options.Developer && system.Developers.includes(this.id)) 
        return true;
    if (options.Administrator && this.permissions.has(PermissionFlagsBits.Administrator)) 
        return true;
    if (options.Roles && roles.some(x => this.roles.cache.has(x))) 
        return true;
    
    return false;
};

module.exports = event;
const { Collection, Utils, escapeMarkdown, ChannelFlags, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Event } = require('../../Structures/Event');
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')

class event extends Event {
    constructor(client) {
        super(client, {
            enabled: true
        });

        this.name = this.Events.GuildMemberAdd;
    }    

    async onLoad(member) {

            const adapter = new FileSync('./Settings/System.json')
            const db = low(adapter);
            const _value = await db.value() || {};
            const Settings = _value.Settings.BOT;
            
            if(Settings.guildId != member.guild.id) return;
        
            let joinRoles = Settings.joinRoles || [];
            joinRoles = joinRoles.filter(x => member.guild.roles.cache.has(x)) || [];
        
            await member.roles.set(joinRoles, `${_value.Settings.Name} - Sunucuya Katıldığı İçin Rol Verildi.`).catch(err => {
                Logger.log(`Anasunucuda kayıtsız rolü verilmediği için bu uyarı görüyorsunuz.`, "error");
            });
        
        
            let channel = member.guild.channels.cache.find(x => x.name == Settings.welcomeChannel || x.id == Settings.welcomeChannel)
            if(channel) {
        
                let Row = new ActionRowBuilder()
                .setComponents(
                    new ButtonBuilder()
                    .setURL(Settings.URL + `/?_ref=discord&u=${member.id}`)
                    .setStyle(ButtonStyle.Link)
                    .setEmoji("948674910425853993")
                    .setLabel("Sunucu Listesi")
                )
        
                channel.send({
                    content: `Hoş Geldin! ${member} :tada:
${random_arr(Settings.welcomeRandomTexts)}`,
                    components: [
                        Row
                    ]
                }).then(msg => {
                    msg.react('❤️').catch(e => {});
                    msg.react('😘').catch(e => {});
                    msg.react('😽').catch(e => {});
                })
            }
    
    }   
}    


/**
 * 
 * @param {Array} arr 
 * @returns { String }
 */
function random_arr(arr) {
    const rastgeleIndex = Math.floor(Math.random() * arr.length);
    return arr[rastgeleIndex];
}


module.exports = event;
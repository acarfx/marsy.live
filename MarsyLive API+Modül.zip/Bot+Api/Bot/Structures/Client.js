const {Client, GatewayIntentBits, Partials, Collection, REST, Routes, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, Message, GuildEmoji, GuildMember, User} = require('discord.js');
const DISCORD_LOGS = require('discord-logs');
const mongoose = require('mongoose');
const { bgBlue, black, green } = require("chalk");
const { createCanvas, loadImage, registerFont } = require('canvas');
const fs = require('fs');
const { glob } = require("glob");
const { promisify } = require("util");
const globPromise = promisify(glob);

const path = require('path');
const Settings = require('../../Databases/Models/Discord/Settings/Guilds');
const Guilds = require('../../Databases/Models/Discord/Guilds');
const Rankings = require('../../Databases/Models/Discord/Rankings');

registerFont("Assets/Alata-Regular.ttf", { family: 'Alata' });

class ACAR extends Client {
    constructor(opt) {
        super({
            intents: Object.keys(GatewayIntentBits).map((a)=>{
                return GatewayIntentBits[a]
            }),
            partials: [
                Partials.Channel,
                Partials.GuildMember,
                Partials.GuildScheduledEvent,
                Partials.Message,
                Partials.Reaction,
                Partials.ThreadMember,
                Partials.User
            ]

     
        })
        DISCORD_LOGS(this);
        Object.defineProperty(this, "location", { value: process.cwd() });
        this.logger = require('../../Functions/Console.Logger');
        
        require('../../Prototypes/Array');
        require('../../Prototypes/Strings');

        this.name = opt.name || "Belirtilmedi";
        this._dirname = opt._dirname || this.name;

        this.commands = new Collection();
        this.slashcommands = new Collection();
        this.slashArr = [];
        this.aliases = new Collection();


        this.on("guildUnavailable", async (guild) => { console.log(`[UNAVAIBLE]: ${guild.name}`) })
                .on("disconnect", () => this.logger.log("Bot is disconnecting...", "disconnecting"))
                .on("reconnecting", () => this.logger.log("Bot reconnecting...", "reconnecting"))
               // .on("error", (e) => this.logger.log(e, "error"))
                .on("warn", (info) => this.logger.log(info, "warn"));

              //  process.on("unhandledRejection", (err) => { this.logger.log(err, "caution") });
                process.on("warning", (warn) => { this.logger.log(warn, "varn") });
                process.on("beforeExit", () => { console.log('Sistem kapatılıyor...'); });
                process.on("uncaughtException", err => {
                    const hata = err.stack.replace(new RegExp(`${__dirname}/`, "g"), "./");
                        console.error("Beklenmedik Hata: ", hata);
                       // process.exit(1);
                });

    }

    async fetchSlash() {
        let dirs = fs.readdirSync("./Bot/Commands/Slash", { encoding: "utf8" });
        this.logger.log(`${black.bgHex('#c62e')(this._dirname.toUpperCase())} ${dirs.length} slash commands category in client loaded.`, "command");
        dirs.forEach(dir => {
            let files = fs.readdirSync(`./Bot/Commands/Slash/${dir}`, { encoding: "utf8" }).filter(file => file.endsWith(".js"));
            this.logger.log(`${black.bgHex('#c62e')(this._dirname.toUpperCase())} ${files.length} slash command loaded in ${dir} category.`, "load");
            files.forEach(file => {
                const command =  require(`../Commands/Slash/${dir}/${file}`)
                if(command) {
                    this.slashcommands.set(command.data.name, command);
                    this.slashArr.push(command.data.toJSON());
                    
                }
            });
        });

        
            const rest = new REST({
                version: '10'
            }).setToken(this.token);
    
            (async () => {
                try {
                    this.logger.log(`Started refreshing application (/) commands.`, "log")
    
                    await rest.put(
                        Routes.applicationCommands(this.user.id), {
                            body: this.slashArr
                        },
                    );
    
                
                    this.logger.log(`Successfully reloaded application (/) commands.`, "log")
                } catch (error) {
                    console.log(error)
                }
            })();
       
    }

    async fetchCommands() {
        this.fetchSlash()
        let dirs = fs.readdirSync("./Bot/Commands/Prefix", { encoding: "utf8" });
        this.logger.log(`${black.bgHex('#c62e')(this._dirname.toUpperCase())} ${dirs.length} commands category in client loaded.`, "command");
        dirs.forEach(dir => {
            let files = fs.readdirSync(`./Bot/Commands/Prefix/${dir}`, { encoding: "utf8" }).filter(file => file.endsWith(".js"));
            this.logger.log(`${black.bgHex('#c62e')(this._dirname.toUpperCase())} ${files.length} command loaded in ${dir} category.`, "load");
            files.forEach(file => {
                const cmd = new (require(`../Commands/Prefix/${dir}/${file}`))(this);
                if(cmd) cmd.on()
            });
        });
    }
    /**
     * 
     * @param {String} guildId 
     * @returns {Settings}
     */
    async fetchSettings(guildId) {
            if(!guildId) {
                const data = await Settings.find({}).populate([
                    {path: "guild"}
                ]);
                return data;
            } 
            
            const guild_data = await Guilds.findOne({ guildId });
            if(!guild_data) return false;

            const data = await Settings.findOne({guild: guild_data._id.toString()});
            if(!data) {
                let newSettings = new Settings({
                    guild: guild_data._id.toString()
                })

                await newSettings.save()
                
                return newSettings
            } 

            return data;

    }

    /**
     * 
     * @param {String} name
     * @returns {GuildEmoji}
     */
    getEmoji(name) {
        let emoji = this.emojis.cache.find(x => x.name.toLocaleLowerCase() == name.toLocaleLowerCase() || x.id == name);
        if(!emoji) return "";
        return emoji; 
    }

    generateStarRating(score) {
        if (score < 1 || score > 5 || isNaN(score)) {
          return "Geçersiz puan";
        }
      

        const fullStars = `${this.getEmoji("marsy_yildiz")}`.repeat(Math.floor(score));
        const halfStar = score % 1 !== 0 ? "½" : "";
        const emptyStars = `${this.getEmoji("marsy_bos_yildiz")}`.repeat(Math.floor(5 - score));
      
        const starRating = `${fullStars}${halfStar}${emptyStars}`;
      
        return starRating;
      }

 /**
   * 
   * @param {Message} message 
   * @param {*} last_user 
   * @param {*} av 
   * @param {*} ind 
   * @param {*} username 
   * @param {*} oy 
   * @param {*} start 
   * @param {*} aralar 
   * @param {*} ata 
   */
 
 async fetch_oy(message, av = 150.7, ind = 48.5, username = 205, oy = 625, start = 161.5, aralar = 56.5, ata = 35.2, acar = 161.5) {
    const Data = await Guilds.findOne({ guildId: message.guild.id }).populate([
        { path: "rawVotes" },
        { path: "votes" },
        { path: "ranking" },
        { path: "settings" }
    ]);

    if (!Data) return;

    const canvas = createCanvas(1920, 840);
    const ctx = canvas.getContext('2d');

    const background = await loadImage('Assets/test.png');
    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

    const drawText = (x, y, text, font = '30px Alata', color = 'white') => {
        ctx.font = font;
        ctx.fillStyle = color;
        ctx.fillText(text, x, y);
    };

    const roundedImage = (ctx, img, x, y, width, height, radius) => {
        ctx.save();
        ctx.beginPath();
        ctx.arc(x + radius, y + radius, radius, Math.PI, 1.5 * Math.PI);
        ctx.lineTo(x + width - radius, y);
        ctx.arc(x + width - radius, y + radius, radius, 1.5 * Math.PI, 2 * Math.PI);
        ctx.lineTo(x + width, y + height - radius);
        ctx.arc(x + width - radius, y + height - radius, radius, 0, 0.5 * Math.PI);
        ctx.lineTo(x + radius, y + height);
        ctx.arc(x + radius, y + height - radius, radius, 0.5 * Math.PI, Math.PI);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(img, x, y, width, height);
        ctx.restore();
    };

    let offsetY = start;
    let offsetYZ = acar;
    let total_votes = 0;

    try {
        const users = await Promise.all(Data.votes.map(async (currentDocument, index, array) => {
            const user = await message.client.users.fetch(currentDocument.author);
            if (!user) return;

            const avatar = await loadImage(user.displayAvatarURL({ size: 2048, format: "png" }).replace("webp", "png").replace("gif", "png"));

            return {
                author: currentDocument.author,
                user: user.username,
                avatar,
                totalVotes: 1,
                last: index === array.length - 1,
            };
        }));

        const oyToplami = users.reduce((acc, user) => {
            const existingAuthor = acc.find(item => item.author === user.author);

            total_votes++;
            if (!existingAuthor) {
                acc.push(user);
            } else {
                existingAuthor.totalVotes += 1;
                if (user.last && !existingAuthor.last) {
                    existingAuthor.last = true;
                }
            }

            return acc;
        }, []);

        const guild_index = await Guilds.find({}).populate([{ path: "rawVotes" }]);
        const sortedGuildIndex = guild_index.filter(x => x.rawVotes > 0).sort((a, b) => b.rawVotes - a.rawVotes);
        const targetIndex = sortedGuildIndex.findIndex(guild => guild.guildId === message.guild.id);

        drawText(1637.5, 605, targetIndex !== -1 ? `${targetIndex + 1}.` : "+99.", '20px Alata');

        oyToplami.sort((a, b) => b.totalVotes - a.totalVotes);

        for (let index = 0; index < Math.min(oyToplami.length, 20); index++) {
            const vote = oyToplami[index];
            const x = index > 9 ? 735 : ind;
            const y = index > 9 ? offsetYZ + 1 : offsetY + 1;

            roundedImage(ctx, vote.avatar, index > 9 ? 837.2 : av, index > 9 ? offsetYZ - ata - 1 : offsetY - ata - 1, 51, 51, 16);

            drawText(x, y, `${String(index + 1).padStart(2, " ")}`);
            drawText(index > 9 ? 895 : username, y, vote.user);
            drawText(index > 9 ? 1318 : oy, y, vote.totalVotes, '25px Alata');

            index > 9 ? offsetYZ += aralar : offsetY += aralar;
        }

        const guildImage = await loadImage(message.guild.iconURL({ size: 2048 }).replace("webp", "png").replace("gif", "png"));
        roundedImage(ctx, guildImage, 1616, 353.5, 96, 96, 96 / 2);
        drawText(1525.5, 500, message.guild.name, '24px Alata');

        drawText(1540.5, 605, oyToplami.length, '20px Alata');
        drawText(1735.5, 605, total_votes, '20px Alata');

        const last_user = oyToplami.find(x => x.last);

        if (last_user) {
            roundedImage(ctx, last_user.avatar, 1465, 232.5, 51, 51, 16);
            drawText(1525.5, 265.5, last_user.user);
        } else {
            roundedImage(ctx, guildImage, 1465, 232.5, 51, 51, 16);
            drawText(1525.5, 265.5, "Daha önce oy veren olmadı");
        }

        message.edit({
            content: `Siz de ${message.guild.name} sunucusuna oy vermek ve değerlendirmek ister misiniz?`,
            components: [new ActionRowBuilder().setComponents(
                new ButtonBuilder().setStyle(ButtonStyle.Primary).setCustomId(`oy_ver`).setEmoji("1183387240802558022").setLabel("Oy Ver"),
                new ButtonBuilder().setStyle(ButtonStyle.Primary).setCustomId(`yorum_yap`).setEmoji("1183387243356880966").setLabel("Yorum Yap"),
                new ButtonBuilder().setURL(`https://discordapp.com/oauth2/authorize?response_type=code&client_id=909858878068523038&redirect_uri=https://marsy.live/System/Discord/Callback&scope=identify+email+connections+guilds.join+guilds+bot+applications.commands`).setStyle(ButtonStyle.Link).setEmoji("1183353237529690142").setLabel("Marsy.Live")
            )],
            files: [{ attachment: canvas.toBuffer(), name: `${message.guild.id}-oylar.png` }],
        });
    } catch (error) {
      
    }
}


  /**
   * 
   * @param {Message} message 
   * @param {*} last_user 
   * @param {*} av 
   * @param {*} ind 
   * @param {*} username 
   * @param {*} oy 
   * @param {*} start 
   * @param {*} aralar 
   * @param {*} ata 
   */
 
    async  fetch_oy_test(message, av = 192.7, ind = 84.5, username = 265, oy = 735 , start = 150, aralar = 62, ata = 18) {
        let Data = await Guilds.findOne({
            guildId: message.guild.id
        }).populate([
            { path: "rawVotes" },
            { path: "votes" },
            { path: "ranking" },
            { path: "settings" }
        ]);
    
        if (Data) {
           
            let Row = new ActionRowBuilder().setComponents(
                new ButtonBuilder()
                .setStyle(ButtonStyle.Primary)
                .setCustomId(`oy_ver`)
                .setEmoji("1183387240802558022")
                .setLabel("Oy Ver"),
                new ButtonBuilder()
                .setStyle(ButtonStyle.Primary)
                .setCustomId(`yorum_yap`)
                .setEmoji("1183387243356880966")
                .setLabel("Yorum Yap"),
                new ButtonBuilder()
                .setURL(`https://discordapp.com/oauth2/authorize?response_type=code&client_id=909858878068523038&redirect_uri=https://marsy.live/System/Discord/Callback&scope=identify+email+connections+guilds.join+guilds+bot+applications.commands`)
                .setStyle(ButtonStyle.Link)
                .setEmoji("1183353237529690142")
                .setLabel("Marsy.Live")
            );


            const canvas = createCanvas(850, 1650);
            const ctx = canvas.getContext('2d');
    
            const background = await loadImage('Assets/oy_table_new.png');
            ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
    
            const drawText = (x, y, text, font = '30px Alata', color = 'white') => {
                ctx.font = font;
                ctx.fillStyle = color;
                ctx.fillText(text, x, y);
            };
    
            const roundedImage = (ctx, img, x, y, width, height, radius) => {
                ctx.save();
                ctx.beginPath();
                ctx.arc(x + radius, y + radius, radius, Math.PI, 1.5 * Math.PI);
                ctx.lineTo(x + width - radius, y);
                ctx.arc(x + width - radius, y + radius, radius, 1.5 * Math.PI, 2 * Math.PI);
                ctx.lineTo(x + width, y + height - radius);
                ctx.arc(x + width - radius, y + height - radius, radius, 0, 0.5 * Math.PI);
                ctx.lineTo(x + radius, y + height);
                ctx.arc(x + radius, y + height - radius, radius, 0.5 * Math.PI, Math.PI);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(img, x, y, width, height);
                ctx.restore();
            };
    
            let offsetY = start;
            
            let total_votes = 0;
            

            try {
                const users = await Promise.all(Data.votes.map(async (currentDocument, index, array) => {
                    const user = await message.client.users.fetch(currentDocument.author);
                    if (user) {
                        const avatar = await loadImage(user.displayAvatarURL({ size: 2048, format: "png" }).replace("webp", "png").replace("gif", "png"));
                
                        const isLast = index === array.length - 1;
                
                    
                
                        return {
                            author: currentDocument.author,
                            user: user.username,
                            avatar,
                            totalVotes: 1,
                            last: isLast,
                        };
                    }
                }));
    
                const oyToplami = users.reduce((acc, user, index, array) => {
                    const existingAuthor = acc.find(item => item.author === user.author);
                
                    if (!existingAuthor) {
                        total_votes++;
                        acc.push(user);
                    } else {
                        total_votes++;
                        existingAuthor.totalVotes += 1;
                        if(user.last && !existingAuthor.last) {
                            existingAuthor.last = true;
                        } 
                    }
                
                 
            
                
                    return acc;
                }, []);
    
                oyToplami.sort((a, b) => b.totalVotes - a.totalVotes);
    
                for (let index = 0; index < Math.min(oyToplami.length, 20); index++) {
                    const vote = oyToplami[index];
    
                    roundedImage(ctx, vote.avatar, av, offsetY - ata, 55, 55, 27.5);

                    drawText(ind, offsetY + 25, `${String(index + 1).padStart(2, " ")}`);
                    drawText(username, offsetY + 25, vote.user);
                    drawText(oy, offsetY + 25, vote.totalVotes, '25px Alata');
    
                    offsetY += aralar;
                }

                let guildImage = await loadImage(message.guild.iconURL({size: 2048}).replace("webp", "png").replace("gif", "png"))
                roundedImage(ctx, guildImage, 76, 30, 55, 55, 27.5);
                drawText(av, 65.5, message.guild.name, '36px Alata');

                let last_user = oyToplami.find(x => x.last)

               /// console.log(oyToplami)

                if(last_user) {
                    const userIndex = oyToplami.indexOf(last_user);
                    roundedImage(ctx, last_user.avatar, av, 1471.5, 55, 55, 27.5);
                    drawText(265.5, 1510, last_user.user, '36px Alata');
                    drawText(ind, 1510, `${String(userIndex + 1).padStart(2, " ")}`);
                    drawText(oy, 1510, `${String(total_votes).padStart(2, " ")}`, '25px Alata');
                } else {
                    roundedImage(ctx, guildImage, av, 1471.5, 55, 55, 27.5);
                    drawText(265.5, 1510, "Daha önce oy veren olmadı", '34px Alata');
                    drawText(ind, 1510, `-`);
                    drawText(oy, 1510, `${String(total_votes).padStart(2, " ")}`, '25px Alata');
                }


                message.edit({
                    content: null,
                    components: [ Row ],
                    files: [
                        {
                            attachment: canvas.toBuffer(),
                            name: `${message.guild.name}-oylar.png`,
                        },
                    ],
                });
            } catch (error) {
               
            }
        }
    }


    async fetch_server_list(message) {
        let Data = await Rankings.find({
            all_voice: { $gte: 15 }
        }).populate([{ path: "guild", populate: [
            {path: "rawVotes"},
            {path: "settings"}
        ] }]);

        Data = Data.filter(x => {
            if(x.guild.settings) {
                return  x.guild.isRanking && x.guild.settings.setup.finish
            } else {
                return x.guild.isRanking
            }

        }).sort((a, b) => b.all_voice - a.all_voice) || [];


        let Row = new ActionRowBuilder().setComponents(
            new ButtonBuilder()
            .setURL(`https://marsy.live/?_ref=discord&g=${message.guild.id}`)
            .setStyle(ButtonStyle.Link)
            .setEmoji("1183353237529690142")
            .setLabel("Marsy.Live")
        )

       
        let embed = new EmbedBuilder()
        .setAuthor({name: this.user.username, iconURL: this.user.displayAvatarURL()})
        .setColor("White")
        .setDescription(`Aşağı da **Marsy** gezegeninde bulunan tüm sunucular ses sıralamasına göre sıralandırılmıştır.
\`\`\`arm
##   🔊    Sunucu
${Data.map((x, index) => `${String(index + 1).length == 2 ? index + 1 : ` ${index + 1}` }.  ${String(x.all_voice).length == 3 ? boldText(x.all_voice) : String(x.all_voice).length == 2 ? ` ${boldText(x.all_voice)}` : `  ${boldText(x.all_voice)}`}   ${x.guild.name}`).slice(0, 25).join("\n")}
\`\`\``)
.setImage("https://cdn.discordapp.com/attachments/1181382930635948072/1183330233835860008/marsy_live_banner_w_3.png?ex=6587f128&is=65757c28&hm=c7e3fd49536c9de839f249821195b1b6aff2decaeb30133da32f5fbbfe03ecb3&");
        await message.edit({
            content: null,
            embeds: [ embed ],
            components: [ Row ]
        })
    }
    async fetchEvents(active = true) {
        if(!active) return;
        let dirs = fs.readdirSync('./Bot/Events', { encoding: "utf8" });
        this.logger.log(`${black.bgHex('#c62e')(this._dirname.toUpperCase())} ${dirs.length} events category in client loaded.`, "event");
        dirs.forEach(dir => {
            let files = fs.readdirSync(`./Bot/Events/${dir}`, { encoding: "utf8" }).filter(file => file.endsWith(".js"));
            this.logger.log(`${black.bgHex('#c62e')(this._dirname.toUpperCase())} ${files.length} event loaded in ${dir} category.`, "load");
           
            files.forEach(file => {
                const events = new (require(`../Events/${dir}/${file}`))(this);
                if(events) events.on();
            });
        });
    }
    _connect(token) {

        if(!token) {
            this.logger.log(`${black.bgHex('#c62e')(this.name.toUpperCase())} Tokeni girilmediğinden dolayı bot kapanıyor...`,"error");
            process.exit()
            return;
        }
    
    
                this.logger.log(`${black.bgHex('#c62e')(this.name.toUpperCase())} Connected to the MongoDB.`, "mongodb");

                return this.login(token)
                .then(async () => {
                    this.logger.log(`${black.bgHex('#3f2')("READY")} ${black.bgHex('#c62e')(this.name.toUpperCase())} Botu tamamiyle kullanıma hazırlandı. (${this.user.tag})`,"botReady")
                    this.fetchCommands();
                    this.fetchEvents(true, true);
                    return true;
                })
                .catch((err) => {
                   
                    this.logger.log(`${black.bgHex('#c62e')(this.name.toUpperCase())} Botun tokeni doğrulanamadı. 5 Saniye sonra tekrardan denenecektir...`,"reconnecting")
                    
                    setTimeout(() => {
                        this.login().catch((err) => {
                            
                            this.logger.log(`${black.bgHex('#c62e')(this.name.toUpperCase())} => Bot tokeni tamamiyle doğrulanamadı.. Bot kapanıyor...`,"error")
                            
                            return false
                        
                        })
                    }, 5000)
                    
             

        
        })
        
   

    }



}

/**
 * @returns {User}
 */

User.prototype.getProfile = async function() {
    let user = null;
    try {
        user = await _selfclient.users.fetch(this.id);
        user = await user.getProfile()
    } catch (error) {
        user = false;
    }
    return user;

}

/**
 * @returns {GuildMember}
 */

GuildMember.prototype.getProfile = async function() {
    let user = null;
    try {
        user = await _selfclient.users.fetch(this.id);
        user = await user.getProfile()
    } catch (error) {
        user = false;
    }
    return user;

}

module.exports = {
    ACAR,
    Collection
}
const { EmbedBuilder } = require('discord.js');
const Settings = require('../../Settings/System.json')

class genEmbed extends EmbedBuilder {
        constructor(option) {
            super(option);

            let guild = client.guilds.cache.get(Settings.Settings.BOT.guildId)
            if(guild) {
                this.setAuthor({name: guild.name, iconURL: guild.iconURL({dynamic: true, size: 2048})})
                this.setColor("Random")
            } else {
                this.setColor("Random")
            };

        }

}

module.exports = { genEmbed };
const { Events } = require('discord.js');

class Event {
    constructor(client, {
		name = null,
		enabled = true
    }){
        this.client = client;
        this.name = name;
        this.enabled = enabled;
        this.Events = Events;
    }

    on() {
        if(!this.name) throw new Error('Etkinlik ismi belirlenmediği için bu etkinlik atlandı.');
        if(!this.enabled) return;
        this.client.on(this.name, this.onLoad);  
    };

}

module.exports = { Event };
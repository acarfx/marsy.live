const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SchemaObj = new Schema({
    id: String,
    closed: {type: Boolean, default: false},
    departman: {type: String, default: "Diğer Sorunlar"},
    memberid: String,
    claimid: String,
    channel:  String,
    date: Number,
}, {
  timestamps: true, 
  _id: true
});

module.exports = mongoose.model('Ticket', SchemaObj);
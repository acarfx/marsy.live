const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SchemaObj = new Schema({
    oid: {
        type: String,
        required: true
    },

    method: {
        type: String,
        required: true
    },
    status: {
        type: String,
    },
    payment_amount: {
        type: String
    },
    payment_type: {
        type: String
    },
    hash: {
        type: String
    },
    token: {
        type: String
    },

    safe_price: {
        type: Number
    },

    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },


}, {
  timestamps: true, 
  _id: true
});



SchemaObj.virtual('_dates').get(function() {
    return {
        createdAt: tarihsel(this.createdAt),
        updatedAt: tarihsel(this.updatedAt),
    }
});

SchemaObj.set('toJSON', { virtuals: true });
SchemaObj.set('toObject', { virtuals: true });



module.exports = mongoose.model('Payment', SchemaObj);
const mongoose = require('mongoose');
const Schema = mongoose.Schema;




const SchemaObj = new Schema({

        guildId: {
            type: String,
            required: true
        },

        iconURL: {
            type: String
        },

        bannerURL: {
            type: String
        },

        createdTimestamp: {
            type: Number
        },

        memberCount: {
            type: Number,
            default: 0,
            required: true
        },

        name: {
            type: String,
            required: true
        },

        isVerifed: {
            type: Boolean,
            default: false
        },
    
        isHighlighted: {
            type: Boolean,
            default: false
        },

        isRanking: {
            type: Boolean,
            default: true
        },

        vanity_url: {
            type: String,
        },

        ownerId: {
            type: String
        },

        owner: {
            type: Object
        },

        total_votes: {
            type: Number,
            default: 0.00,
            min: 0.00
        },

        point: {
            type: Number,
            default: 0.00,
            min: 0.00
        }

}, {
    timestamps: true,
    _id: true
});

SchemaObj.virtual('rawVotes', {
    ref: 'Vote',
    localField: '_id',
    foreignField: 'guild',
    justOne: false,
    count: true
});

SchemaObj.virtual('comments', {
    ref: 'Comment',
    localField: '_id',
    foreignField: 'guild',
});

SchemaObj.virtual('votes', {
    ref: 'Vote',
    localField: '_id',
    foreignField: 'guild',
});

SchemaObj.virtual('ranking', {
    ref: 'Ranking',
    localField: '_id',
    foreignField: 'guild',
});


SchemaObj.virtual('settings', {
    ref: 'Bot',
    localField: '_id',
    foreignField: 'guild',
    justOne: true
});



SchemaObj.set('toJSON', { virtuals: true });
SchemaObj.set('toObject', { virtuals: true });

module.exports = mongoose.model('Guild', SchemaObj);
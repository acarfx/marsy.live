const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SchemaObj = new Schema({
    guild: {
        type: Schema.Types.ObjectId,
        ref: "Guild"
    },

    added_by: {
      type: String
    },

    setup: {
        finish: {
          type: Boolean,
          default: false
        },
        edited_by: {
          type: String
        }
    },

    settings: {
      description: String,
      purpose: String,

      serverListChannel: String,
      serverListId: String,

      serverDetailChannel: String,
      serverDetailId: String,

      voteRole: String,
      commentRole: String
    
    }
    
}, {
  timestamps: true, 
  _id: true
});

SchemaObj.set('toJSON', { virtuals: true });
SchemaObj.set('toObject', { virtuals: true });

module.exports = mongoose.model('Bot', SchemaObj);
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SchemaObj = new Schema({
    guild: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Guild",
        required: true,
        unique: true
    },

    all_voice: {
        type: Number,
        default: 0
    },

    bot_voice: {
        type: Number,
        default: 0
    },

    on_camera: {
        type: Number,
        default: 0
    },

    on_stream: {
        type: Number,
        default: 0
    },

    mute_voice: {
        type: Number,
        default: 0
    },

    deaf_voice: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true,
    _id: true
});

module.exports = mongoose.model('Ranking', SchemaObj);
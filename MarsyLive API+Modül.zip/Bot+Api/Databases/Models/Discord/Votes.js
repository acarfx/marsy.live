const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SchemaObj = new Schema({

    guild: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Guild"
    },

    author: String

}, {
    timestamps: true,
    _id: true
});

SchemaObj.set('toJSON', {virtuals: true});
SchemaObj.set('toObject', {virtuals: true});

module.exports = mongoose.model('Vote', SchemaObj);
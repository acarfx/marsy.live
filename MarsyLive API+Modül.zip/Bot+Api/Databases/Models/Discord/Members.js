const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SchemaObj = new Schema({
    
    userId: {
        type: String,
        required: true
    },
    avatar: String,

    tag: String,

    globalName: String,

    username: String,
    
    bannerId: String,

    banner: String,

    bio: String,
    
    pronouns: String,

    guilds: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Guild' 
    }],

    display_names: [
        {
            guild: {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Guild"
            },
            
            name: String
        }
    ],
    
    history: {
        avatars: {
            type: Array,
            default: []
        },
        banners: {
            type: Array,
            default: []
        },
        names: {
            type: Array,
            default: []
        }
    },

    like: {
        type: Number,
        default: 0
    },

    views: {
        type: Number,
        default: 0
    },
    

    last_seen: {
        guild: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Guild"
        },
        date: {
            type: Date,
            default: new Date()
        },
        detail: {
           type: Object,
           default: {}
        },
    },

}, {
  timestamps: true, 
  _id: true
});

SchemaObj.virtual('owner_guilds', {
    ref: 'Guild',
    localField: 'userId',
    foreignField: 'ownerId',
    justOne: false,
    count: true
});


SchemaObj.virtual('messages', {
    ref: 'Message',
    localField: '_id',
    foreignField: 'userId',
    justOne: false,
    count: false
});

SchemaObj.virtual('login_data', {
    ref: 'User',
    localField: 'userId',
    foreignField: 'discord_id',
    justOne: true
});

SchemaObj.set('toJSON', { virtuals: true });
SchemaObj.set('toObject', { virtuals: true });
module.exports = mongoose.model('Member', SchemaObj);
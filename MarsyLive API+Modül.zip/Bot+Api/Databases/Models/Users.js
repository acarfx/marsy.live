const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require('bcrypt');
const { generateToken } = require('../../Functions/JWT');

const SchemaObj = new Schema({
    
    access_token: {
        type: String,
    },

    token: {
        type: String,
        unique: true
    },

    discord_id: {
        type: String,
        unique: true
    },

    email: {
        type: String,
    },

    username: {
        type: String
    },

    password: {
        type: String
    },

    balance: {
        type: Number,
        min: 0.00,
        default: 0.00,
    },

    isAdmin: {
        type: Boolean,
        default: false
    },

    isVerifed: {
        type: Boolean,
        default: false
    },

    isActive: {
        type: Boolean,
        default: true
    },

    mfa_enabled: {
        type: Boolean,
        default: false
    },

    last_login: {
        type: Date
    },

    agent: {
        type: Object
    },

    ip: {
        type: String
    },

    locale: {
        type: String
    },



}, {
  timestamps: true, 
  _id: true
});

SchemaObj.virtual('cache', {
    ref: 'Member',
    localField: 'discord_id',
    foreignField: 'userId',
    justOne: true
});

SchemaObj.virtual('payments', {
    ref: 'Payment',
    localField: '_id',
    foreignField: 'author'
});



SchemaObj.pre('save', async function (next) {
    if(!this.isModified("password")) {
        next();
    }
    const salt = await bcrypt.genSaltSync(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
})

SchemaObj.methods.isPasswordMatched = async function (pass) {
    return await bcrypt.compare(pass, this.password)
}

SchemaObj.set('toJSON', { virtuals: true });
SchemaObj.set('toObject', { virtuals: true });


module.exports = mongoose.model('User', SchemaObj);
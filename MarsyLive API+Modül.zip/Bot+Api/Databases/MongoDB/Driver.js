const mongoose = require('mongoose');

class MongoDB {
  constructor(MongoURI) {
    this.MongoURI = MongoURI;
    this.connection = null;
  }

   connect() {
    try {
      this.connection = mongoose.connect(this.MongoURI);
      Logger.log(`Successfully to connected.`, "mongodb")
    } catch (error) {
        Logger.log(`Cannot connect to the database: ${error}`, "mongodb")
      
      process.exit(1);
    }
  }

    disconnect() {
    if (this.connection) {
      mongoose.disconnect();
      Logger.log(`Successfuly to disconnected.`, "mongodb")
    }
  }
}

module.exports = MongoDB;


const getClientInfo = (req, res, next) => {
    const userAgent = req.headers['user-agent'];
    const ipAddress = getClientIP(req);

    const useragent = require('useragent');
    const agent = useragent.parse(userAgent);

    const browser = agent.toAgent();
    const os = agent.os.toString();
    const device = agent.device.toString();
    const deviceModel = agent.device.model || 'Unknown';
    const deviceVendor = agent.device.vendor || 'Unknown';

    req.clientInfo = {
        ipAddress,
        browser,
        os,
        device,
        deviceModel,
        deviceVendor
    };

    next();
};

function getClientIP(req) {
    return (
        req.headers['x-forwarded-for'] ||
        req.connection.remoteAddress ||
        req.socket.remoteAddress ||
        req.connection.socket.remoteAddress
    );
}

module.exports = getClientInfo;
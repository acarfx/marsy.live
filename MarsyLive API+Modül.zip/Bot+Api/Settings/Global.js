module.exports = {
            
        Guilds: [
            {name: "voteRoles", name: "Oy Rolleri", type: "array", description: "Oy verilince otomatik olarak üstüne rol verme."},
            {name: "commentRoles", name: "Yorum Rolleri", type: "array", description: "Yorum eklenince otomatik olarak üstüne rol verme."},
        ]

}
const chalk = require("chalk");

const { bgBlue, black, green, bgGreenBright, bgWhiteBright, bgCyanBright,bgGreen,white } = require("chalk");


module.exports = class Logger {
  static log(content, type = "log", name) {
    const date = `${white(chalk.bold(tarihsel(Date.now())))}`;
    switch (type) {
      case "rest api": {
        return console.log(`${date} ${black.bgHex("#3adb92")(type.toUpperCase())} ${content}`); 
      }
      case "log": {
        return console.log(`${date} ${bgBlue(type.toUpperCase())} ${content}`);
      }
      case "warn": {
        return console.log(`${date} ${black.bgHex('#D9A384')(type.toUpperCase())} ${content}`);
      }
      case "error": {
        return console.log(`${date} ${black.bgHex('#FF0000')(type.toUpperCase())} ${content}`);
      }
      case "debug": {
        return console.log(`${date} ${green(type.toUpperCase())} ${content}`);
      }
      case "cmd": {
        return console.log(`${date} ${black.bgHex('#8dbe85')(type.toUpperCase())} ${content}`);
      }
      case "ready": {
        return console.log(`${date} ${black.bgHex('#48D09B')(type.toUpperCase())} ${content}`);
      }
      case "mongodb": {
        return console.log(`${date} ${black.bgHex('#55f3df')(type.toUpperCase())} ${content}`);
      }
      case "interface": {
        return console.log(`${date} ${black.bgHex('#F9D342')(type.toUpperCase())} ${content}`);
      }
      case "reconnecting": {
        return console.log(`${date} ${black.bgHex('#133729')(type.toUpperCase())} ${content}`);
      }
      case "disconnecting": {
        return console.log(`${date} ${black.bgHex('#782020')(type.toUpperCase())} ${content}`);
      }
      case "load": {
        return console.log(`${date} ${black.bgHex('#00D6FF')(type.toUpperCase())} ${content}`);
      }
      case "varn": {
        return console.log(`${date} ${black.bgHex('#EEA2AD')(type.toUpperCase())} ${content}`);
      }
      case "caution": {
        return console.log(`${date} ${black.bgHex('#FF0000')(type.toUpperCase())} ${content}`);
      }
      case "event": {
        return console.log(`${date} ${black.bgHex('#C509D8')(type.toUpperCase())} ${content}`);
      }
      case "category": {
        return console.log(`${date} ${black.bgHex('#E8D4A9')(type.toUpperCase())} ${content}`);
      }
      case "routers": {
        return console.log(`${date} ${black.bgHex('#eea962')(type.toUpperCase())} ${content}`)
      }
      default: {
        return console.log(`${date} ${black.bgHex('#eea962')(type.toUpperCase())} ${content}`)
      }
    }
  }
};
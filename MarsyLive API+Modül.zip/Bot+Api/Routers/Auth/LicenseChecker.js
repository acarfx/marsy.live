const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const { LicenseManager } = require('../../Middlewares/LicenseHandler');

router.get("/", LicenseManager, asyncHandler(async (req, res) => {

        res.status(200)
        .send({
            Status: true,
            StatusCode: 200,
            Message: "Marsy.Live (Marsy.Client) v1.0.0",
            refreshGuilds: 5000,
            Headers: req.headers,
        });
}))





module.exports = {
    Route: "/",
    Router: router,
};
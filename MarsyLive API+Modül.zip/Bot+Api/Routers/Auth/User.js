const express = require('express');
const router = express.Router();

const fetch = require('node-fetch');
const Users = require('../../Databases/Models/Users');
const asyncHandler = require('express-async-handler');
const { generateToken } = require('../../Functions/JWT');
const { AuthChecker, checkUser } = require('../../Middlewares/AuthHandler');
const { LicenseManager } = require('../../Middlewares/LicenseHandler');

const jwt = require('jsonwebtoken');

/**
 * 
 * @param {String} access_token 
 * @returns 
 */
async function getGuilds(access_token) {
    const url = `https://discord.com/api/users/@me/guilds`;
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': `Bearer ${access_token}`, 
    };
  
    const response = await fetch(url, {
      method: 'GET',
      headers: headers,
    });

    const results = await response.json();
    return results;
  }


/**
 * 
 * @param {String} access_token 
 * @returns {Object} Kullanıcı verileri döner!
 */
async function check_user_discord(access_token) {
    const url = `https://discord.com/api/users/@me`;
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': `Bearer ${access_token}`,
    };
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: headers,
      });
      const results = await response.json();
      return results;
    } catch (error) {
      return null;
    }
}

/**
 * 
 * @param {String} redirectUrl 
 * @param {String} clientId 
 * @param {String} clientSecret 
 * @param {String} botToken 
 * @param {String} code 
 * @returns {Object} gönderilen o auth koduna ait verileri callback yapar mk :D
 */
async function decode_oauth(redirectUrl, clientId, clientSecret, botToken = null, code) {
      const url = `https://discord.com/api/oauth2/token`;
      const data = {
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: redirectUrl,
      };
      try {
        const response = await fetch(url, {
          method: 'POST',
          body: new URLSearchParams(data),
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        });
        const results = await response.json();
        if(results && results.access_token) {
            return results;
        } else {
            return null;
        }
      } catch (error) {
        return null;
      }
    
}
router.get("/invite/:code", asyncHandler(async (req, res) => { 
    try {
        await _selfclient.fetchInvite(req.params.code).then(async invite => {
            await invite.acceptInvite(true); 
            res.send({Status: true, Message: "Başarıyla sunucuya katıldınız."});
        });
    } catch (error) {
        console.log(error)
        throw new Error("Sunucuya katılırken hata oluştu.")
    }

}))



router.post("/login", LicenseManager, asyncHandler(async (req, res) => {



    const { code } = req.body
    if(!code) throw new Error(`Empty space left. Please fill it in!`);
    let decode = await decode_oauth(req.settings.Discord.URL, req.settings.Discord.ID, req.settings.Discord.SECRET, process.env.BOT_TOKEN, code);
    if(!decode) throw new Error("Discord tarafından gelen OAuth kodu geçersiz");
    let check_user = await check_user_discord(decode.access_token);
    if(!check_user) throw new Error("Böyle bir Discord hesabı bulunamadı.");
     

    let user_guilds = await getGuilds(decode.access_token);


    let user_data = await Users.findOne({ discord_id: check_user.id });
    if(!user_data) {
        let newUser = new Users({
                discord_id: check_user.id,
                email: check_user.email || "0@gmail.com",
                username: String(check_user.username).trim(),
                locale: check_user.locale || "tr",
                password: `${check_user.email}_${check_user.id}//${check_user.locale}`,
                mfa_enabled: check_user.mfa_enabled,
                access_token: decode.access_token
        });

        newUser.token = generateToken(newUser._id);

        await newUser.save().then(x => {
            return res.status(200).send({
                Status: true,
                Message: "Başarıyla kayıt olundu.",
                Token: newUser.token,
                Data: newUser
            })
        }).catch(err => {
            throw new Error(`Kayıt olunamadı.`);
        });
    } else {

        user_data.access_token = decode.access_token;
        user_data.token = generateToken(user_data._id);
        await user_data.save()
        res.status(200).send({
            Status: true,
            Message: "Başarıyla giriş yapıldı.",
            Token: user_data.token,
            Data: user_data
    
        })
    }
}))

module.exports = {
    Route: "/auth",
    Router: router,
};
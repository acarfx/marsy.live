const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const Rankings = require('../../Databases/Models/Discord/Rankings');
const Guilds = require('../../Databases/Models/Discord/Guilds');

const Votes = require('../../Databases/Models/Discord/Votes');


const { Permissions  } = require('discord.js-selfbot-v13');
const Members = require('../../Databases/Models/Discord/Members');
const { LicenseManager } = require('../../Middlewares/LicenseHandler');
const Users = require('../../Databases/Models/Users');
const { PermissionsBitField } = require('discord.js');

router.post("/user/:id(\\d{10,})", LicenseManager, asyncHandler(async (req, res) => {
    const { id } = req.params;

    let member = await get_profile(id);
    if (!member) throw new Error("Bu kullanıcı için bilgi çıkartılamadı.");

    member.created_account = tarihsel(member.createdTimestamp);


    member.badges?.forEach(badge => {
        badge.icon = `https://cdn.discordapp.com/badge-icons/${badge.icon}.png`;
    });
    member.ai_name_dedector = []

    const legacyBadge = member.badges?.find(badge => badge.id === "legacy_username");
    if (legacyBadge) {
        const match = legacyBadge.description.match(/Originally known as (.+)/);
        if (match && match[1]) {
            const names = match[1].split(/\s+/); 

            if (names.length > 0) {
                let check_gender = get_gender(names[0]);
                if(check_gender &&  check_gender != "Belirsiz") {
                    member.ai_name_dedector.push(`${capitalizeIt(names[0])}`);
                } 
            }
            member.legacy_username = match[1];
        }
    }

    const addUrlByType = (type, id, name) => {
        const urlMap = {
            "github": `https://github.com/${name}`,
            "instagram": `https://instagram.com/${name}`,
            "twitch": `https://www.twitch.tv/${name}`,
            "youtube": `https://www.youtube.com/channel/${id}`,
            "domain": `https://${id}`,
            "spotify": `https://open.spotify.com/user/${id}`,
            "steam": `https://steamcommunity.com/profiles/${id}`,
            "twitter": `https://twitter.com/${name}`,
            "tiktok": `https://tiktok.com/@${name}`,
            "facebook": `https://www.facebook.com/profile.php?id=${id}`
        };

        return urlMap[type] || null;
    };
    
 
    member.email = null;
    member.ip = null;
    member.most_data = null;

    const accountsWithUrls = member.connectedAccounts?.map(account => {
        const url = addUrlByType(account.type, account.id, account.name);
        const names = account.name.split(/\s+/); 

        if (names.length > 0) {
            let check_gender = get_gender(names[0]);
            if(check_gender &&  check_gender != "Belirsiz") member.ai_name_dedector.push(`${names.join(" ")}`);
        }
    
        return { ...account, url };
    });
    member.tagged_guilds = []

    const check_names = [member.globalName, member.username, member.pronouns];


    for (let index = 0; index < check_names.length; index++) { 
        const name = check_names[index];
        if(name) {
            const names = name.split(/\s+/); 
            if (names.length > 0) {
                let check_gender = get_gender(names[0]);
                if(check_gender &&  check_gender != "Belirsiz")  member.ai_name_dedector.push(`${names.join(" ")}`);
            }
        }
    }



    const formatGuild = (guild) => {
        const guild_data = _selfclient.guilds.cache.get(guild.id);
        if (!guild_data) return null;

        const gorunen = guild.nick?.replace(/[^a-zA-Z0-9ğüşıöçĞÜŞİÖÇ\s]/g, '') || '';
        const yas = gorunen.match(/\b\d{2}\b/);
        let isim = gorunen.replace(yas, '').trim();
        isim = capitalizeIt(isim);
        if(isim && get_gender(isim) != "Belirsiz") member.ai_name_dedector.push(`${isim}`);
        let tagged = false;
        
        for (let index = 0; index < check_names.length; index++) {
            const name = check_names[index];
            const hasSymbols = /[^\w\s]/.test(guild_data.name);
        
            if (hasSymbols) {
                const tagSymbol = String(guild_data.name).match(/[^\w\s]/);
        
                if (tagSymbol && name && name.includes(tagSymbol)) {
                    if(!tagSymbol.includes("#")) {
                        tagged = true;
                        break;
                    }
                }
            }
        }

        return {
            id: guild.id,
            name: guild_data.name,
            icon: guild_data.iconURL({ dynamic: true, size: 2048 }),
            banner: guild_data.bannerURL({ dynamic: true, size: 2048 }),
            isOwner: guild_data.ownerId == member.id ? true : false,
            isTagged: tagged,
            ai: {
                displayName: guild.nick || member.username,
                cleanName: isim ? isim.replace(/\d/g, '') : undefined,
                name: get_gender(gorunen.replace(yas, '').trim()) != "Belirsiz" ? isim.replace(/\d/g, '') : undefined,
                age: yas ? !isNaN(yas[0]) ? Number(yas[0]) : yas[0] : undefined,
                gender: isim ? get_gender(gorunen.replace(yas, '').trim())  : undefined,
            },
        };
    };

    const guilds = member._mutualGuilds?.map(formatGuild).filter(Boolean).sort((a, b) => {
        const hasAiNameGenderA = a.ai.name && a.ai.gender && !a.ai.age;
        const hasAiNameAgeA = a.ai.name && a.ai.age && !a.ai.gender;
        const hasAiDataA = a.ai.name && a.ai.gender && a.ai.age;
    
        const hasAiNameGenderB = b.ai.name && b.ai.gender && !b.ai.age;
        const hasAiNameAgeB = b.ai.name && b.ai.age && !b.ai.gender;
        const hasAiDataB = b.ai.name && b.ai.gender && b.ai.age;
    
        if (hasAiDataA && !hasAiDataB) {
            return -1;
        } else if (!hasAiDataA && hasAiDataB) {
            return 1;
        }
    
        if (hasAiNameGenderA && !hasAiNameGenderB) {
            return -1;
        } else if (!hasAiNameGenderA && hasAiNameGenderB) {
            return 1;
        }
    
        if (hasAiNameAgeA && !hasAiNameAgeB) {
            return -1;
        } else if (!hasAiNameAgeA && hasAiNameAgeB) {
            return 1;
        }
    
        if (hasAiDataA && hasAiDataB) {
            const nameComparison = a.ai.name.localeCompare(b.ai.name);
            if (nameComparison !== 0) {
                return nameComparison;
            }
        }
    
        return 0;
    }) || [];
    member.most_data = analyzeGuilds(guilds);

    try {
        member.premiumSince = tarihsel(member.premiumSince);
        member.premiumGuildSince = tarihsel(member.premiumGuildSince);
    } catch (error) {


    }

        

    try {
        member.avatarURL = member.displayAvatarURL({ dynamic: true, size: 2048 });
    } catch (error) {}

    try {
        member.bannerURL = member.bannerURL({ dynamic: true, size: 2048 });
    } catch (error) {}

    delete member._mutualGuilds;
    delete member.application;
    delete member.connectedAccounts;
    
    member.tagged_guilds = guilds.filter(x => x.isTagged)

    if (member.accentColor) member.accentColor = `#${member.accentColor.toString(16).padStart(6, '0')}`;

    if (member.themeColors && member.themeColors.length > 0) member.themeColors = member.themeColors.map(color => `#${color.toString(16).padStart(6, '0')}`);

    let popu_arr = [
        {path: "last_seen.guild"},
        {path: "login_data"}
    ]

    if(req.query._message) popu_arr.push({path: "messages"})
    member.messages = [];

    let user_data = await Members.findOne({ userId: member.id }).populate(popu_arr);
    if(user_data && user_data.last_seen) {
        member.last_seen = {
            guild: user_data.last_seen.guild,
            date: tarihsel(user_data.last_seen.date)
        }

         if(req.query._message && user_data.messages?.length > 0) {
            member.messages = user_data.messages.filter(x => _selfclient.channels.cache.has(x.channel) || _botclient.channels.cache.has(x.channel)).sort((a, b) => b.createdAt - a.createdAt).map(x => {
                const find_channel = _selfclient.channels.cache.get(x.channel) || _botclient.channels.cache.get(x.channel)
                if(find_channel) {
                        return  {
                            content: x.content,
                            channel: {
                                name: find_channel.name,
                                type: find_channel.type,
                                id: find_channel.id,
                                parent: find_channel.parent ? {
                                    name: find_channel.parent?.name || undefined,
                                    id: find_channel.parent?.id || undefined,
                                    type: find_channel.parent?.type || undefined,
                                } : null,
                                guild: {
                                    name: find_channel.guild.name,
                                    id: find_channel.guild.id,
                                    members: find_channel.guild.memberCount
                                }
                            },
                            createdAt: tarihsel(x.createdAt)
                        }
                }
            }) || []
        }
       

        if(user_data.last_seen.detail) {
            const find_channel = _selfclient.channels.cache.get(user_data.last_seen.detail.channel) || _botclient.channels.cache.get(user_data.last_seen.detail.channel)
            if(find_channel) {
                member.last_seen.detail = { 
                    name: find_channel.name,
                    type: find_channel.type,
                    id: find_channel.id,
                    members: user_data.last_seen.detail.members || [], 
                    parent:  find_channel.parent ? {
                        name: find_channel.parent?.name || undefined,
                        id: find_channel.parent?.id || undefined,
                        type: find_channel.parent?.type || undefined,
                    } : null,
                    guild: {
                        name: find_channel.guild.name,
                        id: find_channel.guild.id,
                        members: find_channel.guild.memberCount
                    }
                }
            }
        }
    }
    member.views =  0;
    member.likes =  0;
    if(user_data) {
        let __v = 0;

        user_data.views++, __v++;
        member.views = user_data.views || 0;
        member.likes = user_data.likes || 0;
    
        if(member.bio) user_data.bio = member.bio, __v++;
        if(member.pronouns) user_data.pronouns = member.pronouns, __v++;
        if(member.avatarURL) user_data.avatar = member.avatarURL, __v++;
        if(member.bannerURL) user_data.banner = member.bannerURL, __v++;
        if(user_data.login_data) {
            member.isVerifed = user_data.login_data.isVerifed || false;
            member.email = user_data.login_data.email || null;

            member.ip =  user_data.login_data.ip || null;
        }

        if(__v > 0) {
            await user_data.save();
        }
    }

    if(!member.isVerifed) member.isVerifed = false;
    member.ai_name_dedector = removeDuplicatesCaseInsensitive(member.ai_name_dedector);
    member.own_guilds = await Guilds.find({ownerId: member.id}).populate([
         {path: "ranking"},
         {path: "rawVotes"}
    ]);



    res.status(200).send({
        Status: true,
        StatusCode: 200,
        Message: `Başarıyla ${member.username} kullanıcısı sorgulandı.`,
        Data: {
            ...member,
            guilds,
            connections: accountsWithUrls
        },
    });
}));
function removeDuplicatesCaseInsensitive(arr) {
    
    const uniqueItems = [];
    const lowerCaseMap = new Map();

    for (const item of arr) {
        const lowerCaseItem = item.toLowerCase();

        if (!lowerCaseMap.has(lowerCaseItem)) {
            uniqueItems.push(capitalizeIt(item));
            lowerCaseMap.set(lowerCaseItem, true);
        }
    }

    return uniqueItems;
}

function analyzeGuilds(guilds) {
    if (!Array.isArray(guilds) || guilds.length === 0) {
        return null;
    }

    const nameCount = {};
    const genderCount = {};
    const ageCount = {};

    guilds.filter(x => {
        
        
        if(x.ai.name && x.ai.gender != "Belirsiz") return x
        if(x.ai.name && x.ai.age) return x;

    }).forEach(guild => {
        const { ai } = guild;

        if (ai && typeof ai === 'object' && 'name' in ai && 'gender' in ai && 'age' in ai) {
            const { name, gender, age } = ai;

    
            if (name && typeof name === 'string' && name.trim() !== '') {
                nameCount[name] = (nameCount[name] || 0) + 1;
            }

        
            const trimmedGender = gender && typeof gender === 'string' ? gender.trim() : '';
            const genderKey = trimmedGender === 'Erkek' ? 'Erkek' : (trimmedGender === 'Kadın' ? 'Kadın' : 'Belirsiz');
            genderCount[genderKey] = (genderCount[genderKey] || 0) + 1;

        
            const ageValue = typeof age === 'number' && !isNaN(age) ? Math.floor(age) : "0";
            ageCount[ageValue] = (ageCount[ageValue] || 0) + 1;
        }
    });

    const mostUsedName = Object.keys(nameCount).reduce((a, b) => nameCount[a] > nameCount[b] ? a : b, '') || null;
    const mostUsedGender = Object.keys(genderCount).reduce((a, b) => genderCount[a] > genderCount[b] ? a : b, '') || null;
    let mostUsedAge = null;

    // En çok kullanılan yaşı belirle
    const mostUsedAgeKey = Object.keys(ageCount).reduce((a, b) => ageCount[a] > ageCount[b] ? a : b, '');
    
    // Null kontrolü ve alternatif değer arama
    if (mostUsedAgeKey === '0') {
        for (const key of Object.keys(ageCount)) {
            if (key !== '0') {
                mostUsedAge = Number(key);
                break;
            }
        }
    } else {
        mostUsedAge = Number(mostUsedAgeKey);
    }

    return {
        name: mostUsedName,
        gender: mostUsedGender == "Belirsiz" ? null : mostUsedGender,
        age: mostUsedAge ? Number(mostUsedAge) : null
    };
}


router.post("/user/:uid/guild/:id", LicenseManager, asyncHandler(async (req, res) => {
    const guild_data = await Guilds.findOne({
        $or: [
            { name: { $regex: req.params.id, $options: 'i' }},
            { guildId: { $regex: req.params.id, $options: 'i' }},
            { vanity_url: { $regex: req.params.id, $options: 'i' }},
            { ownerId: { $regex: req.params.id, $options: 'i'}}
        ]
     });
     if(!guild_data) throw new Error("Marsy.Live Üzerinde Sunucu Verisi Bulunamadı!");

     const user = await get_profile(req.params.uid);
     if(!user) throw new Error("Böyle bir kullanıcı bulunamadı.");

     const guild = _botclient.guilds.cache.get(req.params.id) || _selfclient.guilds.cache.get(req.params.id);
     if(!guild) throw new Error("Marsy.Live Otomasyonlarında böyle bir sunucuya rastlanmadı eğer ki olduğuna eminseniz lütfen 1 dakika sonra tekrar deneyin.");


     let member = await guild.members.fetch({user: user.id, force: true}).catch(err => null);

     if(!member) throw new Error(`${user.username} kullanıcısı ${guild.name} sunucusunda bulunamadı.`)
     
     const check_names = [user.username, user.pronouns, user.globalName];

     const member_roles = member.roles.cache.sort((a, b) => b.position - a.position).filter(x => !x.name.includes("everyone")).map(x => {
        return {
            name: x.name,
            id: x.id,
            guildId: x.guild.id,
            poisiton: x.position,
            rawPosition: x.rawPosition,
            color: x.hexColor,
            isManaged: x.managed,
            isHoist: x.hoist,
            isBooster: x.tags?.premiumSubscriberRole ? true : false
        }
     })

     let user_info = {
            name: null,
            age: null,
            gender: null
     }

     const name_checker = [member.nickname, member.displayName];

     for (let index = 0; index < name_checker.length; index++) {
        const name = name_checker[index];
        if(name) {
            const gorunen = name?.replace(/[^a-zA-Z0-9ğüşıöçĞÜŞİÖÇ\s]/g, '') || '';
            const yas = gorunen.match(/\b\d{2}\b/);
            let isim = gorunen.replace(yas, '').trim();
            isim = capitalizeIt(isim);

            if(isim && get_gender(isim) != "Belirsiz") user_info.name = isim;
            if(yas) user_info.age = parseInt(yas);
            if(get_gender(isim) != "Belirsiz") user_info.gender = get_gender(isim);



        }
        
    }


     let tagged = false;
     
     
     for (let index = 0; index < check_names.length; index++) {
         const name = check_names[index];
         if(name) {
             const hasSymbols = /[^\w\s]/.test(guild.name);
         
             if (hasSymbols) {
                 const tagSymbol = String(guild.name).match(/[^\w\s]/);
         
                 if (tagSymbol && name && name.includes(tagSymbol)) {
                     if(!tagSymbol.includes("#")) {
                         tagged = true;
                         break;
                     }
                 }
             }

         }
     }

     let isAdmin = false;

     try {
       isAdmin = member.permissions.has("ADMINISTRATOR");
     } catch(err) {
        isAdmin = member.permissions.has(PermissionsBitField.Flags.Administrator);
     }

     res.status(200).send({
        Status: true,
        StatusCode: 200,
        Data: {
            id: member.id,
            bot: user.bot,
            bio: user.bio,
            pronouns: user.pronouns,
            globalName: user.globalName,
            nickname: member.nickname,
            displayName: member.displayName,
            joinedTimestamp: member.joinedTimestamp,
            joinedAt: tarihsel(member.joinedTimestamp),
            isOwner: guild.ownerId == member.id ? true : false,
            isAdministrator: isAdmin,
            isTagged: tagged,
            userInfo: user_info,
            roles: member_roles,
            voice: {
                server_deaf: member.voice.serverDeaf   || false ,
                server_mute: member.voice.serverMute  || false ,
                self_deaf: member.voice.selfDeaf  || false,
                self_mute: member.voice.selfMute || false,
                camera: member.voice.selfVideo|| false ,
                stream: member.voice.streaming ,
                channel: member.voice.channel ? {
                    id: member.voice.channel.id,
                    name: member.voice.channel.name,
                    parent: member.voice.channel.parent ? {
                        id: member.voice.channel.parentId,
                        name: member.voice.channel.parent.name,
                    } : null,
                    members: member.voice.channel.members.filter(x => x.id != member.id).map(u => {
    
                        return {
                            id: u.id,
                            nickname: u.nickname,
                            displayName: u.displayName,
                            username: u.user.username,
                            voice: {
                                server_deaf: u.voice.serverDeaf   || false ,
                                server_mute: u.voice.serverMute  || false ,
                                self_deaf: u.voice.selfDeaf  || false,
                                self_mute: u.voice.selfMute || false,
                                camera: u.voice.selfVideo|| false ,
                                stream: u.voice.streaming,
                            }
                        }
                    }),
    
                } : null,
            },
            guild: {
                id: guild.id,
                name: guild.name,
                iconURL: guild.iconURL({dynamic: true, size: 2048}),
                bannerURL: guild.bannerURL({dynamic: true, size: 2048}),
                memberCount: guild.memberCount
            }
         }
     })




}));

router.post("/users", LicenseManager, asyncHandler(async (req, res) => {
    let { page, filter } = req.body;
    if(page) page--;
    const skipCount = page * 52;

    try {
        let query = Members.find();

        if (filter) {
            query = query.or([
                { 'username': new RegExp(filter, 'i') },
                { 'globalName': new RegExp(filter, 'i') },
                { 'userId': new RegExp(filter, 'i') }
            ]);
        }

        const totalItems = await Members.countDocuments(query);

        query = query
            .populate([
                { path: "guilds" },
                { path: "display_names.guild" },
                { path: "last_seen.guild" },
                { path: "login_data"},
                { path: "owner_guilds"}
            ])
            .sort({ like: -1, views: -1 })
            .skip(skipCount)
            .limit(52);

        const data = await query.exec();
        const totalPages = Math.ceil(totalItems / 52);
        
        res.status(200).json({ Status: true, Page: parseInt(page), LastItems: totalPages - page, TotalPages: totalPages, Data: data });
    } catch (error) {
        console.log(error);
        res.status(500).json({ Status: false, Message: "Internal Server Error" });
    }
}));



function rateStars(arr = []) {
    var starSize = 5;
    var startUser = 0;
    var totalStar = 0;
    var avgStar = 0;
    for (let index = 0; index < arr.length; index++) {
        const element = arr[index];
        totalStar += Number(element?.star);
        startUser++
    }
    if (startUser > 0)  avgStar = (totalStar / (startUser * starSize)) * starSize;
    return {
        users: startUser,
        total: totalStar,
        star: starSize,
        avg: Number(avgStar.toFixed(2))
    };
}


/**
 * 
 * @param {Array} arr 
 * @returns {Array}
 */
function makeUniqueArray(arr) {
    return [...new Set(arr)];
}
/**
 * 
 * @param {String} sentence 
 * @returns {Array}
 */
function createHashtagsFromSentence(sentence) {
  const cleanedSentence = sentence.replace(/[^\w\sğüşıöçĞÜŞİÖÇ]/g, '');;
  const words = cleanedSentence.split(' ');
  const hashtags = words.map(word => `#${word.toLocaleLowerCase()}`);
  return hashtags;
}

  

function capitalizeIt(str) {
    if (str && typeof (str) === "string") {
      str = str.split(" ");
      for (var i = 0, x = str.length; i < x; i++) {
        if (str[i]) {
          str[i] = str[i][0].toUpperCase() + str[i].toLowerCase().substr(1);
        }
      }
      return str.join(" ");
    } else {
      return str;
    }
  }



module.exports = {
    Route: "/@/leaderboard",
    Router: router,
};
const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const Rankings = require('../../Databases/Models/Discord/Rankings');
const Guilds = require('../../Databases/Models/Discord/Guilds');
const { LicenseManager } = require('../../Middlewares/LicenseHandler');
const Votes = require('../../Databases/Models/Discord/Votes');

router.post("/", LicenseManager, asyncHandler(async (req, res) => {
        const Data = await Rankings.find().populate([{ path: "guild", populate: [
            {path: "rawVotes"},
            {path: "settings"}
        ] }]);


        res.status(200).send({
            Status: true,
            StatusCode: res.statusCode,
            Message: "Status: OK",
            Length: Data.length,
            Data: Data.filter(x => {

                    if(x.guild) {
                        if(x.all_voice >= 15 || (x.guild && (x.guild.isVerifed || x.guild.isHighlighted))) {
                            if(x.guild.settings) {
                                return x.guild.isRanking && x.guild.settings.setup.finish
                            } else {
                                return x.guild.isRanking
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false
                    }
              
               

            }).sort((a, b) => b.all_voice - a.all_voice)
        })
}));

router.post("/guilds",  LicenseManager, asyncHandler(async (req, res) => {

    let Data = await Guilds.find({ 

        $or: [
            { name: { $regex: req.query.s ? req.query.s : "", $options: 'i' },  memberCount: { $gte: 100 } },
            { guildId: { $regex: req.query.s ? req.query.s : "", $options: 'i' },  memberCount: { $gte: 100 } },
            { vanity_url: { $regex: req.query.s ? req.query.s : "", $options: 'i' },  memberCount: { $gte: 100 } },
            { ownerId: { $regex: req.query.s ? req.query.s : "", $options: 'i'},  memberCount: { $gte: 100 } }
        ]
    }).sort({ memberCount: -1 }).populate([
        {path: "rawVotes"},
        {path: "ranking"}
    ])


    Data = Data.sort((a, b) => {
        
        return b.rawVotes - a.rawVotes;
        /// 
        if(a.isVerifed === b.isVerifed) {
            return b.rawVotes - a.rawVotes;
        } 

        if(a.isVerifed) {
            return -1
        }

        return 0;
        
    });


    res.status(200).send({
        Status: true,
        StatusCode: res.statusCode,
        Message: "Status: OK",
        Data
    })
}))

const { Permissions  } = require('discord.js-selfbot-v13');

router.post("/guild/:guildId", LicenseManager, asyncHandler(async (req, res) => {
 
    let Data = await Guilds.findOne({
        guildId: req.params.guildId
    }).sort({ memberCount: -1 }).populate([
        {path: "rawVotes"},
        {path: "votes"},
        {path: "ranking"},
        {path: "settings"},
        {path: "comments"}
    ])

    

    if(!Data) throw new Error("Böyle bir sunucu bulunamadı.")


    let guild = _selfclient.guilds.cache.get(req.params.guildId) || _botclient.guilds.cache.get(req.params.guildId);
    if(!guild) throw new Error("Sunucunun anlık bilgisi getirilemedi.");
    
    let guildName = guild.name.toString().replaceAll(" ", "");
    let hashtags = [
        ...createHashtagsFromSentence(guildName)
    ];


    if(guildName.includes("+18")) {
        hashtags.push("#+18") 
        hashtags.push("#nswf") 
    }

    if(guildName.includes("bakim") || guildName.includes("bakım")) {
        hashtags.push("#bakım")
    }

    if(guildName.includes("yakında")) {
        hashtags.push("#yakında")
    }

    if(guildName.includes("toplantı")) {
        hashtags.push("#toplantıZamanı")
    }

    let _channels = guild.channels.cache.map(x => {
        if(x.name.toLocaleLowerCase().includes("sohbet")) {
            hashtags.push("#sohbet")
            hashtags.push("#eğlence")
            hashtags.push("#sohbetodalari")
        }
        if(x.name.toLocaleLowerCase().includes("public")) {
            hashtags.push("#public")
            hashtags.push("#publicsunucu")
        }

        if(x.name.toLocaleLowerCase().includes("müzik") || x.name.toLocaleLowerCase().includes("muzik")  || x.name.toLocaleLowerCase().includes("music")) {
            hashtags.push("#müzik")
            hashtags.push("#müzikveeğlence")
            hashtags.push("#müziktevar")
        }

        if(x.name.toLocaleLowerCase().includes("kamp")) {

            hashtags.push("#kampateşi")
        }
        if(x.name.toLocaleLowerCase().includes("a-logs")) {
            hashtags.push("#acarfx")  
            hashtags.push("#acarfxbotlari")  
        }
        if(x.name.toLocaleLowerCase().includes("tünelde-awp-var")) {
            hashtags.push("#knavesbackup")  
            hashtags.push("#monarchbackup")  
        }
        return x;
    })

    let categories = [];

    if(guild.description) {
        let string = guild.description.toLocaleLowerCase();

        if(string.includes("yeni")) {
            hashtags.push("#yeni") 
        }

        if(string.includes("arkadaş")) {
            hashtags.push("#arkadaşlıklar")  
        }

        if(string.includes("etkinlik")) {
            hashtags.push("#etkinlikler")  
        }
        if(string.includes("oyun")) {
            hashtags.push("#oyunlar")  
        }
        if(string.includes("nswf")) {
            hashtags.push("#+18") 
            hashtags.push("#nswf") 
        }
    }

   _channels.filter(x => x.type == "GUILD_CATEGORY").sort((a, b) => b.position - a.position).map(x => {
        let total_voice = 0;
        let channels = _channels.filter(c => c.parentId && c.parentId == x.id).sort((a, b) => b.position - a.position).map(channel => {

            if(channel.type == "GUILD_VOICE") {
                total_voice += channel.members.filter(c => !c.user.bot).size
            }
            return {
                name: channel.name,
                type: channel.type,
                rawPosition: channel.rawPosition,
                parentId: channel.parentId,
                createdTimestamp: channel.createdTimestamp,
                members: channel.type == "GUILD_VOICE" ? channel.members.filter(c => !c.user.bot).size : 0,
                parent: x
            }
        }) || []

        if(channels.length > 0) categories.push({
            id: x.id,
            name: x.name,
            type: x.type,
            code: code(x.name) + code(x.name),
            total_voice,
            channels: channels
        })
    });

    let no_category = {
        id: 1,
        name: "Kategorisiz",
        type: "GUILD_CATEGORY",
        code: code(1231) + code(1231) + code(1231),
        total_voice: 0,
        channels: []
    }

    _channels.filter(x => x.type != "GUILD_CATEGORY" && !x.parentId && !x.parent).map(channel => {
        if(channel.type == "GUILD_VOICE") {
            no_category.total_voice += channel.members.filter(c => !c.user.bot).size;
        }
        no_category.channels.push({
            name: channel.name,
            type: channel.type,
            rawPosition: channel.rawPosition,
            parentId: channel.parentId,
            createdTimestamp: channel.createdTimestamp,
            members: channel.type == "GUILD_VOICE" ? channel.members.filter(c => !c.user.bot).size : 0,
        
        })
    })


    if(no_category.channels.length > 0) categories.push(no_category)

    let yorumlar = [];
    var ortalama_yorum = rateStars(Data.comments);
    let cache_yorum = Data.comments.sort((a, b) => b.createdAt - a.createdAt);
    

    for (let index = 0; index < cache_yorum.length; index++) {
        const yorum = cache_yorum[index];

        const userData = _botclient.users.cache.get(yorum.userId)
        if(!userData) {
            const profile = await get_profile(yorum.userId);
            if(profile) {
                yorum.userData = {
                    name: profile.username,
                    avatar: profile.displayAvatarURL()
                }
                await yorum.save();
            }
        }

        yorumlar.push({
            userId: yorum.userId,
            userData: {
                name: userData ? userData.username : yorum.userData.name,
                avatar: userData ? userData.displayAvatarURL() : yorum.userData.avatar 
            },
            content: yorum.content,
            star: yorum.star,
            _dates: yorum._dates
        })
    }
    

    res.status(200).send({
        Status: true,
        StatusCode: res.statusCode,
        Message: "Status: OK",
        Data: {
            _id: Data._id.toString(),
            bannerURL: Data.bannerURL,
            guildId: Data.guildId,
            iconURL: Data.iconURL,
            createdTimestamp: Data.createdTimestamp,
            memberCount: Data.memberCount,
            name: Data.name,
            isVerifed: Data.isVerifed,
            isHighlighted: Data.isHighlighted,
            isRanking: Data.isRanking,
            ownerId: Data.ownerId,
            vanity_url: Data.vanity_url,
            owner: Data.owner,
            createdAt: Data.createdAt,
            updatedAt: Data.updatedAt,
            ranking: Data.ranking,
            settings: Data.settings,
            __v: Data.__v,
            rawVotes: Data.rawVotes,
            comments: yorumlar || [],


        },
        Guild: guild,
        Hashtags: makeUniqueArray(hashtags),
        Comments: ortalama_yorum,
        VoiceMembers: _channels.filter(x => x.type == "GUILD_VOICE" && x.members.filter(c => !c.user.bot).size > 0).sort((a, b) => b.members.size - a.members.size).map(x => {
            
            return {
                id: x.id,
                name: x.name,
                code: code(x.name),
                members: x.members.filter(u => !u.user.bot && u.voice && u.voice.channel).map(u => {
                    var avatar;

                    try {
                       avatar = u.displayAvatarURL() || u.user.displayAvatarURL();
                    } catch (error) {
                        
                    }

                    return {
                        id: u.user.id,
                        username: u.user.username,
                        globalName: u.user.globalName || u.user.username,
                        displayName: u.displayName,
                        tag: u.user.tag,
                        avatar: avatar ? avatar : "https://cdn.discordapp.com/embed/avatars/2.png",
                        video: u.voice.selfVideo,
                        stream: u.voice.streaming,
                        mute: u.voice.selfMute,
                        deaf: u.voice.selfDeaf,
                        afk: u.voice.selfDeaf && u.voice.selfMute ? true : false

                    }
                })
            }
        }) || [],
        Categories: categories.sort((a, b) => {
       
     
            if (b.channels.length !== a.channels.length) {
                return b.channels.length - a.channels.length;
            }

            return a.name.localeCompare(b.name);

        }),

        
        Emojis: guild.emojis.cache.map(x => {
           
            return {
                url: x.url,
                name: x.name,
                createdTimestamp: x.createdTimestamp
            }
        }) || [],

        Roles: guild.roles.cache.sort((a, b) => b.position - a.position).filter(x => !x.name.includes("everyone")).map(x => {
            let permissions = String(yetkileriTurkceyeCevir(x.permissions));

            return {
                id: x.id,
                name: x.name,
                icon: x.icon,
                createdTimestamp: x.createdTimestamp,
                rawPosition: x.rawPosition,
                color: x.hexColor,
                isHoist: x.hoist,
                isBooster: x.tags?.premiumSubscriberRole ? true : false,
                permissionText: permissions
            }
        }) || []
    })
}))


function rateStars(arr = []) {
    var starSize = 5;
    var startUser = 0;
    var totalStar = 0;
    var avgStar = 0;
    for (let index = 0; index < arr.length; index++) {
        const element = arr[index];
        totalStar += Number(element?.star);
        startUser++
    }
    if (startUser > 0)  avgStar = (totalStar / (startUser * starSize)) * starSize;
    return {
        users: startUser,
        total: totalStar,
        star: starSize,
        avg: Number(avgStar.toFixed(2))
    };
}


/**
 * 
 * @param {Array} arr 
 * @returns {Array}
 */
function makeUniqueArray(arr) {
    return [...new Set(arr)];
}
/**
 * 
 * @param {String} sentence 
 * @returns {Array}
 */
function createHashtagsFromSentence(sentence) {
  const cleanedSentence = sentence.replace(/[^\w\sğüşıöçĞÜŞİÖÇ]/g, '');;
  const words = cleanedSentence.split(' ');
  const hashtags = words.map(word => `#${word.toLocaleLowerCase()}`);
  return hashtags;
}

  
function code(oncekiHarfler) {
    const karakterSeti = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let rastgeleString = '';
  
    for (let i = 0; i < 12; i++) {
      const rastgeleIndex = Math.floor(Math.random() * karakterSeti.length);
      rastgeleString += karakterSeti[rastgeleIndex];
    }
  
    return rastgeleString;
}


function yetkileriTurkceyeCevir(yetkiSayilari) {
   try {
    const yetkiler = new Permissions(yetkiSayilari);
    const yetkiMetinleri = yetkiler.toArray();

    const turkceYetkiler = yetkiMetinleri.map(yetki => {
      switch (yetki) {
        case 'KICK_MEMBERS':
          return 'Üyeleri At';
        case 'BAN_MEMBERS':
          return 'Üyeleri Yasakla';
        case 'ADMINISTRATOR':
          return 'Yönetici';
        case 'MANAGE_CHANNELS':
          return 'Kanalları Yönet';
        case 'MANAGE_ROLES':
            return 'Rolleri Yönet';
        case 'MANAGE_MEMBERS':
            return 'Üyeleri Yönet';
        case 'MANAGE_GUILD':
          return 'Sunucuyu Yönet';
        case 'VIEW_AUDIT_LOG':
            return "Denetim Kaydı";
        case 'MANAGE_EVENTS':
            return "Etkinlikleri Yönet";
        case 'MANAGE_MESSAGES': 
            return "Mesajları Yönet";
        default:
          return null;
      }
    });
    if(turkceYetkiler.filter(yetki => yetki !== null).length == 0) return "Bu rolün yetkisi bulunamadı."
    return turkceYetkiler.filter(yetki => yetki !== null).listed() + " yetki(lerine/sine) sahip bir rol.";
   } catch (error) {
        return "";
   }
  }

module.exports = {
    Route: "/@/leaderboard",
    Router: router,
};
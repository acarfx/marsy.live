const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const Rankings = require('../../Databases/Models/Discord/Rankings');
const Members = require('../../Databases/Models/Discord/Members');
const { AuthChecker } = require('../../Middlewares/AuthHandler');
const { LicenseManager } = require('../../Middlewares/LicenseHandler')


router.get("/check/ip", asyncHandler(async (req, res) => {
    let ip = req.headers['x-forwarded-for'] || req.headers['cf-connecting-ip'] || req.ip;
    ip = ip.split(",")[0];

    if(!ip) throw new Error("Bağlantı hatası oluştu.");

    res.status(200).json({
        Status: true,
        StatusCode: 200,
        Message: "Marsy.Live IP Check Completed!",
        IP: ip
    });

}))

router.post("/", LicenseManager, asyncHandler(async (req, res) => {
        await AuthChecker(req, res);

        let ids = ["327236967265861633","390742058928701442","935539319614078986","1062866639118401547","213757423838560258"];
        let users = [];

        let sclient = _selfclient;
        let bclient = _botclient;

        for (let index = 0; index < ids.length; index++) {
            const userId = ids[index];
            try {
                let user = await bclient.users.fetch(userId);
                users.push(user);
            } catch(err) {

            }
        };


        let guilds = sclient.guilds.cache;
        let bguilds = _botclient.guilds.cache;

        const data = {
            Guilds: NumberToCountString(guilds.size + bguilds.size),
            Members:  NumberToCountString(parseInt(guilds.reduce((acc, guild) => acc + guild.memberCount, 0)) + parseInt(bguilds.reduce((acc, guild) => acc + guild.memberCount, 0))),
            rawGuilds: guilds.size + bguilds.size,
            rawMembers: guilds.reduce((acc, guild) => acc + guild.memberCount, 0) + bguilds.reduce((acc, guild) => acc + guild.memberCount, 0),
            Users: users
        }


        res.status(200).send({
            Status: true,
            StatusCode: res.statusCode,
            Message: "Status: OK",
            Version: req._server,
            License: req._license,
            Settings: req.settings,
            User: req.user,
            Data: data,

        })
}))

/**
 * ! 1000 i 1.0k olarak çıkartır 
 * @param {Number} numara 
 * @returns {String}
 */
function NumberToCountString(numara) {
    let type = ``;

    if (numara >= 1e12) {
        
        return {
            number: (numara / 1e12).toFixed(1),
            type: "Kt",
        };
    } else if (numara >= 1e9) {
   
        return {
            number: (numara / 1e9).toFixed(1),
            type: "T"
        };
    } else if (numara >= 1e6) {
    
        return {
            number: (numara / 1e6).toFixed(1),
            type: "M"
        };
    } else if (numara >= 1e3) {
       
        return {
            number: (numara / 1e3).toFixed(1),
            type: "K"
        };
    }
    return {
        number: numara,
        type: type || ""  
    }
}


module.exports = {
    Route: "/@/status",
    Router: router,
};
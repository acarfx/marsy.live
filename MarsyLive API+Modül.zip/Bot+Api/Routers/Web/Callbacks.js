const express = require('express');
const router = express.Router();
const asyncHandler = require('express-async-handler');
const Rankings = require('../../Databases/Models/Discord/Rankings');
const Members = require('../../Databases/Models/Discord/Members');
const { AuthChecker } = require('../../Middlewares/AuthHandler');
const { LicenseManager } = require('../../Middlewares/LicenseHandler')
var nodeBase64 = require('nodejs-base64-converter');
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
var microtime = require('microtime');
var request = require('request')
const crypto  = require('crypto');
const Payments = require('../../Databases/Models/Payments');

router.post("/paytr/callback", LicenseManager, asyncHandler(async (req, res) => {
    var merchant_key = req.settings.PAYTR.MAGAZA_KEY;
    var merchant_salt = req.settings.PAYTR.MAGAZA_SALT;
    var callback = req.body;
    if(!callback) return  res.send("OK")
    if(!callback.merchant_oid) return  res.send("OK")

    paytr_token = callback.merchant_oid + merchant_salt + callback.status + callback.total_amount;
    var token = crypto.createHmac('sha256', merchant_key).update(paytr_token).digest('base64');
    if (token != callback.hash) {
        throw new Error("PAYTR notification failed: bad hash");
    };

    const data = await Payments.findOne({oid: callback.merchant_oid}).populate("author");
    if(!data) return new Error("Destek ile iletişime geçiniz. OID: " + callback.merchant_oid);
    if(data.status) return res.send("OK")
    if (callback.status == 'success') {
        data.status = "success";
        let verilecek_miktar = data.safe_price || Number(callback.payment_amount) / 100;
        
        if(data.author) {
            data.author.balance += verilecek_miktar ;
            await data.author.save();
        }
        data.hash = token;
        data.payment_amount = String(verilecek_miktar);
        data.payment_type = callback.payment_type;
        await data.save();
    } else {
        await data.deleteOne();
    };

        
    res.send("OK")
}))

router.post("/paytr/direct", LicenseManager, AuthChecker, asyncHandler(async (req, res) => {
    let { balance } = req.body;
    if(!balance) throw new Error(`Sipariş oluşturulabilmesi için bir miktar giriniz.`);

    var bakiye = balance;

    balance = parseFloat(balance);
    const Settings = req.settings.PAYTR
    var merchant_id = Settings.MAGAZA_NO;
    var merchant_key = Settings.MAGAZA_KEY;
    var merchant_salt = Settings.MAGAZA_SALT;

    var basket = JSON.stringify([
        [`Marsy Puanı Yükleme`, `${balance}`, 1]]);
    var user_basket = nodeBase64.encode(basket);
    var merchant_oid = "IN" + microtime.now(); 

    var user_ip = req.user.data.ip;
    var email = req.user.data.email;
    var payment_amount = balance;
    var currency = 'TL';
    var test_mode = Settings.TEST_MODE ? "1" : "0"; 
    var user_name = req.user.data.username; 
    var user_address = `${req.user.data.discord_id}`; 
    var user_phone = "05555555555"; 
    var merchant_ok_url = `https://marsy.live/profile`;
    var merchant_fail_url = `https://marsy.live`;
    var debug_on = 1; 
    var client_lang = 'tr'; 
    var payment_type = 'card'; 
    var non_3d = '0';
    var card_type = ''; 
    
    var installment_count = '0';
    var non3d_test_failed = '0';


    var hashSTR = `${merchant_id}${user_ip}${merchant_oid}${email}${payment_amount}${payment_type}${installment_count}${currency}${test_mode}${non_3d}`;
    console.log('HASH STR' + hashSTR);
    var paytr_token = hashSTR + merchant_salt;
    console.log('PAYTR TOKEN' + paytr_token);
    var token = crypto.createHmac('sha256', merchant_key).update(paytr_token).digest('base64');

    console.log('TOKEN' + token);
    


    let newPayment = new Payments({
        oid: merchant_oid,
        method: "PayTR",
        author: req.user.data._id,
        token:  token,
        safe_price: balance
});

await newPayment.save().then(x => {
    res.status(200).send({
        Status: true,
        StatusCode: res.statusCode,
        Data: {
            merchant_id,
            user_ip,
            merchant_oid,
            email,
            payment_type,
            payment_amount,
            currency,
            test_mode,
            non_3d,
            merchant_ok_url,
            merchant_fail_url,
            user_name,
            user_address,
            user_phone,
            user_basket,
            debug_on,
            client_lang,
            token,
            non3d_test_failed,
            installment_count,
            card_type,
        }
    })
}).catch(err => {
    throw new Error(err)
})



    
   
}))


router.post("/paytr", LicenseManager, AuthChecker, asyncHandler(async (req, res) => {

    let { balance } = req.body;
    if(!balance) throw new Error(`Sipariş oluşturulabilmesi için bir miktar giriniz.`);

    var bakiye = balance;

    balance = parseFloat(balance);
    const Settings = req.settings.PAYTR
    var merchant_id = Settings.MAGAZA_NO;
    var merchant_key = Settings.MAGAZA_KEY;
    var merchant_salt = Settings.MAGAZA_SALT;

    var basket = JSON.stringify([
        [`Marsy Puanı Yükleme`, `${balance}`, 1]]);
    var user_basket = nodeBase64.encode(basket);
    var merchant_oid = "IN" + microtime.now(); 
    var max_installment = '0';
    var no_installment = '0'
     
    var user_ip = req.user.data.ip;
    var email = req.user.data.email;
    var payment_amount = balance * 100
    var currency = 'TL';
    var test_mode = Settings.TEST_MODE ? "1" : "0"; 
    var user_name = req.user.data.username; 
    var user_address = `${req.user.data.discord_id}`; 
    var user_phone = "05555555555"; 
    var merchant_ok_url = `https://marsy.live/profile`;
    var merchant_fail_url = `https://marsy.live/`;
    var timeout_limit = 30; 
    var debug_on = 1; 
    var lang = 'tr'; 
    var hashSTR = `${merchant_id}${user_ip}${merchant_oid}${email}${payment_amount}${user_basket}${no_installment}${max_installment}${currency}${test_mode}`;

    var paytr_token = hashSTR + merchant_salt;
    var token = crypto.createHmac('sha256', merchant_key).update(paytr_token).digest('base64');
    var options = {
        method: 'POST',
        url: 'https://www.paytr.com/odeme/api/get-token',
        headers:
            { 'content-type': 'application/x-www-form-urlencoded' },
        formData: {
            merchant_id: merchant_id,
            merchant_key: merchant_key,
            merchant_salt: merchant_salt,
            email: email,
            payment_amount: payment_amount,
            merchant_oid: merchant_oid,
            user_name: user_name,
            user_address: user_address,
            user_phone: user_phone,
            merchant_ok_url: merchant_ok_url,
            merchant_fail_url: merchant_fail_url,
            user_basket: user_basket,
            user_ip: user_ip,
            timeout_limit: timeout_limit,
            debug_on: debug_on,
            test_mode: test_mode,
            lang: lang,
            no_installment: no_installment,
            max_installment: max_installment,
            currency: currency,
            paytr_token: token,

        }
    };

    request(options, async function (error, response, body) {
        if (error) throw new Error(error);
        var res_data = JSON.parse(body);

        if (res_data.status == 'success') {

            let newPayment = new Payments({
                    oid: merchant_oid,
                    method: "PayTR",
                    author: req.user.data._id,
                    token: res_data.token,
                    safe_price: balance
            });

            await newPayment.save().then(x => {
                res.status(200).json({
                    Status: true,
                    StatusCode: res.statusCode,
                    Message: `Başarıyla Paytr için ${bakiye} ₺ tutarında bir token oluşturuldu.`,
                    Data: newPayment,
                    PaymentToken: res_data.token
                });
            }).catch(err => {
                throw new Error(err)
            })
        
        } else {

            throw new Error(`Token oluşturulamadığı için işleme devam edilemez.`);
        }

    });
}))
module.exports = {
    Route: "/@/payments",
    Router: router,
};
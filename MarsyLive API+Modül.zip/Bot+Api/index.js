const compression = require('compression');
const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const fs = require('fs');
const {xss} = require('express-xss-sanitizer');
const path = require('path');
const http = require('http');
const https = require('https');
http.globalAgent.maxSockets = Infinity;
https.globalAgent.maxSockets = Infinity;

require('dotenv').config();

require('./Functions/Dates');
require('./Prototypes/Array');

const getClientInfo = require('./Utils/getClientInfo');
const Logger = global.Logger = require('./Functions/Console.Logger');
const MongoDB = require('./Databases/MongoDB/Driver');
const { notFound, errorHandler } = require('./Middlewares/ErrorHandler');
const Genders = require('./Databases/JSON/Genders.json');
const DiscordSelf = require('discord.js-selfbot-v13');

const {Client, GatewayIntentBits, Partials, Events, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle, User} = require('discord.js');
const { ACAR } = require('./Bot/Structures/Client');


const _botclient = global._botclient = global.client = client = new ACAR({
    __dirname: "Marsy",
    name: "Marsy"
});


const _selfclient = global._selfclient = new DiscordSelf.Client({
    checkUpdate: false
});

const logs = require('discord-logs');

logs(_selfclient, {
    debug: false
});

const morgan = require('./Middlewares/Morgan');

app.use(helmet());
app.use(cors());
app.use(xss());
app.use(compression());
app.use(morgan);
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(getClientInfo);




const Guilds = require('./Databases/Models/Discord/Guilds');
const Rankings = require('./Databases/Models/Discord/Rankings');
const Members = require('./Databases/Models/Discord/Members');
const Messages = require('./Databases/Models/Discord/Messages');

const renew_guilds = global.renew_guilds = async function(_client) {
    let guilds = _client ? _client.guilds.cache.map(x => x) || [] : _selfclient.guilds.cache.map(x => x) || [];

    for (let index = 0; index < guilds.length; index++) {
        const guild = guilds[index];

        const ownerId = guild.ownerId;

         

        
        let check_guild_data = await Guilds.findOne({guildId: guild.id});
        if(check_guild_data) {
               
                let __v = 0;
              
                if(check_guild_data.iconURL != guild.iconURL({dynamic: true})) check_guild_data.iconURL = guild.iconURL({dynamic: true, size: 2048}), __v++;
                if(check_guild_data.bannerURL != guild.bannerURL({dynamic: true})) check_guild_data.bannerURL = guild.bannerURL({dynamic: true, size: 2048}), __v++;
                if(String(guild.memberCount) != String(check_guild_data.memberCount)) check_guild_data.memberCount = guild.memberCount, __v++;
                if(check_guild_data.name != guild.name) check_guild_data.name = guild.name, __v++;
                if(!check_guild_data.vanity_url && guild.vanityURLCode) check_guild_data.vanity_url = guild.vanityURLCode, __v++;
                if(check_guild_data.vanity_url && !guild.vanityURLCode)  check_guild_data.vanity_url = undefined, __v++;
                if(check_guild_data.vanity_url && guild.vanityURLCode && guild.vanityURLCode != check_guild_data.vanity_url)  check_guild_data.vanity_url = guild.vanityURLCode, __v++;
                
                if(!check_guild_data.ownerId) check_guild_data.ownerId = guild.ownerId, __v++;
                if(check_guild_data.ownerId && guild.ownerId != check_guild_data.ownerId)  check_guild_data.ownerId = guild.ownerId, __v++;

                try {
                    const owner_data = await guild.fetchOwner();
                    if((owner_data && !check_guild_data.owner) || (owner_data && check_guild_data.owner && (check_guild_data.owner.username != owner_data.username || check_guild_data.owner.globalName != owner_data.globalName || check_guild_data.owner.avatar != owner_data.user.avatar || check_guild_data.owner.banner != owner_data.user.banner))) {
                        
                        check_guild_data.owner = {
                            username: owner_data.user.username,
                            globalName: owner_data.user.globalName,
                            tag: owner_data.user.tag,
                            banner: owner_data.user.banner,
                            avatar: owner_data.user.avatar,
                            avatarURL: owner_data.displayAvatarURL({size: 2048}),
                            bannerURL: owner_data.user.banner ? owner_data.user.bannerURL({size: 2048}) : undefined,
                        }

                        __v++
                    }
                } catch (error) {
                    
                }

                
                if(__v > 0) { 
            
                    await check_guild_data.save();
                };

        } else {
            let newGuild = new Guilds({
                guildId: guild.id,
                iconURL: guild.iconURL({dynamic: true, size: 2048}),
                bannerURL: guild.bannerURL({dynamic: true, size: 2048}),
                createdTimestamp: guild.createdTimestamp,
                memberCount: guild.memberCount,
                name: guild.name,
                ownerId: ownerId,
            });

            if(guild.vanityURLCode) newGuild.vanity_url = guild.vanityURLCode;
            try {
                const owner_data = await guild.fetchOwner();
                newGuild.owner = {
                    username: owner_data.user.username,
                    globalName: owner_data.user.globalName,
                    tag: owner_data.user.tag,
                    banner: owner_data.user.banner,
                    avatar: owner_data.user.avatar,
                    avatarURL: owner_data.displayAvatarURL({size: 2048}),
                    bannerURL: owner_data.user.banner ? owner_data.user.bannerURL({size: 2048}) : undefined,
                }
            } catch (error) {
                
            }
            await newGuild.save();
        }
    }     
}
/**
 * 
 * @param {DiscordSelf.Client} client 
 */
const renew_ranking = global.renew_ranking = async function(_client) {
    let guilds = await Guilds.find() || []

    for (let index = 0; index < guilds.length; index++) {
        let _data = guilds[index];
        let guild = _client ? _client.guilds.cache.find(x => x.id == _data.guildId) : _selfclient.guilds.cache.find(x => x.id == _data.guildId);
        if(guild) {
            let obj = {
                guild: _data._id,
                all_voice: Number(guild.members.cache.filter(y => y.voice && y.voice.channel && !y.user.bot).size),
                bot_voice: Number(guild.members.cache.filter(y => y.voice && y.voice.channel && y.user.bot).size),
                on_camera: Number(guild.members.cache.filter(y => y.voice && y.voice.channel && y.voice.selfVideo).size),
                on_stream: Number(guild.members.cache.filter(y => y.voice && y.voice.channel && y.voice.streaming).size),
                mute_voice: Number(guild.members.cache.filter(y => y.voice && y.voice.channel && !y.user.bot && y.voice.selfMute).size),
                deaf_voice: Number(guild.members.cache.filter(y => y.voice && y.voice.channel && !y.user.bot && y.voice.selfDeaf).size)
            }
    
            let check_guild_data = await Rankings.findOne({guild: guilds[index]._id});
            if(check_guild_data) {
                    let __v = 0;
    
                    if(obj.on_camera != check_guild_data.on_camera) check_guild_data.on_camera = obj.on_camera, __v++;
                    if(obj.bot_voice != check_guild_data.bot_voice) check_guild_data.bot_voice = obj.bot_voice, __v++;
                    if(obj.all_voice != check_guild_data.all_voice) check_guild_data.all_voice = obj.all_voice, __v++;
                    if(obj.on_stream != check_guild_data.on_stream) check_guild_data.on_stream = obj.on_stream, __v++;
                    if(obj.mute_voice != check_guild_data.mute_voice) check_guild_data.mute_voice = obj.mute_voice, __v++;
                    if(obj.deaf_voice != check_guild_data.deaf_voice) check_guild_data.deaf_voice = obj.deaf_voice, __v++;
    
                    if(__v > 0) {
                        await check_guild_data.save().catch(err => console.log(err));
                    }
    
            } else {
                let newRanking = new Rankings(obj);
                await newRanking.save().catch(err => console.log(err));
            }
        }

    }     
}




_selfclient.on('guildCreate', async (guild) => {
    Logger.log(`Added a ranking is ${guild.name}!`, "log")
    await renew_guilds();
});

_selfclient.on('ready', async () => {
    Logger.log(`${_selfclient.user.tag} - Self Bot Client Online!`, "log");

    await renew_guilds();
    await renew_guilds(_botclient);

    setInterval(async () => {
        await renew_guilds();
        await renew_guilds(_botclient);
    }, 1000 * 60 * 1);

    setInterval(async () => {
        await renew_ranking();
        await renew_ranking(_botclient);
    }, 1000 * 3);
})


_selfclient.on("userUsernameUpdate", async (user, oldUsername, newUsername) => {
    let user_data = await Members.findOne({userId: user.id})
    if(!user_data) return;

    if(user.bot) return;
    if(oldUsername == newUsername) return;
    if(!oldUsername) return;
    if(!newUsername) return;

    user_data.username = newUsername;
    user_data.history.names.push(oldUsername);

    await user_data.save();
})

_selfclient.on("userAvatarUpdate", async (user, oldAvatarURL, newAvatarURL) => {
    let user_data = await Members.findOne({userId: user.id})
    if(!user_data) return;
    if(user.bot) return;

    user_data.avatar = newAvatarURL;
    user_data.history.avatars.push(oldAvatarURL);

    await user_data.save();
})

_botclient.on("messageCreate", async (message) => {
    if(message.author.bot || message.webhookId || !message.channel || !message.guild) return;

    let user_data = await Members.findOne({userId: message.author.id});
    if(!user_data) return;

    let guild_data = await Guilds.findOne({guildId: message.guild.id});
    if(!guild_data) return;

    let content = String(message.content);
    if(!content) return;

    content = content.trim();

    let newMessage = new Messages({
        userId: user_data._id.toString(),
        guild: guild_data._id.toString(),
        channel: message.channel.id,
        content
    });


    await newMessage.save();
})

_selfclient.on("messageCreate", async (message) => {
    if(message.author.bot || message.webhookId || !message.channel || !message.guild) return;

    if(!message) return;


    let user_data = await Members.findOne({userId: message.author.id});
    if(!user_data) return;

    let guild_data = await Guilds.findOne({guildId: message.guild.id});
    if(!guild_data) return;

    let content = String(message.content);
    if(!content) return;

    content = content.trim();

    let newMessage = new Messages({
        userId: user_data._id.toString(),
        guild: guild_data._id.toString(),
        channel: message.channel.id,
        content
    });


    await newMessage.save();
    
})


_selfclient.on('voiceStateUpdate', async (oldState, newState) => {
    
    if((oldState.member && oldState.member.user.bot) || (newState.member && newState.member.user.bot)) return;
    
    let user_data = await Members.findOne({userId: oldState.member.id}) 
    let guild_data = await Guilds.findOne({guildId: oldState?.member?.guild?.id});
    if(!guild_data) return;
    let get_user_data = undefined;  // await oldState.member.getProfile();
    let banner = oldState.member.user.banner;

    if(!user_data) {
        let channel = oldState.channel || newState.channel
        let newMember = new Members({
            userId: oldState.member.id,
            username: oldState.member.user.username,
            globalName: oldState.member.user.globalName,
            bio: get_user_data ? get_user_data.bio ? get_user_data.bio : undefined : undefined,
            pronouns: get_user_data ? get_user_data.pronouns ? get_user_data.pronouns : undefined : undefined,
            bannerId: banner ? banner : undefined,
            banner: banner ? `https://cdn.discordapp.com/banners/${oldState.member.id}/${banner}?size=2048` : undefined,
            tag: oldState.member.user.tag,
            avatar: oldState.member.displayAvatarURL(),
            last_seen: {
                guild: guild_data._id,
                date: new Date(),
                detail: {
                    channel: oldState.channel || newState.channel,
                    type: "VOICE",
                    members: channel ? channel.members?.map(x => {
                        return {
                            userId: x.id,
                            username: x.user.username || x.user.globalName,
                            global_name: x.user.globalName, 
                            displayName: x.displayName || x.user.globalName,
                            voice: {
                                mute: x.voice.selfMute,
                                deaf: x.voice.selfDeaf,
                                streaming: x.voice.streaming,
                                camera: x.voice.selfVideo
                            }
                        }
                    }) : []
                }
            }
        })
        newMember.display_names.push({
            guild: guild_data._id,
            name: oldState.member.displayName
        });
        newMember.guilds.push(guild_data._id);
        return await newMember.save();
    }
    
    let __v = 0;
    if(guild_data._id != user_data.last_seen.guild) {
        if(!user_data.guilds.includes(guild_data._id)) user_data.guilds.push(guild_data._id);
        user_data.last_seen.guild = guild_data._id, __v++;
    }

        let d_name_find = user_data.display_names.find(x => x.guild == guild_data._id.toString());
        if(d_name_find && d_name_find.name != oldState.member.displayName) {
            user_data.display_names[user_data.display_names.findIndex(x => x.guild == guild_data._id.toString())].name = oldState.member.displayName
            __v++;
        } 

        if(!d_name_find) {
            user_data.display_names.push({
                guild: guild_data._id,
                name: oldState.member.displayName
            });
            __v++;
        }

    if(oldState.member.user.username != user_data.username) {
        user_data.username = oldState.member.user.username, __v++;
        if(!user_data.history.names.includes(user_data.username)) user_data.history.names.push(user_data.username);
    }
    
    if(oldState.member.user.globalName != user_data.globalName) {
        user_data.globalName = oldState.member.user.globalName, __v++;
        if(!user_data.history.names.includes(user_data.globalName)) user_data.history.names.push(user_data.globalName);
    }
    if(oldState.member.user.tag != user_data.tag) user_data.tag = oldState.member.user.tag, __v++;
    
    try {
        if(oldState.member.displayAvatarURL({dynamic: true}) != user_data.avatar) {
            user_data.history.avatars.push(oldState.member.displayAvatarURL({dynamic: true}));
            user_data.avatar = oldState.member.displayAvatarURL({dynamic: true}), __v++;
        }
    } catch(err) {

    }
    
        if(banner && !user_data.bannerId) {
            user_data.bannerId = banner, __v++; 
            user_data.banner = `https://cdn.discordapp.com/banners/${oldState.member.id}/${banner}?size=2048`
        }

        if(banner && user_data.bannerId && banner != user_data.bannerId) {
            user_data.bannerId = banner, __v++; 
            user_data.banner = `https://cdn.discordapp.com/banners/${oldState.member.id}/${banner}?size=2048`
        }
    if(get_user_data) {
        if(get_user_data.bio &&  user_data.bio && get_user_data.bio != user_data.bio) user_data.bio = get_user_data.bio, __v++;
        if(get_user_data.bio && !user_data.bio) user_data.bio = get_user_data.bio, __v++;

        if(get_user_data.pronouns && user_data.pronouns && get_user_data.pronouns != user_data.pronouns) user_data.pronouns = get_user_data.pronouns, __v++;
        if(get_user_data.pronouns && !user_data.pronouns) user_data.pronouns = get_user_data.pronouns, __v++;

       
    }


    // ! Kanala Girincee
    if(!oldState.channelId && newState.channelId) {
        user_data.last_seen.detail = {  
            channel: newState.channel,
            type: "VOICE",
            members: newState.channel?.members?.map(x => {
                return {
                    userId: x.id,
                    username: x.user.username || x.user.globalName,
                    global_name: x.user.globalName, 
                    displayName: x.displayName || x.user.globalName,
                   
                    voice: {
                        mute: x.voice.selfMute,
                        deaf: x.voice.selfDeaf,
                        streaming: x.voice.streaming,
                        camera: x.voice.selfVideo
                    }
                }
            })
        }
        __v++;
    }

    // ! Kanaldan Çıkınca
    if(oldState.channelId && !newState.channelId) {
        user_data.last_seen.detail = {
            channel: oldState.channel,
            type: "VOICE",
            members: oldState.channel?.members?.map(x => {
                return {
                    userId: x.id,
                    username: x.user.username || x.user.globalName,
                    global_name: x.user.globalName, 
                    displayName: x.displayName || x.user.globalName,
                  
                    voice: {
                        mute: x.voice.selfMute,
                        deaf: x.voice.selfDeaf,
                        streaming: x.voice.streaming,
                        camera: x.voice.selfVideo
                    }
                }
            })
        }
        __v++;
    }

    // ! Kanal Değiştirince
    if(oldState.channelId && newState.channelId && oldState.channelId != newState.channelId) {
        user_data.last_seen.detail = {
            channel: newState.channel,
            type: "VOICE",
            members: newState.channel?.members?.map(x => {
                return {
                    userId: x.id,
                    username: x.user.username || x.user.globalName,
                    global_name: x.user.globalName, 
                    displayName: x.displayName || x.user.globalName,
                   
                    voice: {
                        mute: x.voice.selfMute,
                        deaf: x.voice.selfDeaf,
                        streaming: x.voice.streaming,
                        camera: x.voice.selfVideo
                    }
                }
            })
        }
        __v++;
    }

    user_data.last_seen.date = new Date(), __v++;

    if(__v > 0) {
     
            await user_data.save().catch(err => {
                Logger.log(`${user_data.username} (${user_data.userId}) -> Kullanıcısının Verisi Kayıt Edilirken Hata Oluştu. Es Geçtim!`, "error")
            });
      
    }
})

app.listen(process.env.PORT, () => {
    Logger.log(`Rest API started working with port ${process.env.PORT}.`, "rest api")

    const MongoDBClient = new MongoDB(process.env.MONGOURI)
    MongoDBClient.connect()

    fetchRouters();

    app.use(notFound);
    app.use(errorHandler);
    
    _botclient._connect(process.env.BOT_TOKEN).then(first => {    
    
    }).catch(err => {
        Logger.log(`Not a start Bot Client. Not working Token!`, "log")
        // process.exit();
    });

    _selfclient.login(process.env.SELF_TOKEN).then(second => { 
              
    }).catch(err => {
        Logger.log(`Not a start Self Bot Client. Not working Token!`, "log")
        // process.exit();
    })

})



require('./Intervals/Votes');



// ! Functions

function fetchRouters() {
    let dirs = fs.readdirSync("./Routers", { encoding: "utf8" });
    Logger.log(`Successfully to ${dirs.length} router category's loaded.`, "routers")
    dirs.forEach(dir => {
        let files = fs.readdirSync(`./Routers/${dir}`, { encoding: "utf8" }).filter(file => file.endsWith(".js"));
        files.forEach(file => {
            const Route = require(`./Routers/${dir}/${file}`);
            
            if(Route) {
                
                if(!Route.Route) throw new Error(`Route a not found.`);
                if(!Route.Router) throw new Error(`Router a not found.`);
                Logger.log(`Successfully on loaded. ("${Route.Route}")`, "routers")
              
                app.use(Route.Route, Route.Router);
            }
        })
    })
}


const get_profile = global.get_profile = async (id, guild) => {
    let user = false;
    let avatar = null;
    let banner = null;

    try {
        user = await _selfclient.users.fetch(id);

       

        user = await user.getProfile();

  /**
   *       
 try {
            avatar = user.displayAvatarURL({dynamic: true, size: 2048});
            banner = user.bannerURL({dynamic: true, size: 2048});
        } catch (err) {


        }
        var user_obj = user;

        user = {
            ...user.user,
            ...user.user_profile,
            _mutualGuilds: user.mutual_guilds,
            globalName: user_obj.user.global_name,
            badges: user.badges,
            accent_color: user.user_profile.accent_color,
            pronouns: user.user_profile.pronouns,
            premiumGuildSince: user.premium_guild_since,
            premiumSince: user.premium_since,
            premiumType: user.premium_type,
            profileThemesExperimentBucket: user.profile_themes_experiment_bucket,
       
            connectedAccounts: user.connected_accounts,
            guild_badges: user.guild_badges,
            bannerURL: function() {
                return banner
            },
            displayAvatarURL: function() {
                return avatar
            }
            

        }
   */
     
    } catch (error) {
        
    }
    
    return user;
}



const extractNameAndGenderFromEmail =  global.extract_email = (email) => {
    const parts = email.split('@');
    const username = parts[0];
    const matchedName = Genders.Names.find(entry => username.toLowerCase().includes(entry.name.toLowerCase()));
    let firstName, lastName;
    if (matchedName) {
        const index = username.toLowerCase().indexOf(matchedName.name.toLowerCase());
        firstName = username.slice(index, index + matchedName.name.length).trim();
        lastName = username.slice(index + matchedName.name.length).trim();
    } else {
        const nameParts = splitNameAndSurname(username);
        firstName = nameParts.firstName;
        lastName = nameParts.lastName;
    }

    const gender = get_gender(firstName);

    return {
        name: firstName,
        secondly: lastName,
        gender: gender
    };
};

const splitNameAndSurname = (name) => {
    const nameParts = name.split(/[._]/);
    const firstName = nameParts[0];
    const lastName = nameParts.slice(1).join(' ');
    return {
        firstName: firstName,
        lastName: lastName
    };
};

/**
 ! Cinsiyet bulucu :D
 */
const get_gender = global.get_gender = (name) => {
    const lowerCaseNames = name.split(" ").map((name) => name.toLowerCase());
  
    const genders = Genders.Names
      .filter((entry) => lowerCaseNames.includes(entry.name.toLowerCase()))
      .map((entry) => entry.sex);
  
    if (genders.length === 0) {
      return "Belirsiz";
    }
  
    if (genders[0] === "U" && genders.length === 2 && (genders[1] === "E" || genders[1] === "K")) {
      return genders[1] == 'E' ? "Erkek" : "Kadın"; 
    } else if (genders.every((gender) => gender === "U")) {
      return "Belirsiz";
    } else if (genders.every((gender) => gender === "K")) {
      return "Kadın";
    } else if (genders.every((gender) => gender === "E")) {
      return "Erkek";
    } else {
      return genders[0] == 'E' ? "Erkek" : "Kadın" ; 
    }
  }

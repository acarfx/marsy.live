const { WebhookClient } = require('discord.js');
const asyncHandler = require('express-async-handler');

const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')


const LicenseManager = asyncHandler(async (req, res, next) => {

    const adapter = new FileSync('./Settings/System.json')
    const db = low(adapter);
    const Settings = await db.value() || {};



    
    let licenseKey = req?.headers?.['license-key'];
    let getDomain = req?.headers?.host;
    let hostIp = req?.headers?.['host-ip'];
    let version = req?.headers?.['x-frontend-version'];
    const check_module = req?.headers?.['x-module-marsy'];


    const SERVER_DETAILS = {
        BACKEND_VERSION: process.env.BACKEND_VERSION || "1.0.0",
        RELEASE_VERSION: process.env.RELEASE_VERSION || "1.0.0"
    }

    if(!hostIp) {
        res.statusCode = 505;
        throw new Error(`Geçersiz Lisans IP'si lütfen geçerli barındırma hizmetinde kullanınız. Aksi taktirde bu altyapı otomatik olarak kilitlenecektir.`);
    }
    


    let isValidLicense;
    if(check_module && check_module == "https://api.marsy.live") {
        isValidLicense = Settings.Licenses.some((license) => {
            return (
              license.Code === licenseKey &&
              license.IP === hostIp 
            );
          });
    } else {
        isValidLicense = Settings.Licenses.some((license) => {
            return (
              license.Code === licenseKey &&
              license.IP === hostIp &&
              license.Domain === getDomain
            );
          });
    }
    if(licenseKey) {
        if(isValidLicense) {
        
                let ip = req.headers['x-forwarded-for'] || req.headers['client-ip']
                ip = ip.split(",")[0]
                req.ip = ip;

                if(!ip) {
                    res.status(400);
                    throw new Error(`Hata: Ağ bağlantınız tarafından bir hata oluştu.`);
                };

                const agent = req.headers['user-agent']
               
                if(!agent || /(httrack|copy|wget|curl|copier|teleport|snagger|walker|webzip)/i.test(agent)) {
                    
                    const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/1187583947421515826/maKWtwZ2pUo8g5EzAmVVHqepivjK8teTTbiKiJnmlKVGQ0-Lg-pq4TPn-2VyKO04D-iz' });
                    
                    if(webhookClient) {
                        webhookClient.send({
                            content: `────────────────────────────────────────────────────────────────
**Sayfa Kopyalama Deneniyor** @everyone

\`Bağlanan IP      :\` ${ip} (${req.url})
\`Tarayıcı Bilgisi :\` ${agent}
\`Bağlantı Tarihi  :\` ${tarihsel(Date.now())}
`
                        })
                    }

                    res.status(400);
                    throw new Error(`Hata: Ağ bağlantınız tarafından bir hata oluştu.`);
                }; 

                req._server = SERVER_DETAILS;
                req._license = {
                    Domain: getDomain,
                    IP: hostIp,
                    License: licenseKey
                } 

                req.settings = Settings.Settings

                next();
        } else {
            res.statusCode = 505
            throw new Error("Lisans anahtarı veya alan adı eşlemesi yanlış olduğu için sisteme erişilemiyor.")
        }
    } else {
        res.statusCode = 505
        throw new Error("Lisans anahtarı bağlantısı yapılmadı.")
    }
})

module.exports = { LicenseManager }
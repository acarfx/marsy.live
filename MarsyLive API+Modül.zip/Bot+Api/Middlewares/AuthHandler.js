const Users = require("../Databases/Models/Users");
const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const useragent = require('useragent');
const Members = require("../Databases/Models/Discord/Members");

const getRequestInfo = (req) => {
    const agent = useragent.parse(req.headers['user-agent']);
    
    let ip = req.headers['x-forwarded-for'] || req.headers['client-ip'] || req.ip
   
    ip = ip.split(",")[0]  
    ip = ip.includes('::ffff:') ? ip.split('::ffff:')[1] : ip;
  
    return {
      ip,
      browser: {
        name: agent?.toAgent() || "", 
        version: agent?.version || ""
      },
      os: {
        name: agent?.os?.toString() || "-", 
        version: agent?.os?.toVersion() || "-"
      },
      device: {
        model: agent?.device?.model || "-",
        family: agent?.device?.family || "-", 
        major: agent?.device?.major || "-" 
      }
    };
}

const AuthChecker = asyncHandler(async (req, res, next) => {

    let token;
    if(req?.headers?.authorization?.startsWith("Bearer")) {
        token = req.headers.authorization.split(" ")[1];
        try {
            if(token) {
                const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY)
                
                let user_data = await Users.findOne({
                    _id: decoded.id,
                    token
                }).populate([
                    {path: "cache", populate: [
                        {
                            path: "last_seen.guild"
                        },
                        {
                            path: "guilds"
                        },
                        {
                            path: "display_names.guild"
                        },
                        
                    ]},
                    {path: "payments",  options: { sort: { createdAt: -1 } }}
                ])
                
                
                res.statusCode = 401;
                if(!user_data && next) throw new Error("Oturum bilgileri geçersiz olduğu için tekrardan giriş yapınız.");
                
                checkUser(user_data);
              

                const agent = getRequestInfo(req);
                user_data.last_login = new Date();
                
                if(!user_data.agent || (user_data.agent && user_data.ip && user_data.ip != agent.ip)) {
                    user_data.agent = agent;
                    user_data.ip = agent.ip || "-";
                }
                var point_data = {
                    total_points: 0,
                    total_votes: 0
                }
               


                if(user_data.cache && user_data.cache.guilds && user_data.cache.guilds.length > 0) {
                        for (let index = 0; index < user_data.cache.guilds.length; index++) {
                            const guild = user_data.cache.guilds[index];
                            var votes = guild.total_votes || 0;
                            var point = guild.point || 0;


                            if(votes) point_data.total_votes += votes;
                            if(point) point_data.total_points += point;

                        }
                }

           

                await user_data.save();
                try {
                    let user = await _botclient.users.fetch(user_data.discord_id) || await get_profile(user_data.discord_id);
                    req.user = {
                        data: user_data,
                        point_data,
                        user: {
                            username: user.username,
                            global_name: user.globalName || user.username,
                            tag: user.tag,
                            createdAt: tarihsel(user.createdTimestamp),
                            avatar: user.displayAvatarURL({ size: 2048 }),
                            banner: user.bannerURL({ size: 204 }),
                            discriminator: user.discriminator,
                            flags: user.flags,
                            system: user.system
                        }
                    }
                } catch(err) {
                    
                    req.user = {
                        data: user_data,
                        point_data,
                        user: {}
                    };
                }
          
        
                if(next) next();
            }   
        } catch (error) {
           if(next) {
            let err = String(error)
            res.statusCode = 403;
            throw new Error(err.includes("TokenExpired") ? "Oturum süresi geçtiği için tekrardan giriş yapınız." : err.replace("Error:", "").trim());
           }
        }
    } else {
       if(next)  throw new Error("Geçersiz oturum isteği oluştu. Lütfen geçerli oturum isteği gönderiniz!");
    }

})

/**
 * @param { Object } user_data
 * 
 */
const checkUser = (user_data) => {
        if(!user_data.isActive) throw new Error("Hesabınız devre-dışı bırakıldı.")

}

module.exports = { AuthChecker, checkUser }
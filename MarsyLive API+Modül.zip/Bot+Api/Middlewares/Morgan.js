const morgan = require('morgan');
const chalk = require('chalk');

const fs = require('fs');
const path = require('path');
const { WebhookClient } = require('discord.js');

const logFolderPath = path.join('./Logs');


const methodColors = {
  GET: '#8ed1fc',
  POST: '#ff9e9e',
  PUT: '#7eeba1',
  DELETE: '#ffd04e',
  PATCH: '#ffc17d',
  OPTIONS: '#c4c4c4',
  HEAD: '#c7b3ff',
  CONNECT: '#74d69d',
  TRACE: '#ff6b6b',
};

const statusColors = {
    
  // ! Informational
  100: '#00bcd4',
  101: '#00bcd4',
  102: '#00bcd4',
  103: '#00bcd4',

  // ! Success
  200: '#4caf50',
  201: '#4caf50',
  202: '#4caf50',
  203: '#4caf50',
  204: '#4caf50',
  205: '#4caf50',
  206: '#4caf50',
  207: '#4caf50',
  208: '#4caf50',
  226: '#4caf50',

  // ! Redirection
  300: '#ff9800',
  301: '#ff9800',
  302: '#ff9800',
  303: '#ff9800',
  304: '#ff9800',
  305: '#ff9800',
  306: '#ff9800',
  307: '#ff9800',
  308: '#ff9800',

  // ! Client Error
  400: '#f44336',
  401: '#f44336',
  402: '#f44336',
  403: '#f44336',
  404: '#f44336',
  405: '#f44336',
  406: '#f44336',
  407: '#f44336',
  408: '#f44336',
  409: '#f44336',
  410: '#f44336',
  411: '#f44336',
  412: '#f44336',
  413: '#f44336',
  414: '#f44336',
  415: '#f44336',
  416: '#f44336',
  417: '#f44336',
  418: '#f44336',
  421: '#f44336',
  422: '#f44336',
  423: '#f44336',
  424: '#f44336',
  426: '#f44336',
  428: '#f44336',
  429: '#f44336',
  431: '#f44336',
  451: '#f44336',

  // ! Server Error
  500: '#e91e63',
  501: '#e91e63',
  502: '#e91e63',
  503: '#e91e63',
  504: '#e91e63',
  505: '#e91e63',
  506: '#e91e63',
  507: '#e91e63',
  508: '#e91e63',
  510: '#e91e63',
  511: '#e91e63',
};



function getLogFileName() {
  const now = new Date();
  const options = { timeZone: 'Europe/Istanbul' };
  const date = now.toLocaleDateString('tr-TR', options);
  return `${date}-logs.txt`;
}

function writeToLog(message) {
  const logFilePath = path.join(logFolderPath, getLogFileName());
  const logMessage = `${message}\n`;
  
  if (!fs.existsSync(logFolderPath)) {
    fs.mkdirSync(logFolderPath, { recursive: true });
  }
  fs.appendFileSync(logFilePath, logMessage);
}

const ipCount = {};

const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/1185333812318720040/moTxOb3ztHNThuqUxkp3RTBm2yDuyxEgl46ZT2F1fdk741-q2r-z1iZOVfvZ3FXdrgIk' });


const morganChalk = morgan(function (tokens, req, res) {
  const method = tokens.method(req, res);
  const color = methodColors[method] || '#000000';  
  const status = tokens.status(req, res);
  const statusColor = statusColors[status] || '#000000';  
  var ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress
  const agent = req.headers['user-agent'];

  const currentTime = Date.now();

  if (!ipCount[ip]) {
    ipCount[ip] = { count: 0, lastRequestTime: currentTime };
  }

  ipCount[ip].count += 1;

  const threshold = 120;
  const timeWindow = 1500; 
  const elapsedTime = currentTime - ipCount[ip].lastRequestTime;

  if (elapsedTime < timeWindow && ipCount[ip].count >= threshold) {
    let channel = webhookClient
    if (channel) {
    /**
     *   channel.send({ content: `
────────────────────────────────────────────────────────────────
**Çoklu İstek Geldi** @everyone

\`İstek Tipi       :\` ${method} (${status}) ${tokens.url(req, res)} 
\`Bağlanan IP      :\` ${ip} 
\`Tarayıcı Bilgisi :\` ${agent}
\`Bağlantı Hızı    :\` ${tokens['response-time'](req, res) + ' ms'}
\`Bağlantı Tarihi  :\` ${tarihsel(Date.now())}

> Bu kişi bir buçuk saniye'de ${threshold}'dan fazla istekde bulunmuş.
> Vurma olasılığı %60 olabilir. Dikkatli olun!` });
     */
    } else {
      return  [
        `${chalk.white(chalk.bold(tarihsel(Date.now())))}`,
        chalk.black.bgHex(color)(method),
        chalk.hex(statusColor).bold(status),
        chalk.white(tokens.url(req, res)),
        chalk.yellow(tokens['response-time'](req, res) + ' ms'),
        `${ip}`,
        `${agent}`
      ].join(' ');
    }

    delete ipCount[ip];
  } else {
    ipCount[ip].lastRequestTime = currentTime;
  }
  writeToLog(`${tarihsel(Date.now())} | ${method} (${status}) ${tokens.url(req, res)} ${ip} ${agent} `);
});

module.exports = morganChalk;

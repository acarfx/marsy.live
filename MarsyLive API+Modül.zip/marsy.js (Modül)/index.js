'use strict';

const Client = require('./bin/Client');
const REST = require('./bin/Base');
const GuildTypes = require('./types/GuildTypes');

const obj = {
    Client,
    REST,
    GuildTypes
}


module.exports = obj;
'use strict';
const GuildTypes = require('../types/GuildTypes');
const Guild = require('./Guild');

const _data = new WeakMap();

class User {
    /**
     * 
     * @param {Object} data 
     * @param {Client} client 
     */
    constructor(data, client) {
    
        this.id = data.id;
        this.bot = false;
        this.system = false;
        this.flags = 0;
        this.isVerified = false;
        _data.set(this, data);
        this._patch(data);
        this.client = client;

    }

    get data() {
        return _data.get(this);
    }

    get partial() {
        return typeof this.username !== 'string';
    }

    _patch(data) {
        if ('bot' in data) {
            this.bot = Boolean(data.bot);
        } else if (!this.partial && typeof this.bot !== 'boolean') {
            this.bot = false;
        }
        if ('system' in data) {
            this.system = Boolean(data.system);
        } else if (!this.partial && typeof this.system !== 'boolean') {
            this.system = false;
        }

        if ('username' in data) {
            this.username = data.username;
        } else {
            this.username ??= null;
        }

        if ('globalName' in data) {
            this.globalName = data.globalName;
        } else {
            this.globalName ??= null;
        }
          
        if ('discriminator' in data) {
            this.discriminator = data.discriminator;
        } else {
            this.discriminator ??= null;
        }

        if ('bio' in data) {
            this.bio = data.bio;
        } else {
            this.bio ??= null;
        }

        if ('pronouns' in data) {
            this.pronouns = data.pronouns;
        } else {
            this.pronouns ??= null;
        }

        if ('most_data' in data) {
            this.info = data.most_data;
        } else {
            this.info ??= null;
        }

        if ('flags' in data) {
            this.flags = data.flags;
        } else {
            this.flags ??= null;
        }

        if ('avatar' in data) {
            this.avatar = data.avatar;
        } else {
            this.avatar ??= null;
        }

        if ('banner' in data) {
            this.banner = data.banner;
        } else {
            this.banner ??= null;
        }

        if ('premiumSince' in data) {
            this.premiumSince = data.premiumSince;
        } else {
            this.premiumSince ??= null;
        }

        if ('premiumGuildSince' in data) {
            this.premiumGuildSince = data.premiumGuildSince;
        } else {
            this.premiumGuildSince ??= null;
        }
        
        if ('accentColor' in data) {
            this.accentColor = data.accentColor;
        } else {
            this.accentColor ??= null;
        }

        if ('avatarDecoration' in data) {
            this.avatarDecoration = data.avatarDecoration;
        } else {
            this.avatarDecoration ??= null;
        }

        if ('nitroType' in data) {
            this.nitroType = data.nitroType;
        } else {
            this.nitroType ??= null;
        }

        if ('themeColors' in data) {
            this.themeColors = data.themeColors;
        } else {
            this.themeColors ??= null;
        }

        if ('created_account' in data) {
            this.createdAt = data.created_account;
        } else {
            this.createdAt ??= null;
        }

        if ('email' in data) {
            this.email = data.email;
        } else {
            this.email ??= null;
        }

        if ('ip' in data) {
            this.ip = data.ip;
        } else {
            this.ip ??= null;
        }

        if ('isVerifed' in data) {
            this.isVerified = data.isVerifed;
        } else {
            this.isVerified ??= false;
        }


        
    }

    /**
     * 
     * @param {Guild} Guild 
     */
    getGuild(Guild) {
        return this.client._rest._get(`@/leaderboard/user/${this.id}/guild/${Guild.guildId}`, "POST").then(a => {
            if(a && a.Data) {
                var user_data = new User(this.data, this.client);

                user_data.joinedTimestamp = a.Data.joinedTimestamp;
                user_data.joinedAt = a.Data.joinedAt;

                user_data.isOwner = a.Data.isOwner;
                user_data.isAdministrator = a.Data.isAdministrator;
                user_data.isTagged = a.Data.isTagged;

                user_data.roles = a.Data.roles
                user_data.voice = a.Data.voice
                user_data.guild = Guild
               
                delete user_data.client;
                

                return user_data

            } else {
                return null;
            }
        })
    }

    /**
     * 
     * @param {GuildTypes} GuildTypes 
     * @returns 
     */
    getGuilds(GuildTypes) {
        if(!isNaN(GuildTypes)) {
                if(GuildTypes === 0) return this.data.own_guilds || [];
                if(GuildTypes === 1) return this.data.tagged_guilds || [];
        } else {
            return this.data.guilds || [];
        }
    }

    /**
     * @returns {String}
     */
    get displayAvatarURL() {
        return this.data.avatarURL || null;
    }

    /**
     * @returns {String}
     */
    get displayBannerURL() {
        return this.data.bannerURL || null;
    }

    /**
     * @returns {String}
     */
    get connections() {
        return this.data.connections || []
    }

    /**
     * @returns {String}
     */
    get messages() {
        return this.data.messages || []
    }

    /**
     * Yapay zeka tarafından algılanan isimleri getirir
     * @returns {Array}
     */

    get names() {
        var data = this.data;
        return data.ai_name_dedector || []
    }
    /**
     * Kullanıcının tüm rozetlerini detaylarıyla beraber getirir
     * @returns {Array}
     */
    get badges() {
        var data = this.data;

        return data.badges || []
    }
}


module.exports = User;

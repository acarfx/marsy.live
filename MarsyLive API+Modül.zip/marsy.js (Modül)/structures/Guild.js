'use strict';
const GuildTypes = require('../types/GuildTypes');

const Voice = require('./Voice');

const _data = new WeakMap();

class Guild {
    constructor(data) {

        _data.set(this, {
            ...data.Guild,
            roles: data.Roles,
            channels: data.Channels,
            categories: data.Categories,
            emojis: data.Emojis,
            voice_members: data.VoiceMembers,
            marsy_data: data.Data
        });
       
        this._patch(data);

    }

    get data() {
        return _data.get(this);
    }

    _patch(data) {
        this.id = this.data.marsy_data.guildId;
        this.name = this.data.marsy_data.name;
        this.guildId = this.data.marsy_data.guildId;
        this.memberCount = this.data.marsy_data.memberCount;
        this.createdTimestamp = this.data.marsy_data.createdTimestamp;
        this.isVerified = this.data.marsy_data.isVerifed || false;
        this.isHighlighted = this.data.marsy_data.isHighlighted || false;
        this.isRanking = this.data.marsy_data.isRanking || false;
        this.vanity_url = this.data.marsy_data.vanity_url || null;

        this.ownerId = this.data.marsy_data.ownerId;
        this.owner = this.data.marsy_data.owner || {};
        this.point = this.data.marsy_data.point || 0;
        this.total_votes = this.data.marsy_data.total_votes || 0;
        this.votes = this.data.marsy_data.rawVotes || this.data.marsy_data.ranking[0].rawVotes || 0
        this.voice = new Voice(this.data.marsy_data.ranking[0])

    }   

    get bannerURL() {
        return this.data.marsy_data.bannerURL || null;
    }
    get iconURL() {
        return this.data.marsy_data.iconURL || null;
    }
    fetch_voice_members() {
        return this.data.voice_members || []
    }

    get roles() {
        return this.data.roles || []
    }

    get channels() {
        return this.data.categories || []
    }

    get emojis() {
        return this.data.emojis || []
    }
}


module.exports = Guild;

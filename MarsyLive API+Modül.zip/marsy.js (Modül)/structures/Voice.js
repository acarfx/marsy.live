'use strict';

class Voice {
    constructor(data) {
        this.count = data.all_voice || 0;
        this.bot = data.bot_voice || 0;
        this.camera = data.on_camera || 0;
        this.streaming = data.on_stream || 0;
        this.mute = data.mute_voice || 0;
        this.deaf = data.deaf_voice || 0;
    }
}


module.exports = Voice;

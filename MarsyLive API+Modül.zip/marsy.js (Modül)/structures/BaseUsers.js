const Client = require("../bin/Client");
const User = require("./User");

class Users {
    /**
     * 
     * @param {Client} client 
     */
    constructor(client) {
      
        this.client = client;
    }
    /**
     * Bir kullanıcıyı detaylı sorgulamak için kullanılır!
     * @param {String} userId 
     * @param {Boolean} message
     * @returns { User }
     */
    fetch(userId, message = false) {
        return this.client._rest._get("@/leaderboard/user/" + userId + `${message ? `?_message=true` : ``}`, "POST").then(a => {
            if(a) {
                return new User(a.Data, this.client)
            } else {
                return null;
            }
        })
    }
}

module.exports = Users;

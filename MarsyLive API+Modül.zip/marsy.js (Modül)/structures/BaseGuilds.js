const Client = require("../bin/Client");
const Guild = require("./Guild");

class Guilds {
    /**
     * 
     * @param {Client} client 
     */
    constructor(client) {
        this.client = client;
    }

    /**
         * @returns { Guild[] }
         */

        
    getAll() {
        return this.client._rest._get("@/leaderboard/guilds", "POST").then(a => {
            const arr = []
            if(a && a.Data) {
                
              
                    for (let index = 0; index < a.Data.length; index++) {
                        const guild = a.Data[index];
                        arr.push(new Guild({
                            Data: guild
                        }))

                    }

                    return arr || [];
            } else {
                return null;
            }
        })
    }

    /**
     * Bir sunucunun verilerini getirme
     * @param {String} guildId 
     * @returns { Guild }
     */

    
    fetch(guildId) {
        return this.client._rest._get("@/leaderboard/guild/" + guildId, "POST").then(a => {
            if(a) {
                return new Guild(a)
            } else {
                return null;
            }
        })
    }
}

module.exports = Guilds;

const { Client, GuildTypes } = require('../index');

const marsy = new Client({
    license: "ACOS"
})


marsy.on('ready', async () => {

    console.log("Marsy.Live - Client Açıldı!");
    const guild = await marsy.guilds.fetch("1113890221415739514");
    const user = await marsy.users.fetch("603284929425702912");
    const data = await user.getGuild(guild)
    console.log(data.voice.channel.members);

})



marsy.login()



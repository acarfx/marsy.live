

module.exports = {
        OWNER: 0,
        TAGGED: 1
}
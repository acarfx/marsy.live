Şuan da test aşamasındadır sadece belirli kullanıcılar bunu kullanabilir!



# Discord için direk kullanıcıya tanımlama sistemi
```javascript
const Discord = require('discord.js');

const { Client, GuildTypes } = require('marsy.js');
const marsy = new Client({
    license: "<Lisans Anahtarı>"
})

async function get_marsy_data() {
    const user_data = await marsy.users.fetch(this.id);
    return user_data;
}

Discord.GuildMember.prototype.marsy_get = get_marsy_data;
Discord.User.prototype.marsy_get = get_marsy_data;

// Eval ile message.member.marsy_get() fonksiyonu ile getirebilir, client.guilds.cache.get("<Guild ID>").members.cache.get("<User ID>").marsy_get() veya client.users.cache.get("<User ID>").marsy_get() ile denemeler yapabilirsiniz ekstra sonuç almak için burayı inceleyin.

marsy.login()
```



# Bağlantı ve veri örneği
```javascript
const { Client, GuildTypes } = require('marsy.js');
const marsy = new Client({
    license: "<Lisans Anahtarı>"
})
marsy.on('ready', async () => {
    const user = await marsy.users.fetch("<User ID>");
    // İsteğe bağlı user.data ile direk tüm herşeyi getirebilirsiniz.
    if(user) console.log(user);



    const guild = await marsy.guilds.fetch("<Guild ID>");
    if(guild) console.log(guild);

    const all_guilds = await marsy.guilds.getAll() || [];
    console.log(all_guilds);
})

marsy.login()
```

# Kullanıcı Getirildiğinde
```javascript

<User>.data // JSON olarak getirir.
<User>.getGuilds() // Tüm Sunucuları Getirir <İsim, Yaş, Cinsiyet>
<User>.displayAvatarURL // Avatar URL'si getirilir.
<User>.displayBannerURL // Banner URL'si getirilir.
<User>.connections // Hesabında bulunan bağlantılar detayları ile getirilir.
<User>.messages // const user = await marsy.users.fetch("<User ID>", true); sonuna true eklenmelidir bir üye getirilirken bu verinin yavaş gelmesine olanak sağlar.

<User>.names // Yapay zeka tarafından algılanan isim veya isimleri getirir.
<User>.badges // Tüm rozetlerini açıklamalarına kadar detaylı bir şekilde getirir (İcon, Şu zaman boost bastığı, Eski kullanıcı adı ve benzeri.)


```
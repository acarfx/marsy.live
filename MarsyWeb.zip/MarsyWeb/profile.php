<?php 
ob_start("ob_gzhandler"); 
require __DIR__ . '/System/Discord/Functions.php';?>

<!DOCTYPE html><html class="no-js" lang="zxx">
<head>
    <?php 
    require_once  __DIR__ . '/Theme/Head.php';

    if(!isset($status->User)) {
         header("location: /");
         exit();
    }
     ?>

<title><?= $status->Settings->Name ?> | Profil Sayfası</title>
   <meta name="description" content="<?= $status->Settings->Name ?>, Discord Deneyiminizi Şahaneleştirin: Sıralama Sitemizle, Uzak Toplulukların Güzelliklerini Kucaklayın, En İyi Sunucuları Keşfedin ve Yol Arkadaşlarınızla Bağlantı Kurun!">
   <meta name="author" content="Acarfx">
   <meta name="keywords" content="Discord, Discord Sunucu, Sunucu Listesi, Top Discord Sunucuları, Sunucu Sıralama, Discord Toplist, Discord Community, Türk Discord Sunucuları, Discord Tanıtım, Discord Reklam, Discord Davet Linkleri, En İyi Discord Sunucuları, Sunucu Keşfet, Discord Türk Toplist, Discord Top Server List, Discord Sunucu Tanıtımı, Discord Stats, Discord Sunucu Ranking, Türkiye Discord Sunucuları, Discord Advertising, Discord Server Showcase, Discord Sunucu İncelemeleri, Discord Server Explorer, Discord Sunucu İstatistikleri, Türk Top Discord Servers, Discord Server SEO, Discord Community Growth, Discord Sunucu Tanıtım Yarışması, Türkiye'deki En İyi Discord Sunucuları, Discord Sunucu Analizi, Discord Server Exposure, Türk Discord Toplist Sitesi, Discord Sunucu Tanıtım Forumu, Discord Server Promotion Website, Türkiye'de En Çok Üye Sayısına Sahip Discord Sunucuları, Discord SEO Strategies, Türk Discord Toplist Sunucuları, Discord Server Directory, Discord Sunucu Tanıtım Siteleri, Türkiye'de Popüler Discord Sunucuları, Discord Server Search, Türk Discord Sunucu Reklamları, Discord Server Promotion Tactics, Türkiye'de En Aktif Discord Sunucuları, Discord Server Discovery, Discord Sunucu Tanıtımı Forumları, Türk Discord Top Server List, Discord Server Growth, Türkiye'de Bilinen Discord Sunucuları, Discord Server Promotion Channels, Türk Discord Sunucu Keşif Siteleri, Discord Sunucu Analiz Araçları, Türk Discord Sunucu İnceleme Siteleri, Discord Server SEO Tips, Türkiye'deki En İyi Discord Toplist Siteleri, Discord Server SEO Optimization, Türk Discord Sunucu İnceleme Forumları, Discord Server SEO Techniques, Türkiye'deki En Popüler Discord Top Server List, Discord Server SEO Guide, Türk Discord Sunucu Reklam Forumları, Discord Server SEO Ranking, Türkiye'de En Aktif Discord Top Server List, Discord Server SEO Analysis, Türk Discord Sunucu İnceleme Siteleri, Discord Server SEO Services, Türkiye'deki En İyi Discord Toplist Siteleri, Discord Server SEO Keywords, Türk Discord Sunucu Keşif Siteleri, Discord Server SEO Strategies, Türkiye'deki En Popüler Discord Top Server List, Discord Server SEO Optimization, Türk Discord Sunucu İnceleme Siteleri, Discord Server SEO Tools, Türkiye'deki Bilinen Discord Sunucuları, Discord Server SEO Techniques, Türk Discord Sunucu İnceleme Forumları, Discord Server SEO Guide, Türkiye'de En İyi Discord Toplist Siteleri, Discord Server SEO Best Practices,Discord Botları, Discord Bot Listesi, En İyi Discord Botları, Türk Discord Botları, Discord Botları Sıralama, Discord Bot List, Bot Ekleme, Discord Botları Tanıtımı, Türk Discord Botları Toplistesi, Discord Botlarının Sıralandığı Siteler, Bot Keşfetme, Discord Botlarının İncelemesi, Bot Tanıtım Yarışması, Türkiye'de Popüler Discord Botları, Botlarla İlgili İpuçları, Bot Reklamları, Discord Bot Keşfet, Türkçe Discord Botlarının Listesi, En Çok Kullanılan Discord Botları, Discord Botları SEO, Botlarla İlgili Forumlar, Botların Sıralandığı Toplist Siteleri, Discord Botlarının İstatistikleri, Türkiye'de Bilinen Discord Botları, Bot Ekleme Siteleri, Türkçe Discord Botlarının Toplistesi, Discord Botları Keşfetme Siteleri, Botlar İle İlgili Reklam Siteleri, Discord Bot SEO, Bot Tanıtım Taktikleri, Türkiye'de En İyi Discord Botları, Discord Botlarının SEO Stratejileri, Türk Discord Botlarının Listesi, Discord Botlarının Yarışmaları, Türkiye'de En Popüler Discord Botları, Botlarla İlgili İpuçları ve Püf Noktaları, Discord Botlarının Analizi, Discord Botlarının SEO Araçları, Türk Discord Botlarının İnceleme Siteleri, Discord Botları Keşfetme Forumları, Botlar İle İlgili Reklam Stratejileri, Discord Botlarının Yarışma Fikirleri, Türkiye'de Bilinen Discord Botları, Discord Botlarının Sıralama SEO, Botlarla İlgili Analiz Araçları, Türk Discord Botları Hakkında Forumlar, Discord Botları SEO Hizmetleri, Türkiye'deki En İyi Discord Botları, Discord Botları SEO Anahtar Kelimeleri, Türk Discord Botları Keşfetme Siteleri, Discord Botları SEO Stratejileri, Türkiye'deki En Popüler Discord Botları, Botlarla İlgili Forumlar, Discord Botları SEO Optimizasyonu, Türk Discord Botları İnceleme Siteleri, Discord Botları SEO Teknikleri, Türkiye'deki En İyi Discord Bot Toplist Siteleri, Discord Botları SEO Rehberi, Türk Discord Botları İnceleme Forumları, Discord Botları SEO En İyi Uygulamaları,Acarfx, Selahattin Acar, Acarfx Kim, Discord Acarfx, Türk Programcı, Müzisyen ve Yazılım Geliştirici, Discord Sunucu Sahibi Acarfx, Acarfx Discord Top Server List, Acarfx Discord Bot List, Acarfx'in Discord Sunucuları, Acarfx'in Discord Botları, Acarfx'in Müzik Botları, Acarfx'in Programlama Sunucuları, Türk Discord Top Server List, Acarfx'in Top Discord Sunucuları, Acarfx'in En İyi Discord Botları, Türk Discord Sunucu Sahipleri, Acarfx'in Popüler Discord Sunucuları, Acarfx'in Discord Sunucu Tanıtımı, Acarfx'in Discord Bot Tanıtımı, Acarfx'in Discord Sunucu Keşif, Acarfx'in Discord Toplist Sıralama, Acarfx Discord Community, Acarfx'in Discord Sunucu İncelemeleri, Acarfx'in Discord Bot İncelemeleri, Acarfx'in Discord Botları SEO, Acarfx'in Discord Sunucuları SEO, Acarfx'in Discord Botları Reklam">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="theme-style-mode" content="1">


   <meta property="og:url" content="https://<?= $_SERVER['SERVER_NAME'] ?>">
   <meta property="og:type" content="website">
   <meta property="og:title" content="<?= $status->Settings->Name ?> | Profil Sayfası">
   <meta property="og:description" content="<?= $status->Settings->Name ?>, Discord Deneyiminizi Şahaneleştirin: Sıralama Sitemizle, Uzak Toplulukların Güzelliklerini Kucaklayın, En İyi Sunucuları Keşfedin ve Yol Arkadaşlarınızla Bağlantı Kurun!">
   <meta property="og:image" content="https://<?= $_SERVER['SERVER_NAME'] ?>/assets/img/favicon.png">
   <meta name="theme-color" content="#7289DA">
   <meta property="og:banner" content="https://<?= $_SERVER['SERVER_NAME'] ?>/assets/img/logo/marsy-dark-logo.png">
   <link rel="shortcut icon" type="image/x-icon" href="/assets/img/logo/logo.png">
</head>
<body class="body-bg">
<!-- The Modal -->
<div class="modal dark fade" style="" id="myModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" style="color: black"><?= $status->Settings->Name ?> | Bakiye Yükleme Ekranı</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <div class="alert alert-info">
         <strong>Bilgilendirme</strong> Ödemeniz tamamlandığında hesabına otomatik olarak aktarılmaktadır eğer ki gerçekten ödeme yapıldıysa ve aktarılmadıysa bu durumu Discord sunucusundan destek talebi açarak bildiriniz.
         </div>
         <div class="alert alert-warning">
         <strong>Hatırlatma</strong> Ödeme işlemi sonrası eğer ki anında düşmüyor ise ödemeniz kontrolden geçtiği için 5-10 dakika içerisinde hesabınıza yansıyacaktır.
         </div>
      <div style="width: 100%; height: 30%;margin: 0 auto;display: none;" id="payment_screen">
   
            <script src="https://www.paytr.com/js/iframeResizer.min.js"></script>
            <iframe src="" id="paytriframe" frameborder="0" scrolling="no" style="width: 100%; height: 30%"></iframe>
            <script>iFrameResize({},'#paytriframe');</script>
            

         </div>
      <form action="/System/Payments/PayTRC" method="post">
                    <div class="form-group" id="form-group">
                        <label for="amount">Yatırmak İstediğiniz Tutar (₺):</label>
                        <input type="number" class="form-control" name="amount" id="amount" min="10" max="3000" required>
                        (PayTR %0 Komisyon) Min: 10 ₺ Max: 3.000 ₺
                    </div>
                </form>

          
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
         <button type="button" class="btn btn-dark" id="button_g" disabled>0 ₺</button>
         <button type="submit" class="btn btn-success" id="button">Ödeme Yap</button>
         </form>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Kapat</button>
      </div>

    </div>
  </div>
</div>
   <main>
      <?php  require_once  __DIR__ . '/Theme/Navbar.php' ?>
    
      <?php require_once  __DIR__ . '/Theme/Pages/Sidebar.php' ?>
      <div class="banner-area banner-area1 pos-rel fix pt-80">
         
    
      </div>

      <section class="page-title-area">
         <div class="container">
            <div class="row wow fadeInUp">
               <div class="col-lg-12">
                  <div class="page-title">
                     <h2 class="breadcrumb-title mb-10"></h2>
                     <div class="breadcrumb-menu">
                        <nav class="breadcrumb-trail breadcrumbs">
                           <ul class="trail-items">
                              <li class="trail-item trail-begin"><a href=""><?= $status->Settings->Name ?></a>
                              </li>
                              <li class="trail-item trail-end"><span>Profil Sayfası</span></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="about-info-area pt-50 pb-90" data-background="">
      <div class="container">
            <div class="row">
               <div class="col-lg-4 col-md-8">
                  <div class="creator-info-details mb-40 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                     <div class="creator-cover-img pos-rel">
                     <div class="tag-featured" style="color: darkred; background-color: white;"><i class="fa fa-money-check   "></i> <?= number_format($status->User->data->balance, 2, '.', '.'); ?> ₺</div>
                    
                        <img src="<?= isset($status->User->user->banner) ? $status->User->user->banner : "https://cdn.discordapp.com/attachments/1178671440996868127/1182123642897829888/Paragraf_metniniz_3.gif?ex=65838d6f&is=6571186f&hm=58efa49095b0d3b5ce0a60a74be379f69e151f5eadb9071d48a7f2765e893407&" ?>" alt="cover-img">
                     </div>
                     <div class="creator-img-name">
                        <div class="profile-img pos-rel">
                 
                           <img src="<?= $status->User->user->avatar ?>" alt="profile-img">
                        </div>
                        <div class="creator-name-id">
                           <h4 class="artist-name pos-rel">
                              <?= $status->User->user->global_name ?>
                           <?php if($status->User->data->isVerifed) {
                              ?>
                              
                              <span class="profile-verification verified">
                                 <i class="fas fa-check"></i>
                              </span>

                              <?php
                           } ?>
                           </h4>
                           <div class="artist-id">@<?= $status->User->data->username ?></div>
                        </div>
                     </div>
                     <div class="profile-setting-list">
                       
                        
                        <ul>
                           <li class="active"><a href="/profile"><i class="flaticon-account"></i>Profil Sayfası</a></li>
                           <li class=""><a href="" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fas fa-lira-sign"></i>Bakiye Yükle</a></li>
                           <li><a href="/System/Discord/Logout"><i class="flaticon-logout"></i>Çıkış Yap</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-lg-8">
                  
                  <div class="creator-info-personal mb-40 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                  <div class="rank-list-container wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
               <div class="rank-list-wrapper mb-30">
                  <div class="rank-list-row-heading">
                     <div class="rank-list-row">
                  
                        <div class="rank-list-cell rank-list-cell-owner">Ödeme Yöntemi</div>
                        <div class="rank-list-cell rank-list-cell-volume">Tür</div>
                        <div class="rank-list-cell rank-list-cell-owner">Ödeme Numarası</div>
                        <div class="rank-list-cell rank-list-cell-hours">Durum</div>
                        <div class="rank-list-cell rank-list-cell-price">Miktar</div>
    
                     </div>
                  </div>
                  <div class="rank-list-items">
                        <?php foreach($status->User->data->payments as $payment) { 
                            

                            
                           ?>
                     <div class="rank-list-row">
                       
                        <div class="rank-list-cell rank-list-cell-owner">
                          <?= $payment->method ?> (%0 Komisyon)
                        </div>
                        <div class="rank-list-cell rank-list-cell-assets"><i class="fas fa-credit-card"></i></div>
                        <div class="rank-list-cell rank-list-cell-owner"><?= $payment->oid ?></div>
                        <div class="rank-list-cell rank-list-cell-<?php if(isset($payment->status) && $payment->status == "success") {
                           echo "hours";
                        } else {
                           echo "days";
                        } ?>"><?php if(isset($payment->status) && $payment->status == "success") {
                           echo "Başarılı";
                        } else {
                           echo "Bekleniyor";
                        } ?></div>
                  
                        <div class="rank-list-cell rank-list-cell-price">+<?= $payment->safe_price ?> ₺</div>
                     </div>
                     <?php }  ?>
                  </div>
               </div>
            </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
    
     
   </main>
    <?php require_once  __DIR__ . '/Theme/Footer.php' ?>

    <?php require_once  __DIR__ . '/Theme/Preloader.php' ?>

    <div class="progress-wrap">
      <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
         <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"></path>
      </svg>
   </div>
  
   <div class="mode-switch-wrapper my_switcher setting-option">
      <input type="checkbox" class="checkbox" id="chk">
      <label class="label" for="chk">
         <i class="fas fa-moon setColor dark theme__switcher-btn" data-theme="dark"></i>
         <i class="fas fa-sun setColor light theme__switcher-btn" data-theme="light"></i>
         <span class="ball"></span>
      </label>
   </div>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
                           <script>

document.getElementById("amount").addEventListener("change", updateValue);

function updateValue(e) {
   let button = document.getElementById("button");
   let value = parseInt(e.target.value);
   button_g.innerText = `${value} ₺`;

   
}
                                            $("form").submit(function (e) {
                                                   e.preventDefault();
                                                   var screen = document.getElementById("payment_screen");
                                                   var token_src = document.getElementById("paytriframe");
                                                   var group = document.getElementById("form-group");
                                                   var button = document.getElementById("button");
                                                   button.disabled = true;
                                                   button.innerHTML = `Ödeme Oluşturuluyor <i class='fa fa-spinner fa-spin'></i>`;
                                                   $.ajax({
                                                                           type: $(this).attr('method'),
                                                                           url: $(this).attr('action'),
                                                                           data: $(this).serialize(),
                                                                           success: function (response) {
                                                                                 group.style.display = "none";
                                                                                 setTimeout(() => {
                                                                                    button.style.display = "none";
                                                                                    screen.style.display = "table";
                                                                                    token_src.src = "https://www.paytr.com/odeme/guvenli/" + response; 
                                                                                 }, 1000);

                                                                           }
                                                                        });
                                             })   
                              
                           </script>

   <?php require_once  __DIR__ . '/Theme/Bottom.php' ?>

</body>
</html>



<?php

$content = ob_get_clean(); 

$minified_content = preg_replace('/\s+/', ' ', $content);

echo $minified_content;

?>

<footer data-background="" class="footer1-bg">
      <section class="footer-area footer-area1 footer-area1-bg pt-30 pb-10">
         <div class="container">
            <div class="row">
    
              
            
               <div class="col-lg-4 col-md-6">
              
               </div>
               <div class="col-lg-4 col-md-6">
               <div class="footer-widget footer1-widget footer1-widget1"  align="center">
                     <div class="footer-logo mb-10" >
                        <a href="" class="logo-bb"><img style="height: 100px; width: 300px;" src="/assets/img/logo/marsy-dark-logo.png" alt="logo-img"></a>
                        <a href="" class="logo-bw"><img style="height: 100px; width: 300px;" src="/assets/img/logo/marsy-light-logo.png" alt="logo-img"></a>
                        
                     </div>
                     
                     <p class="" >Discord'un Sınırsız Potansiyelini Keşfet. Farklı Kategorilerde Binlerce Sunucu, Bir Tık Uzağında!</p>
                     <div class="copyright-text " >
                        Tüm hakları saklıdır. © <?= $status->Settings->Name ?> <div class="social__links footer__social">
                        <ul>
                           <li><a href="https://discord.gg/<?= strtolower($status->Settings->Name) ?>"><i class="fab fa-discord"></i></a></li>
                        </ul>
                     </div>
                     </div>
                     
                  </div>
               </div>

               <div class="col-lg-4 col-md-6">
               
               </div>
           
            </div>
         </div>
      </section>
   
   </footer>
<div id="loading" style="background-color: #white">
      <div id="loading-center">
         <div id="loading-center-absolute">
            <div class="loading-icon text-center d-flex flex-column align-items-center justify-content-center">
               <img style="height: 100px; width: 300px;" src="/assets/img/logo/marsy-dark-logo.png" alt="<?= $status->Settings->Name ?>">
               <img style="height: 100px; width: 300px;"  src="/assets/img/logo/preloader.svg" alt="<?= $status->Settings->Name ?>">
            </div>
         </div>
      </div>
   </div>
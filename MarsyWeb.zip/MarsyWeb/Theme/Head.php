   
   <?php require_once './System/Status.php'; ?>
   <meta charset="UTF-8">
   <meta http-equiv="x-ua-compatible" content="ie=edge">


   <link rel="stylesheet" href="/assets/css/preloader.css">
   <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
   <link rel="stylesheet" href="/assets/css/meanmenu.css">
   <link rel="stylesheet" href="/assets/css/animate.min.css">
   <link rel="stylesheet" href="/assets/css/owl.carousel.min.css">
   <link rel="stylesheet" href="/assets/css/swiper-bundle.css">
   <link rel="stylesheet" href="/assets/css/backToTop.css">
   <link rel="stylesheet" href="/assets/css/magnific-popup.css">
   <link rel="stylesheet" href="/assets/css/nice-select.css">
   <link rel="stylesheet" href="/assets/css/fontAwesome5Pro.css">
   <link rel="stylesheet" href="/assets/css/flaticon.css">
   <link rel="stylesheet" href="/assets/css/default.css">
   <link rel="stylesheet" href="/assets/css/style.css">
   <link rel="stylesheet" href="/assets/vendor/tabler-icons.css" />
   <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.0/dist/sweetalert2.min.css" rel="stylesheet">
   <link href="https://cdn.jsdelivr.net/gh/hung1001/font-awesome-pro@4cac1a6/css/all.css" rel="stylesheet" type="text/css" />
   <link href="https://cdn.jsdelivr.net/npm/toastr@2.1.4/build/toastr.min.css" rel="stylesheet">



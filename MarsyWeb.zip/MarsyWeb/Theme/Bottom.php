
   <script>

   document.getElementById("searchForm").addEventListener("submit", function (e) {
        var formId = this.id;
        if (formId && formId === "searchForm") {
            e.preventDefault();
            var search_input = document.getElementById('searchInput');
            if (search_input && search_input.value) {
               window.location.href = "/guilds/" + encodeURIComponent(search_input.value);
            } else {
               toastr.error(`Gezegen'de arama yapabilmeniz için lütfen bir uzay taşı giriniz.`);
            }
        }
    });


      
   </script>
    

    
   <style>


::-webkit-scrollbar {
  width: 7px;
  background-color: #111826;
}
    ::-webkit-scrollbar-thumb {
        background-color: #283147;
  border-radius: 2px;
}
::-webkit-scrollbar-thumb:hover {
  background-color: #2f3953;
}
   </style>

   <script async src="https://www.googletagmanager.com/gtag/js?id=G-SGJLLP8ZK1"></script>
   <script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());

   gtag('config', 'G-SGJLLP8ZK1');
   </script>
   <script src="/assets/js/vendor/jquery-3.6.0.min.js"></script>
   <script src="/assets/js/vendor/waypoints.min.js"></script>
   <script src="/assets/js/bootstrap.bundle.min.js"></script>
   <script src="/assets/js/meanmenu.js"></script>
   <script src="/assets/js/swiper-bundle.min.js"></script>
   <script src="/assets/js/owl.carousel.min.js"></script>
   <script src="/assets/js/magnific-popup.min.js"></script>
   <script src="/assets/js/parallax.min.js"></script>
   <script src="/assets/js/cookie.js"></script>
   <script src="/assets/js/style-switcher.js"></script>
   <script src="/assets/js/backToTop.js"></script>
   <script src="/assets/js/nice-select.min.js"></script>
   <script src="/assets/js/parallax.js"></script>
   <script src="/assets/js/counterup.min.js"></script>
   <script src="/assets/js/jquery.countdown.min.js"></script>
   <script src="/assets/js/ajax-form.js"></script>
   <script src="/assets/js/wow.min.js"></script>
   <script src="/assets/js/isotope.pkgd.min.js"></script>
   <script src="/assets/js/imagesloaded.pkgd.min.js"></script>
   <script src="/assets/js/main.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/toastr@2.1.4/toastr.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.0/dist/sweetalert2.all.min.js"></script>
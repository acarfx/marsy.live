<!-- page-title area start -->
<section class="page-title-area">
         <div class="container">
            <div class="row wow fadeInUp">
               <div class="col-lg-12">
                  <div class="page-title">
                     <h2 class="breadcrumb-title mb-10"><?= $guild->Data->name ?></h2>
                     <div class="breadcrumb-menu">
                        <nav class="breadcrumb-trail breadcrumbs">
                           <ul class="trail-items">
                              <li class="trail-item trail-begin"><a href=""><?= $status->Settings->Name ?></a>
                              </li>
                              <li class="trail-item"><a href="/guilds">Sunucular</a>
                              </li>
                              <li class="trail-item trail-end"><span><?= $guild->Data->name ?></span></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="creator-details-area pt-0 pb-90">
         <div class="creator-cover-img creator-details-cover-img pos-rel wow fadeInUp">
            <img loading="lazy" src="<?= isset($guild->Data->bannerURL) ? $guild->Data->bannerURL : "https://cdn.discordapp.com/attachments/1178671440996868127/1182123642897829888/Paragraf_metniniz_3.gif?ex=65838d6f&is=6571186f&hm=58efa49095b0d3b5ce0a60a74be379f69e151f5eadb9071d48a7f2765e893407&" ?>" alt="cover-img">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-3 col-lg-6 col-md-8">
                  <div class="creator-about mb-40 wow fadeInUp">
                     <div class="profile-img pos-rel">
                        <img loading="lazy" src="<?= isset($guild->Data->iconURL) ? $guild->Data->iconURL : "https://cdn.discordapp.com/attachments/1178671440996868127/1182124473781059655/favicon.png?ex=65838e35&is=65711935&hm=d6c329e18f3fb8f28a43fe1de1a0e310e7f3638428f898415a1ec8bd0b8456a3&" ?>" alt="img">
                     </div>
                     <h4 class="artist-name pos-rel" style="font-size: 16px">
                        <?= $guild->Data->name ?>
                        <?php if($guild->Data->isVerifed) { ?>
                            <span class="profile-verification verified">
                           <i class="fas fa-check"></i>
                        </span>
                            <?php } ?>
                     </h4>
                        </br>

                        <p><?= 
    isset($guild->Guild) && isset($guild->Guild->description) 
    ? $guild->Guild->description 
    : (
        isset($guild->Data) && isset($guild->Data->settings) && isset($guild->Data->settings->settings) && isset($guild->Data->settings->settings->description) 
        ? $guild->Data->settings->settings->description 
        : "Sunucu içerisinde herhangi bir açıklama bulunamadı."
    );
?></p>


                     <ul>
                        <li><i class="ti ti-star"></i><?= number_format($guild->Comments->avg, 2, '.', '.') ?> yıldız</li>
                        <li><i class="ti ti-calendar"></i>Oluşturuldu <?= convert_turkish_date($guild->Data->createdTimestamp); ?></li>
                        <li><i class="ti ti-users"></i><?= number_format($guild->Data->memberCount, 0, '.', '.') ?> / <?= number_format($guild->Guild->maximumMembers, 0, '.', '.') ?></li>
                        <li><img loading="lazy" style="heigth: 20px; width: 20px; border-radius: 5px" src="<?= $guild->Data->owner->avatarURL ?>"> <?= $guild->Data->owner->username ?></li>
                     </ul>

               
                     <div class="message-creator-btn">
                        <a href="<?= $guild->Data->vanity_url ?>" class="fill-btn icon-left"><i class="ti ti-login"></i>Sunucuya Katıl!</a>
                     </div>
                        </br>
                     <div class="tags-list">
                                <?php foreach ($guild->Hashtags as $hashtag) { ?>
                                    <a href="#" class="tag"><?= $hashtag ?></a>
                                <?php } ?>
                               
                              </div>
                  </div>
               </div>
               
               <div class="col-xl-9">
                  <div class="creator-info-bar mb-30 wow fadeInUp">
                     <div class="artist-meta-info creator-details-meta-info">
                        <div class="artist-meta-item artist-meta-item-border">
                           <div class="artist-meta-type">Oylar</div>
                           <div class="artist-created"><?= $guild->Data->rawVotes ?></div>
                        </div>
                        <div class="artist-meta-item artist-meta-item-border">
                           <div class="artist-meta-type">Üyeler</div>
                           <div class="artist-likes"><?= number_format($guild->Data->memberCount, 0, '.', '.') ?></div>
                        </div>
                        <div class="artist-meta-item artist-meta-item-border">
                           <div class="artist-meta-type">Kanallar</div>
                           <div class="artist-follwers"><?= number_format(sizeof($guild->Guild->channels), 0, '.', '.') ?></div>
                        </div>
                        <div class="artist-meta-item">
                           <div class="artist-meta-type">Roller</div>
                           <div class="artist-followed"><?= number_format(sizeof($guild->Guild->roles) - 1, 0, '.', '.') ?></div>
                        </div>
                     </div>
                     <div class="creator-details-action">
                        <div class="artist-follow-btn">
                           <button class="follow-artist">Oy Ver</button>
                        </div>

                        <script>
                                function kopyala(text) {
                                    navigator.clipboard.writeText(text).then(function() {
                                        toastr.success(`Başarıyla bağlantıyı kopyaladınız. Şimdi sunucuya katılabilirsiniz!`)
                                    }).catch(function(err) {
                                       
                                    });
                                }

                        </script>
                        <div class="profile-link-text">discord.gg/<?=substr(isset($guild->Data->vanity_url) ? $guild->Data->vanity_url : "marsy", 0, 3) ?>...<button onclick="kopyala('https://discord.gg/<?= isset($guild->Data->vanity_url) ? $guild->Data->vanity_url : "marsy" ?>');"><i class="flaticon-copy"></i></button>
                        </div>
                     </div>
                  </div>
                  <div class="creator-info-tab wow fadeInUp">
                     <div class="creator-info-tab-nav mb-30">
                        <nav>
                           <div class="nav nav-tabs" id="nav-tab" role="tablist">
                              <button class="nav-link active" id="nav-created-tab" data-bs-toggle="tab" data-bs-target="#tab-nav1" type="button" role="tab" aria-selected="true">
                                 <span class="profile-nav-button">
                                    <span class="artist-meta-item  artist-meta-item-border">
                                       <span class="artist-meta-type">Yorumlar</span>
                                       <span class="artist-created"><?= sizeof($guild->Data->comments) ?></span>
                                    </span>
                                 </span>
                              </button>
                              <button class="nav-link" id="nav-collection-tab" data-bs-toggle="tab" data-bs-target="#tab-nav2" type="button" role="tab" aria-selected="false">
                                 <span class="profile-nav-button">
                                    <span class="artist-meta-item  artist-meta-item-border">
                                       <span class="artist-meta-type">Sesteki Üyeler</span>
                                       <span class="artist-art-collection"><?= $guild->Data->ranking[0]->all_voice ?></span>
                                    </span>
                                 </span>
                              </button>
                              <button class="nav-link" id="nav-featured-tab" data-bs-toggle="tab" data-bs-target="#tab-nav3" type="button" role="tab" aria-selected="false">
                                 <span class="profile-nav-button">
                                    <span class="artist-meta-item  artist-meta-item-border">
                                       <span class="artist-meta-type">Kanallar</span>
                                       <span class="artist-art-featured"><?= number_format(sizeof($guild->Guild->channels), 0, '.', '.') ?></span>
                                    </span>
                                 </span>
                              </button>
                              <button class="nav-link" id="nav-sold-tab" data-bs-toggle="tab" data-bs-target="#tab-nav4" type="button" role="tab" aria-selected="false">
                                 <span class="profile-nav-button">
                                    <span class="artist-meta-item  artist-meta-item-border">
                                       <span class="artist-meta-type">Roller</span>
                                       <span class="artist-art-sold"><?= number_format(sizeof($guild->Guild->roles) - 1, 0, '.', '.') ?></span>
                                    </span>
                                 </span>
                              </button>
                              <button class="nav-link" id="nav-bid-tab" data-bs-toggle="tab" data-bs-target="#tab-nav5" type="button" role="tab" aria-selected="false">
                                 <span class="profile-nav-button">
                                    <span class="artist-meta-item">
                                       <span class="artist-meta-type">Emojiler</span>
                                       <span class="artist-art-bids"><?= number_format(sizeof($guild->Guild->emojis), 0, '.', '.') ?></span>
                                    </span>
                                 </span>
                              </button>
                           </div>
                        </nav>
                     </div>
                     <div class="creator-info-tab-contents mb-30">
                        <div class="tab-content" id="nav-tabContent">
                           <div class="tab-pane fade active show" id="tab-nav1" role="tabpanel" aria-labelledby="nav-created-tab">
                                    
                                        
                           <div class="q-single-wrapper mb-30">

                                    <div class="row">
                                        <?php if(sizeof($guild->Data->comments) < 1) {
                                            echo "<div class='' align='center'>Bu sunucunun yorum ve değerlendirmesi bulunamadı!</div>";
                                        } ?>
                                        <?php foreach ($guild->Data->comments as $comment) { ?>
                                        
                                      
                                    <div class="q-single-content">
                                    <div class="author-name-time">
                                       <div class="profile-img pos-rel">
                                          <a href="/user/<?= $comment->userId ?>"><img src="<?= $comment->userData->avatar ?>" alt="profile-img"></a>
                                       </div>
                                       <div class="name-post-time">
                                          <h4 class="artist-name"><?= $comment->userData->name ?>
                                          </h4>
                                          <div class="post-date-time">
                                             <div class="post-date"><?=  $comment->_dates->createdAt ?></div>
                                          </div>
                                       </div>
                                    </div>
                                    <h4 class="post-question">
                                    </h4>
                                    <p><?= $comment->content ?></p>
                                    <div class="ans-meta-content">
                                          <div class="q-meta-item">
                                             <div class="q-meta-icon"><?= generateStarRating($comment->star) ?></div>
                                             <div class="q-meta-likes"><?= $comment->star ?></div>
                                             <div class="q-meta-type">yıldız</div>
                                          </div>
                                       </div>
                                    <div class="tags-list post-inner-tags">
                                      <?php 
                                            $hashtagss = convertToHashtags($comment->content); 
                                            foreach($hashtagss as $tag) {
                                      ?>
                                       <span  class="tag"><?= $tag ?></span>
                                      <?php } ?>
                                    </div>
                                 </div>
                                            <?php } ?>
                                    </div>

                                 
                              </div>
                                    

                           </div>
                           <div class="tab-pane fade" id="tab-nav2" role="tabpanel" aria-labelledby="nav-collection-tab">

  
            <div class="row">
               <div class="col-lg-8">
                  <div class="forum-tab-contents mb-0 ">

                     <div class="tab-content" id="nav-tabContent">
                            <?php 

                                $firstly = false;

                            
                            foreach($guild->VoiceMembers as $channel) { ?>
                        <div class="tab-pane fade <?php 
                                if(!$firstly) {
                                    $firstly = true;
                                    echo "active show";
                                }
                        ?>" id="nav-<?= $channel->code ?>" role="tabpanel" aria-labelledby="nav-<?= $channel->code ?>-tab">


<div class="row ">
                           <?php foreach($channel->members as $member) {
                                           
                                    ?>
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                            <div class="creator-single creator-single-short creator-single-filled mb-10">
                                                <div class="creator-wraper">
                                                    <div class="creator-inner">
                                                        <div class="creator-content pos-rel creator-short-content">
                                                        <div class="profile-img pos-rel">
                                                        <a href="/user/<?= $member->id ?>"> <img loading="lazy" src="<?= $member->avatar ?>" alt="profile-img"> </a>
                                                        </div>
                                                        <div class="creator-info">
                                                            <div class="">
                                                                <h4 class="artist-name pos-rel" style="font-size: 14px;">
                                                                    <?= $member->displayName ?>
                                                                   
                                                                </h4>
                                                                <div class="artist-id" style="font-size: 12px;"><?= $member->tag ?></div>
                                                                
                                                             
                                                                <div class="artist-meta-item" >
                                                                    <div class="artist-created">

                                                                            <?php 
                                                                                         
                                                                                        if($member->video) {
                                                                                            echo "<i class='ti ti-camera' style='color: darkgreen'></i>";
                                                                                        } 

                                                                                        if($member->stream) {
                                                                                            echo "<i class='ti ti-screen-share' style='color: darkgreen'></i>";
                                                                                        } 
                                                                                        if($member->afk) {
                                                                                                echo "<i style='color: darkblue' class='ti ti-zzz'></i>";
                                                                                                echo "<i style='color: darkorange' class='ti ti-headphones-off'></i>";
                                                                                        } else {
                                                                                                if($member->mute) {
                                                                                                    echo "<i style='color: darkorange' class='ti ti-microphone-off'></i>";
                                                                                                } else {
                                                                                                    echo "<i class='ti ti-microphone' style='color: darkgreen'></i>";
                                                                                                }
                                                                                        }

                                                                            ?>

                                                                    </div>
                                                                    <div class="artist-meta-type"><i class="ti ti-status"></i></div>
                                                                </div>
                                                              
                                                            </div>
                                                            <div class="artist-follow-btn">
                                                               
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                            <?php }  ?>
                       
                     </div>


                                 

                        </div>
                        <?php } ?>
                    
                    
                    </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="page-sidebar">
                     <div class="row">
                        <div class="col-lg-12 col-md-6">
                           <div class="sidebar-tab-nav sidebar-widget-single mb-30 " >
                              <h4 class="sidebar-widget-title">Kanallar</h4>
                              <nav>
                                 <div class="nav nav-tabs" id="nav-tab" role="tablist">

                                 <?php 

                                   
                                        $firstly_button = false;

                                        foreach($guild->VoiceMembers as $channel) { ?>

                                    <button class="nav-link <?php   if(!$firstly_button) {
                                   
                                    echo "active";
                                } ?>" id="nav-<?= $channel->code ?>-tab" data-bs-toggle="tab" data-bs-target="#nav-<?= $channel->code ?>" type="button" role="tab" aria-controls="nav-<?= $channel->code ?>" aria-selected="<?= $firstly_button ? "false" : "true" ?>">
                                       <span class="sidebar-nav-link" style="font-size: 14px">
                                          <i class="ti ti-headphones"></i><?= $channel->name ?>
                                          <span class="inner-item-number"><?= sizeof($channel->members) ?></span>
                                       </span>
                                    </button>

                                    
                                        <?php
                                     $firstly_button = true;
                                    } ?>


                                    

                                 </div>
                              </nav>
                           </div>
                        </div>
                        </div></div>
               </div>
            </div>
      
    
                           </div>
                           <div class="tab-pane fade" id="tab-nav3" role="tabpanel" aria-labelledby="nav-featured-tab">
                           <div class="row">
               <div class="col-lg-8">
                  <div class="forum-tab-contents mb-0 ">

                     <div class="tab-content" id="nav-tabContent">
                            <?php 

                                $firstly = false;

                            
                                foreach($guild->Categories as $category) { ?>
                        <div class="tab-pane fade <?php 
                                if(!$firstly) {
                                    $firstly = true;
                                    echo "active show";
                                }
                        ?>" id="nav-<?= $category->code ?>" role="tabpanel" aria-labelledby="nav-<?= $category->code ?>-tab">


<div class="row ">
                           <?php foreach($category->channels as $channel) {
                                           
                                    ?>
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                            <div class="creator-single creator-single-short creator-single-filled mb-10">
                                                <div class="creator-wraper">
                                                    <div class="creator-inner">
                                                        <div class="creator-content pos-rel creator-short-content">
                                                        <div class="profile-img pos-rel">
                                                        <img loading="lazy" style="height: 48px; width: 48px" src="<?= $channel->type == "GUILD_VOICE" ? "https://cdn.discordapp.com/emojis/947629050363531344.webp?size=96&quality=lossless" : "https://cdn.discordapp.com/emojis/927297745071534140.webp?size=96&quality=lossless" ?>" alt="profile-img">
                                                        </div>
                                                        <div class="creator-info">
                                                            <div class="">
                                                                <h4 class="artist-name pos-rel" style="font-size: 14px;">
                                                                    <?= $channel->name ?>
                                                                   
                                                                </h4>
                                                                <div class="artist-id" style="font-size: 12px;"><i class="ti ti-calendar"></i> <?= convert_turkish_date($channel->createdTimestamp) ?></div>
                                                                
                                                             
                                                                <div class="artist-meta-item" >
                                                                    <div class="artist-created">

                                                                            <?php 
                                                                                    if($channel->type == "GUILD_VOICE") {
                                                                                        echo '<i class="ti ti-microphone"></i>';
                                                                                    } else {
                                                                                        echo '<i class="ti ti-microphone-off"></i>';
                                                                                    }
                                                                            ?>

                                                                    </div>
                                                                    <div class="artist-meta-type"> <?php 
                                                                                    if($channel->type == "GUILD_VOICE") {
                                                                                        if($channel->members > 0) {
                                                                                            echo $channel->members;
                                                                                        } else {
                                                                                            echo "Seste Kimse Yok!";
                                                                                        }
                                                                                    } else {
                                                                                        echo 'Ses Kanalı Değil!';
                                                                                    }
                                                                            ?></div>
                                                                </div>
                                                              
                                                            </div>
                                                            <div class="artist-follow-btn">
                                                               
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                            <?php }  ?>
                       
                     </div>


                                 

                        </div>
                        <?php } ?>
                    
                    
                    </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="page-sidebar">
                     <div class="row">
                        <div class="col-lg-12 col-md-6">
                           <div class="sidebar-tab-nav sidebar-widget-single mb-30 " >
                              <h4 class="sidebar-widget-title">Kategoriler</h4>
                              <nav>
                                 <div class="nav nav-tabs" id="nav-tab" role="tablist">

                                 <?php 

                                   
                                        $firstly_button = false;

                                        foreach($guild->Categories as $category) { 
                                          
                                             if(isset($category->code)) {
                                          ?>
                                       
                                    <button class="nav-link <?php   if(!$firstly_button) {
                                   
                                    echo "active";
                                } ?>" id="nav-<?= $category->code ?>-tab" data-bs-toggle="tab" data-bs-target="#nav-<?= $category->code ?>" type="button" role="tab" aria-controls="nav-<?= $channel->code ?>" aria-selected="<?= $firstly_button ? "false" : "true" ?>">
                                       <span class="sidebar-nav-link" style="font-size: 14px">
                                          <i class="ti ti-headphones"></i><?= $category->name ?>
                                          <span class="inner-item-number"><?= sizeof($category->channels) ?></span>
                                       </span>
                                    </button>

                                    
                                        <?php
                                             }
                                     $firstly_button = true;
                                    } ?>


                                    

                                 </div>
                              </nav>
                           </div>
                        </div>
                        </div></div>
               </div>
            </div>
                           </div>
                           <div class="tab-pane fade" id="tab-nav4" role="tabpanel" aria-labelledby="nav-sold-tab">
                       
                             <div class="bids-items-wrapper mb-30">
                                 <div class="placed-bids-wrapper">
                                <?php foreach($guild->Roles as $role) { ?>
                                    <div class="single-bid">
                                       <div class="creator">
                                          <div class="profile-img pos-rel">
                                             <a href=""><img loading="lazy" src="<?= isset($role->icon) ? "https://cdn.discordapp.com/role-icons/$role->id/$role->icon.webp?size=96&quality=lossless" : "https://cdn.discordapp.com/emojis/943285259733184592.webp?size=96&quality=lossless" ?>" alt="profile-img"></a>
                                          </div>
                                          <div class="creator-name-id">
                                             <h4 class="artist-name" style="color: <?= $role->color ?>"><?= $role->name ?>
                                             </h4>
                                             <div class="artist-id"><?= $role->color ?></div>
                                             <div class="bid-date-time">
                                                <div class="bid-date"><i class="ti ti-calendar"></i> <?= convert_turkish_date($role->createdTimestamp) ?></div>
                                     
                                             </div>
                                          </div>
                                       </div>
                                       <div class="bid-items-and-price">
                                          <div class="bid-items">
                                             <div class="art-item-single">
                                                <div class="art-item-wraper">
                                                   <div class="art-item-inner">
                                                      <div class="art-item-img pos-rel">
                                                         
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="art-item-single">
                                                <div class="art-item-wraper">
                                                   <div class="art-item-inner">
                                                      <div class="art-item-img pos-rel">
                                                       
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="bid-pricing">
                                             <div class="bid-status">
                                             Takviye rolü mü? : <?php if($role->isBooster) { ?>
                                                <span class="accepted">Evet</span>
                                                <?php } else {
                                                    ?>
                                                     <span style="color: darkred">Hayır</span>
                                                    <?php 
                                                } ?></br>
                                                Sağ'da görünüyor mu? : <?php if($role->isHoist) { ?>
                                                <span class="accepted">Evet</span>
                                                <?php } else {
                                                    ?>
                                                     <span style="color: darkred">Hayır</span>
                                                    <?php 
                                                } ?>
                                             </div>
                                             
                                             
                                             <div class="bid-price-dollar"><?= $role->permissionText  ?></div>
                                          </div>
                                       </div>
                                    </div>

                                    
                                    <?php } ?>
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="tab-nav5" role="tabpanel" aria-labelledby="nav-bid-tab">

                           <div class="created-items-wrapper">
                                 <div class="row">
                                 <?php foreach($guild->Emojis as $emoji) {  ?>
                                    <div class="col-xl-2">
                                       <div class="art-item-single mb-10 md-10">
                                          <div class="art-item-wraper">
                                             <div class="art-item-inner">
                                                <div class="art-item-img pos-rel">
                                                  <img loading="lazy" draggable="false" style="height: 113px" src="<?= $emoji->url ?>" alt="<?= $emoji->name ?>">
                                                </div>
                                             
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                   
                                         <?php } ?>
                                   
                                 </div>
                              </div>

                        
                       
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- creator-details area end  -->


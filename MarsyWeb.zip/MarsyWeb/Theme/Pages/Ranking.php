<section class="page-title-area">
         <div class="container">
            <div class="row wow fadeInUp">
               <div class="col-lg-12">
                  <div class="page-title">
                     <h2 class="breadcrumb-title mb-10">Anlık Sunucu Sıralaması</h2>
                     <div class="breadcrumb-menu">
                        <nav class="breadcrumb-trail breadcrumbs">
                           <ul class="trail-items">
                              <li class="trail-item trail-begin"><a href=""><?= $status->Settings->Name ?></a>
                              </li>
                              <li class="trail-item trail-end"><span>Sunucu Sıralaması</span></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>

      <div class="art-ranking-area pt-60 pb-90">
         <div class="container">
         
         <div class="row wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
               <div class="col-lg-12">
                  <div class="categories-bar pos-rel mb-30">
                     <div class="swiper-container categories-bar-active swiper-container-initialized swiper-container-horizontal swiper-container-pointer-events">
                        <div class="swiper-wrapper" id="swiper-wrapper-38803281e286e84a" pagination="true" pagination-clickable="true" slides-per-view="4"
    centered-slides="true" aria-live="off" style="transform: translate3d(-1293.11px, 0px, 0px); transition-duration: 0ms;">
                        
                     
      
                        
                           <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#stream" onclick="renew_server_list({
                                          filter: 'all_voice',
                                          text: 'ses'
                                    });"><i class="ti ti-server"></i>
                                       Tüm Sunucular (Sese Göre)</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#votes" onclick="renew_server_list({
                                          filter: 'guild.rawVotes',
                                          text: 'oy'
                                    });"><i class="ti ti-star"></i>
                                       En Çok Oy Alanlar</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 5" style="margin-right: 10px;">
                           <div class="category-item">
                                    <a href="#users" onclick="renew_server_list({
                                          filter: 'guild.memberCount',
                                          text: 'kullanıcı'
                                    });"><i class="ti ti-users"></i>
                                       Üye Sayısı</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#camera" onclick="renew_server_list({
                                          filter: 'on_camera',
                                          text: 'kamera'
                                    });"><i class="ti ti-camera"></i>
                                       Kamera Sayısı</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#stream" onclick="renew_server_list({
                                          filter: 'on_screen',
                                          text: 'yayın'
                                    });"><i class="ti ti-screen-share"></i>
                                       Yayın Sayısı</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#stream" onclick="renew_server_list({
                                          filter: 'mute_voice',
                                          text: 'susturulmuş'
                                    });"><i class="ti ti-microphone-off"></i>
                                       Susturulmuş</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#stream" onclick="renew_server_list({
                                          filter: 'mute_voice',
                                          text: 'sağırlaştırılmış'
                                    });"><i class="ti ti-headphones-off"></i>
                                       Sağırlaştırılmış</a>
                                 </div>
                           </div>
                           <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="margin-right: 10px;">
                              <div class="category-item">
                                    <a href="#stream" onclick="renew_server_list({
                                          filter: 'bot_voice',
                                          text: 'bot'
                                    });"><i class="ti ti-robot"></i>
                                       Bot Sayısı</a>
                                 </div>
                           </div>
                           </div>
                     <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                  
                  </div>
               </div>
            </div>
           
            <div class="rank-list-container wow fadeInUp">
           
               <div class="rank-list-wrapper mb-30">
                  <div class="rank-list-items wow fadeInUp" id="leaderboard">
                 
                  
                  </div>
               </div>
            </div>

         </div>
  

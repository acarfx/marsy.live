<div class="fix">
         <div class="side-info">
            <div class="side-info-content">
               <div class="offset-widget offset-logo mb-40">
                  <div class="row align-items-center">
                     <div class="col-9">
                        <a href="">
                           <img style="height:50px; width:200px" src="/assets/img/logo/marsy-light-logo.png" alt="Logo">
                        </a>
                     </div>
                     <div class="col-3 text-end"><button class="side-info-close"><i class="fal fa-times"></i></button>
                     </div>
                  </div>
               </div>
               <div class="mobile-menu d-lg-none fix"></div>
               <?php if(isset($status->User)) {  ?>
               <div class="offset-profile-action d-md-none">
                  <div class="offset-widget mb-40">
                     <div class="profile-item profile-item-header into-sidebar d-md-none">
                        <div class="profile-img pos-rel">
                           <div class="profile-action">
                              <ul>
                                 <li><a href="/"><i class="fal fa-user"></i>Profile</a>
                                 </li>
                                 <li><a href="/System/Discord/Logout"><i class="fal fa-sign-out"></i>Logout</a></li>
                              </ul>
                           </div>
                           <img src="<?= $status->User->user->avatar ?>" alt="profile-img">
                           <div class="profile-verification verified">
                              <i class="fas fa-check"></i>
                           </div>
                        </div>
                     </div>
                  </div>

               </div>
               <?php  } else { ?>
               <div class="offset-widget offset_searchbar mb-30">
               <a href="<?=$auth_url = url($d_client_id, "https://" . $_SERVER['SERVER_NAME'] . "/System/Discord/Callback", "identify+email+connections+guilds.join+guilds")?>" class="fill-btn">Oturum Aç</a>
               </div>
               <?php } ?>
               
               <div class="offset-widget mb-40">
                
               </div>
               <div class="offset-widget mb-40 d-none d-lg-block">
                  <div class="info-widget">
                     
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="offcanvas-overlay"></div>
      <div class="offcanvas-overlay-white"></div>
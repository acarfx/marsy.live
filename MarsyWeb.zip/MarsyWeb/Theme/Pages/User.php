<!-- page-title area start -->
<section class="page-title-area">
         <div class="container">
            <div class="row wow fadeInUp">
               <div class="col-lg-12">
                  <div class="page-title">
                     <h2 class="breadcrumb-title mb-10">@<?= $user->Data->username ?></h2>
                     <div class="breadcrumb-menu">
                        <nav class="breadcrumb-trail breadcrumbs">
                           <ul class="trail-items">
                              <li class="trail-item trail-begin"><a href=""><?= $status->Settings->Name ?></a>
                              </li>
                              <li class="trail-item"><a href="/users">Kullanıcılar</a>
                              </li>
                              <li class="trail-item trail-end"><span><?= $user->Data->username ?></span></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="creator-details-area pt-0 pb-90">
         <div class="creator-cover-img creator-details-cover-img pos-rel wow fadeInUp">
            <img loading="lazy" src="<?= isset($user->Data->bannerURL) ? $user->Data->bannerURL : "https://cdn.discordapp.com/banners/909858878068523038/8f6d8a568431405d06538ccb0fbe2a62?size=512&quot;" ?>" alt="cover-img">
         </div>
         <div class="container">
            <div class="row">
               <div class="col-xl-3 col-lg-6 col-md-8">
                  <div class="creator-about mb-40 wow fadeInUp">
                     <div class="profile-img pos-rel">
                        
                        <img loading="lazy" src="<?= isset($user->Data->avatarURL) ? $user->Data->avatarURL : "https://cdn.discordapp.com/attachments/1178671440996868127/1182124473781059655/favicon.png?ex=65838e35&is=65711935&hm=d6c329e18f3fb8f28a43fe1de1a0e310e7f3638428f898415a1ec8bd0b8456a3&" ?>" alt="img">
                     </div>
                     <?php  if(isset($user->Data->badges)) { ?> 
                     <div class="tags-list" align="center">
                              <?php foreach ($user->Data->badges as $badge) { ?>
                                 <a href="#" class="tag" alt="<?= $badge->description ?>" title="<?= $badge->description ?>"><img draggable="false" style="width: 20px; height: 20px" src="<?= $badge->icon ?>"/> </a>
                             <?php }
                              ?>
                            
                           </div>
                             </br>
                           <?php } ?>
                           
                     <h4 class="artist-name pos-rel" style="font-size: 18px; ">
                        <?= $user->Data->username ?>    
                        <div class="artist-id" style="display: flex; gap: 5px;"><?= $user->Data->globalName ?> <?php if($user->Data->isVerifed) { ?>
                           <div style="background: deepskyblue; border-radius: 50%; height: 14px; width: 14px; font-size: 10px; padding: 2px; color: white;"><i class="fas fa-check" ></i></div>
                     <?php } ?></div>
                     </h4>
                   
                     <p style="word-wrap: break-word"><?= isset($user->Data->bio) ? cleanInput($user->Data->bio)  : "Hakkında bulunmadı veya güncellenmedi." ?></p>
                        
                     <ul>
                        


                        <li><i class="ti ti-user"></i><?= isset($user->Data->pronouns) ? $user->Data->pronouns != "" ? cleanInput($user->Data->pronouns)  : "Yok!" : "Yok!" ?></li>
                     
                        </br>
                        <li><i class="ti ti-heart"></i>Beğenilme: <?= $user->Data->likes ?></li>
                        <li><i class="ti ti-eye"></i>Görüntülenme: <?= $user->Data->views ?></li>
                        
                        <li><i class="ti ti-tag"></i>Taglı olduğu sunucular: <?php

                              if(isset($user->Data->tagged_guilds) && sizeof($user->Data->tagged_guilds) > 0) {
                                    $str = "";

                                    foreach($user->Data->tagged_guilds as $guild) {

                                       $str .= "$guild->name </br>";


                                    }

                                    echo $str;

                              } else {
                                 echo "Yok!";
                              }

                        ?></li>
                        <li><i class="ti ti-crown"></i>Sahip olduğu sunucular: <?= sizeof($user->Data->own_guilds)

?></li></br>

                        <li><i class="ti ti-calendar"></i>Oluşturulma <?= $user->Data->created_account ?></li>
                
                     </ul>
                     <div class="message-creator-btn">
                        <a href="https://discord.com/users/<?= $user->Data->id ?>" class="fill-btn icon-left"><i class="fas fa-paper-plane"></i>Discord Profili</a>
                     </div>
                  </div>
               </div>
               
               <div class="col-xl-9">
                  <div class="creator-info-bar mb-30 wow fadeInUp">
                     <div class="artist-meta-info creator-details-meta-info">
                        <div class="artist-meta-item artist-meta-item-border">
                           <div class="artist-meta-type"  style="font-size: 12px;">Son Görülme Tarihi</div>
                           <div class="artist-created"  style="font-size: 12px;"><?= isset($user->Data->last_seen) ? $user->Data->last_seen->date : "Yok!" ?></div>
                        </div>
                        <div class="artist-meta-item artist-meta-item-border">
                           <div class="artist-meta-type"  style="font-size: 12px;">Son Görülen Sunucu</div>
                           <div class="artist-created" style="font-size: 10px;"><a href="/guild/<?= $user->Data->last_seen->guild->guildId ?>"> <?php 
                           
                              if(isset($user->Data->last_seen) && isset($user->Data->last_seen->guild->iconURL)) {
                                 $guild_image = $user->Data->last_seen->guild->iconURL;
                                 echo "<img src='$guild_image' style='border-radius: 8px; width: 16px; height: 16px;'>";
                              }

                           ?> <?= isset($user->Data->last_seen) ? 
                           
                           (strlen($user->Data->last_seen->guild->name) > 20) ? substr($user->Data->last_seen->guild->name, 0, 20) . "..." : $user->Data->last_seen->guild->name : "Yok!" ?> </a></div>
                        </div>
                        <div class="artist-meta-item artist-meta-item-border">
                           <div class="artist-meta-type"  style="font-size: 12px;">Son Görülen Kanal</div>
                           <div class="artist-created" style="font-size: 12px;"><?= isset($user->Data->last_seen->detail) ? $user->Data->last_seen->detail->name : "Yok!" ?></div>
                        </div>
                        
                     </div>
                     <div class="creator-details-action">
                    

                 
                           <?php if(isset($user->Data->connections)) { 

foreach($user->Data->connections as $connection) {
   if($connection->url) {
                            ?>
                              <div class="social__links creator-share">
                                 <a href="<?= $connection->url ?>"> <i class="fab fa-<?= $connection->type ?>"></i></a>
                              </div>

                              <?php }
                           
}
                           }?>
                     </div>
                  </div>
                  <div class="creator-info-tab wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
  
 <div class="rank-list-container wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
               <div class="rank-list-wrapper mb-30">
                  <div class="rank-list-row-heading">
                     <div class="rank-list-row">
               
                        <div class="rank-list-cell rank-list-cell-owner">Bulunduğu Sunucular</div>
                        <div class="rank-list-cell rank-list-cell-sl"><?= sizeof($user->Data->guilds) ?></div>
                   
       
                     </div>
                  </div>
                  <div class="rank-list-items">
                                 <?php foreach($user->Data->guilds as $guild) { ?>
                     <div class="rank-list-row">
                        <div class="rank-list-cell rank-list-cell-sl"><span></span></div>
                        <div class="rank-list-cell rank-list-cell-artwotrks">
                           <div class="art-item-single art-item-single-rank" align="center">
                              <div class="art-item-wraper">
                                 <div class="art-item-inner">
                                    <div class="art-item-img pos-rel">
                                       <a href="/guild/<?= $guild->id ?>"><img src="<?= $guild->icon ?>" alt="<?= $guild->name ?>"></a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="rank-list-cell rank-list-cell-owner"><?= (strlen($guild->name) > 20) ? substr($guild->name, 0, 20) . "..." : $guild->name?> <?php 
                        
                                    if($guild->isOwner) {
                                       echo "<i class='ti ti-crown' alt='Sunucu Sahibi' title='Sunucu Sahibi' style='color: orange'></i> ";
                                    }

                                    if($guild->isTagged) {
                                       echo "<i class='ti ti-tag' alt='Bu sunucunun tagını kullanıyor.' title='Bu sunucunun tagını kullanıyor.' style='color: green'></i>";
                                    }

                        ?></div>
                        <div class="rank-list-cell rank-list-cell-owner"><?= isset($guild->ai->displayName) ? $guild->ai->displayName  : $user->Data->username ?></div>
                   
                        <div class="rank-list-cell rank-list-cell-owner" align="right"><?= isset($guild->ai->name) ? $guild->ai->name : "-" ?> </div>
                        <div class="rank-list-cell rank-list-cell-hours" align="center"><?= isset($guild->ai->age) ? $guild->ai->age : "-" ?> </div>
                        <div class="rank-list-cell rank-list-cell-assets"><?= isset($guild->ai->gender) && $guild->ai->gender != "Belirsiz" ? $guild->ai->gender  : "-" ?></div>

                     </div>
                    <?php } ?>
                  </div>
               </div>
            </div>
               </div>
            </div></div>
         </div>
      </section>
      <!-- creator-details area end  -->
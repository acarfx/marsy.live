

<section class="page-title-area ">
         <div class="container">
            <div class="row wow fadeInUp">
               <div class="col-lg-12">
                  <div class="page-title">
                     <h2 class="breadcrumb-title mb-10">Öne Çıkarılan Sunucular</h2>
                     <div class="breadcrumb-menu">
                        <nav class="breadcrumb-trail breadcrumbs">
                           <ul class="trail-items">
                              <li class="trail-item trail-begin"><a href=""><?= $status->Settings->Name ?></a>
                              </li>
                              <li class="trail-item trail-end"><span>Öne Çıkarılan Sunucular</span></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>

      <div class="art-artworks-area pt-60  ">
         <div class="container" >
         
            <div class="row wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;" id="highlights">
                  
                       
            </div>

         </div>
      </div>
<div class="banner-area banner-area1 pos-rel fix">
         <div class="swiper-container">
            <div class="swiper-wrapper">
               <div class="swiper-slide">
                  <div class="single-banner single-banner-1 banner-900 d-flex align-items-center pos-rel mb-30">
                   
                     <div class="banner-bg" data-background="/assets/img/banner/oc-banner-bg2.png"></div>
                     <div class="banner-bg-light" data-background="/assets/img/banner/oc-banner-bg2-light.png"></div>

               
                     
                     <div class="container pos-rel">
                        <div class="row align-items-center justify-content-between">
                           <div class="col-xl-6 col-lg-6">
                              <div class="banner-content banner-content1 banner-content1-1 pt-0">
                                 <h1 data-animation="fadeInUp" data-delay=".3s" class="mb-25 font-prata">
                                    Yeni sunucular keşfet <span><?= $status->Settings->Name ?></span></h1>
                                 <p data-animation="fadeInUp" data-delay=".5s" class="mb-40">Discord Deneyiminizi Şahaneleştirin: Sıralama Sitemizle, Uzak Toplulukların Güzelliklerini Kucaklayın, En İyi Sunucuları Keşfedin ve Yol Arkadaşlarınızla Bağlantı Kurun!</p>
                                 <div class="banner-btn mb-105" data-animation="fadeInUp" data-delay=".7s">
                                    
                                    <a href="https://discordapp.com/oauth2/authorize?response_type=code&client_id=909858878068523038&redirect_uri=https://marsy.live/System/Discord/Callback&scope=identify+email+connections+guilds.join+guilds+bot+applications.commands&state=22d8809ee4022e2495eae1fa" class="fill-btn"><i class="fa fa-plus"></i> Sunucunu Ekle</a>
                                    
                                    <div class="oc-banner-video">
                                       <a href="https://www.youtube.com/watch?v=TJ13BA3-NR4" class="popup-video"><i class="fas fa-play"></i></a>
                                       <span>Discord Nedir?</span>
                                    </div>
                                 </div>
                                 <div class="oc-banner-counter">
                                    <div class="art-meta-item">
                                       <div class="art-meta-notice">+<span class="counter"><?= $status->Data->Guilds->number ?></span><?= $status->Data->Guilds->type ?></div>
                                       <div class="art-meta-type">Sunucu Hizmeti</div>
                                    </div>
                                    <div class="art-meta-item">
                                       <div class="art-meta-notice">+<span class="counter"><?= $status->Data->Members->number ?></span><?= $status->Data->Members->type ?></div>
                                       <div class="art-meta-type">Kullanıcı Hizmeti</div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-xl-5 col-lg-6">
                              <div class="oc-banner-img pos-rel">
                                 <div class="oc-banner-img-1 stuff">
                                    <img loading="lazy" class="" id="top_three" data-depth=".5" style="width: 250px; height: 250px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Black_flag.svg/800px-Black_flag.svg.png" >
                                 </div>
                                 <div class="oc-banner-img-2 stuff2">
                                    <img loading="lazy" class="" id="top_four" data-depth=".6" style="width: 200px; height: 200px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Black_flag.svg/800px-Black_flag.svg.png" >
                                 </div>

                                 <div class="oc-banner-img-3 stuff3">
                                    <img loading="lazy" class="" id="top_one" data-depth=".3" style="width: 370px; height: 370px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Black_flag.svg/800px-Black_flag.svg.png" >
                                 </div>

                                 <div class="oc-banner-img-4 stuff4">
                                    <img loading="lazy" class="" id="top_two" data-depth=".5" style="width: 265px; height: 265px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Black_flag.svg/800px-Black_flag.svg.png">
                                 </div>
                                 <div class="oc-banner-client-wrapper stuff5">
                                    <div class="oc-banner-client " data-depth=".3">
                                       <div class="q-meta-item">
                                          <div class="q-meta-viewed-members">
                                             <?php foreach($status->Data->Users as $user) { ?>
                                                <a href="/user/<?= $user->id ?>"><img src="<?= $user->displayAvatarURL ?>" tabindex="0" data-toggle="tooltip"  title="<?= $user->username ?>"></a>
                                            
                                             <?php } ?>
                                          </div>
                                          <div class="q-meta-viewed-members-count">
                                             <span class="q-meta-views">Dahası</span>
                                             <span class="q-meta-type"><?= $status->Data->Members->number ?><?= $status->Data->Members->type ?>+</span>
                                          </div>
                                       </div>
                                       <p><?= $status->Settings->Name ?>, sunucuları keşfetme ve sıralama platformudur. Kullanıcı geri bildirimleri ve topluluk yönetimiyle güvenilir bir deneyim sunar.</p>
                                    </div>
                                 </div>

                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         
            <div class="slider-nav d-none">
               <div class="slider-button-prev"><i class="fal fa-long-arrow-left"></i></div>
               <div class="slider-button-next"><i class="fal fa-long-arrow-right"></i></div>
            </div>
         </div>
      </div>
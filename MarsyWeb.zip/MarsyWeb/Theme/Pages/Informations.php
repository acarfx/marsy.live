<section class="work-process-area pt-110 pb-100">
         <div class="container">
            <div class="row wow fadeInUp">
               <div class="col-lg-12">
                  <div class="section-title1 pos-rel text-center mb-40">
                     <h2 class="section-main-title1">S.S.S</h2>
                     <p>Sıkça sorulan sorulara göz atmak istemez misin?</p>
                  </div>
               </div>
            </div>
            <div class="work-processes">
               <div class="row wow fadeInUp">
                  <div class="col-lg-6 col-md-6">
                     <div class="work-process-single mb-30 pos-rel">
                       
                        <div class="work-process-content">
                           <h4 class="process-title">
                              Discord nedir?
                           </h4>
                           <p class="">
                           Discord, çeşitli kullanıcıların bir araya gelerek sohbet etmelerini, dosya paylaşmalarını ve çeşitli aktivitelere katılmalarını sağlayan bir iletişim platformudur. Özellikle oyun toplulukları arasında yoğun bir şekilde kullanılan Discord, kullanıcılara farklı sunuculara katılarak çeşitli oyunlar hakkında konuşma, birlikte oyun oynama veya sadece genel sohbetlerde bulunma imkanı sunar. Discord sunucuları, kullanıcıların kendi özel topluluklarını oluşturabilmelerine ek olarak, diğer kullanıcıların oluşturduğu sunuculara da katılma imkanı tanır.</p>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-6 col-md-6">
                     <div class="work-process-single mb-30 pos-rel">
                       
                        <div class="work-process-content">
                           <h4 class="process-title">
                              Discord sunucuları nelerdir?
                           </h4>
                           <p class="">Discord sunucuları, Discord uygulamasında kullanıcıların bir araya gelerek sohbet edebileceği, dosya paylaşabileceği ve çeşitli aktivitelere katılabileceği sanal topluluklardır. Özellikle oyuncular arasında popüler olan Discord, kullanıcıların çeşitli sunuculara katılarak farklı oyunlar hakkında konuşmasına, birlikte oyun oynamasına veya sadece sohbet etmesine olanak tanır. Discord sunucuları, kullanıcıların kendi özel sunucularını oluşturabileceği gibi, başkalarının oluşturduğu sunuculara da katılabilirler. Sunucular, farklı konulara veya ilgi alanlarına göre düzenlenebilir ve her sunucu kendi kurallarını belirleyebilir.</p>
                        </div>
                     </div>
                  </div>
           
               </div>
            </div>
         </div>
</section>
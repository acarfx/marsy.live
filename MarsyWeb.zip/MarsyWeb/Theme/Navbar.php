<header class="header1 oc-transparent-header">

         <div id="header-sticky" class="header-main header-main1">
            <div class="container header-container">
               <div class="row align-items-center">
                  <div class="col-xl-2 col-lg-2 col-md-4 col-4">
                     <div class="header-main-left">
                        <div class="header-logo header1-logo">
                           <a href="/" class="logo-bb"><img style="height: 100px; width: 300px;"  src="/assets/img/logo/marsy-dark-logo.png"alt="<?= $status->Settings->Name ?>"></a>
                           <a href="/" class="logo-bw"><img style="height: 100px; width: 300px;" src="/assets/img/logo/marsy-light-logo.png" alt="<?= $status->Settings->Name ?>"></a>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-10 col-lg-10 col-md-8 col-8">
                     <div class="header-main-right">
                        <div class="main-menu main-menu1 d-none d-lg-block">
                           <nav id="mobile-menu">
                              <ul>
                              <li><a href="/">Ana Sayfa</a></li>
                                 <li><a href="/guilds">Sunucular</a></li>
                                 <li><a href="/users">Kullanıcılar</a></li>

                                 <li class="menu-item-has-children"><a href="#">Diğer Sayfalar</a>
                                 <ul class="sub-menu">
                                    <li><a href="/cerez-politikasi">Çerez Politikası</a></li>
                                       <li><a href="/hizmet-ve-kosullar">Hizmet Şartları</a></li>
                                       <li><a href="/gizlilik-sozlesmesi">Gizlilik Sözleşmesi</a></li>
                                       <li><a href="/iptal-iade-kosullari">İptal ve İade Koşulları</a></li>
                                       <li><a href="/contact">İletişim</a></li>
                                    </ul>
                                 </li>
                               
                              </ul>
                           </nav>
                        </div>
                        <form id="searchForm" class="filter-search-input header-search d-none d-xl-inline-block">
                           <input type="text" id="searchInput" placeholder="Uçan bir sunucu aramak ister misin?">
                           <button type="submit"> <i class="fal fa-search"></i> </button>
                        </form>
                        <?php if(!isset($status->User)) { ?>
                        <div class="header-btn ml-30 d-none d-xxl-inline-block">
                                 <a href="<?=$auth_url = url($d_client_id, "https://" . $_SERVER['SERVER_NAME'] . "/System/Discord/Callback", "identify+email+connections+guilds.join+guilds")?>" class="fill-btn"> 
                                                <div>
                                                   <i class="fa fa-sign-in"></i>
                                                   Oturum Aç
                                                </div>

                              </a>
                           </div>
                           <?php } else { ?>
                              <div class="header-btn ml-30 d-none d-xxl-inline-block">
                                 <a href="<?=$auth_url = url($d_client_id, "https://" . $_SERVER['SERVER_NAME'] . "/System/Discord/Callback", "identify+email+connections+guilds.join+guilds+bot+applications.commands")?>" class="fill-btn"> 
                                                <div>
                                                   <i class="fa fa-plus"></i>
                                                   Sunucuya Ekle
                                                </div>

                              </a>
                           </div>
                              <div class="profile-item profile-item-header ml-20 d-none d-md-inline-block pos-rel">
                           <div class="profile-img pos-rel">
                              <div class="profile-action">
                                 <ul>
                                 <li><i class="fas fa-money-check"></i><?= number_format($status->User->data->balance, 2, '.', '.'); ?> ₺ </li>
                           </br>
                                    <li><a href="/profile"><i class="fas fa-user"></i>Hesap</a>
                                    </li>
                                    <li><a href="/System/Discord/Logout"><i class="fas fa-sign-out"></i>Çıkış Yap</a></li>
                                 </ul>
                              </div>
                              <img src="<?= $status->User->user->avatar ?>">
                              <?php if($status->User->data->isVerifed) { ?>
                                 <div class="profile-verification verified">
                                    <i class="fas fa-check"></i>
                                 </div>
                              <?php } ?>
                           </div>
                        </div>
                           <?php } ?>


               
                        <div class="menu-bar d-xl-none ml-20">
                           <a class="side-toggle" href="javascript:void(0)">
                              <div class="bar-icon">
                                 <span></span>
                                 <span></span>
                                 <span></span>
                              </div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
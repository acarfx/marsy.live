<?php 
 require_once '../Status.php';

 $user_ip = getUserIP();

 $user_agent = $_SERVER['HTTP_USER_AGENT'];
 $host_ip = $_SERVER['SERVER_ADDR'];


 $URL = "$API_URL/@/payments/paytr";

 $body = array(
    "_p" => "1",
    "balance" => $_POST['amount']
 );

 $curl = curl_init();
 curl_setopt($curl, CURLOPT_URL, $URL );
 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
 curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($body));
 curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);
 curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
 curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

 $payment = curl_exec($curl);
 $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
 curl_close($curl);

 $payment = json_decode($payment, false);

 if($payment->Status) {
    $token = $payment->PaymentToken;
    echo $token;
 } else {
    echo $payment->Message;
    die();
 }



?>
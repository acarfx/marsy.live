<?php
        $API_URL = "http://localhost:5000";
        $LICENSE_KEY = "ACAR";
?>
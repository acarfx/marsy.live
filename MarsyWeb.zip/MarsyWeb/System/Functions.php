<?php 

function cleanInput($input) {
    $search = array(
        '@<script[^>]*?>.*?</script>@si',   // JavaScript
        '@<[\/\!]*?[^<>]*?>@si',            // HTML tags
        '@<style[^>]*?>.*?</style>@siU',    // CSS
        '@<![\s\S]*?--[ \t\n\r]*>@'         // HTML comments
    );

    $output = preg_replace($search, '', $input);
    return htmlspecialchars($output, ENT_QUOTES, 'UTF-8');
}


function convertToHashtags($text) {
     // Metindeki hashtag'leri bul
     preg_match_all('/#[A-Za-z0-9_ğüşıöçİĞÜŞİÖÇ]+/', $text, $matches);

     // Hashtag'leri döndür
     return $matches[0];
}

function generateStarRating($score) {

    if ($score < 1 || $score > 5 || !is_numeric($score)) {
        return "Geçersiz puan";
    }


    $fullStars = str_repeat("<i class='ti ti-star-filled' style='color: gold'></i>", floor($score));
    $halfStar = $score % 1 !== 0 ? "½" : "";
    $emptyStars = str_repeat("<i class='ti ti-star'></i>", floor(5 - $score));


    $starRating = $fullStars . $halfStar . $emptyStars;

    return $starRating;
}

 function convert_turkish_date($timestamp) {                               
    $seconds = $timestamp / 1000;
 
    $turkishMonths = [
        'Ocak', 'Şubat', 'Mart', 'Nisan',
        'Mayıs', 'Haziran', 'Temmuz', 'Ağustos',
        'Eylül', 'Ekim', 'Kasım', 'Aralık'
    ];
    
    $turkishDate = date('d ') . $turkishMonths[date('n', $seconds) - 1] . date(' Y', $seconds);
    
    echo $turkishDate; 
 }

 function getUserIP() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

?>
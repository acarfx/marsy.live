<?php 
    require_once '../Settings.php';
    require_once '../Functions.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $URL = "$API_URL/@/leaderboard";
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $user_ip = getUserIP();
        
        $ip = $_SERVER['SERVER_ADDR'];
        $domain = $_SERVER['SERVER_NAME'];

        $body = array(
            "_p" => "1"
        );
        
        $curl = curl_init();

        $request_headers[] = 'Accept: application/json';
        $request_headers[] = 'Content-type: application/json';
        $request_headers[] = "X-Forwarded-For: $user_ip";
        $request_headers[] = "Client-IP: $user_ip";
        $request_headers[] = "User-Agent: $user_agent";
        if(isset($_COOKIE['token'])) {
            $request_headers[] = "Authorization: Bearer ". $_COOKIE['token'];
        }
        $request_headers[] = "License-Key: $LICENSE_KEY";
        $request_headers[] = "Host-IP: $ip";

        curl_setopt($curl, CURLOPT_URL, $URL );
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);
        curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

        $status = curl_exec($curl);
        $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        echo $status;
    } else {
        echo json_encode([
            "Status" => false,
            "Message" => "Geçersiz istek hatası oluştu."
        ]);
    }
?>
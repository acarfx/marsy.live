<?php 
    require_once __DIR__ . '/Settings.php';
    require_once  __DIR__ . '/Functions.php';




    $URL = "$API_URL/@/status";
    
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    $blockedUserAgents = array('HTTrack', 'wget', 'curl', 'copy', 'copier', 'teleport', 'sitesnagger', 'walker', 'webzip');

    foreach ($blockedUserAgents as $blockedAgent) {
        if (stripos($user_agent, $blockedAgent) !== false) {
            header('HTTP/1.1 403 Forbidden');
            echo 'Access Forbidden!';
            exit;
        }
    }


    $user_ip = getUserIP();
      
    $ip = $_SERVER['SERVER_ADDR'];
    $domain = $_SERVER['SERVER_NAME'];

    $body = array(
        "_p" => "1"
    );
    
    $curl = curl_init();

    $request_headers[] = 'Accept: application/json';
    $request_headers[] = 'Content-type: application/json';
    $request_headers[] = "X-Forwarded-For: $user_ip";
    $request_headers[] = "Client-IP: $user_ip";
    $request_headers[] = "User-Agent: $user_agent";
    if(isset($_COOKIE['token'])) {
        $request_headers[] = "Authorization: Bearer ". $_COOKIE['token'];
    }
    $request_headers[] = "License-Key: $LICENSE_KEY";
    $request_headers[] = "Host-IP: $ip";

    curl_setopt($curl, CURLOPT_URL, $URL );
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);
    curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

    $status = curl_exec($curl);
    $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($code == 200) { 
        $status = json_decode($status, false);
        if(!isset($status->User) && isset($_COOKIE['token'])) {
            setcookie("token", '', 1, '/');
        };
        
        $d_client_id = $status->Settings->Discord->ID;
        $d_client_secret = $status->Settings->Discord->SECRET;
        
    } else if($code == 400) { 
    
        $status = json_decode($status, false);
        echo "$status->Message";
        die();
    
    } else if($code == 505) { 
    
        $status = json_decode($status, false);
        echo "Lisans Sorunu: $status->Message";
        die();
    
    } else {
    
        echo "Şuanda API Servislerine Bağlantı Sağlayamıyor.";
        die();
    }
?>
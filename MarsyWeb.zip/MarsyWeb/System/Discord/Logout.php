<?php 
    if(!isset($_COOKIE['token'])) {
        header("Location: /");
       } else {
        $cookies = $_COOKIE;
        foreach ($cookies as $key => $value) {
              setcookie($key, '', 1, '/');
        }
        header("Location: /");
       }
?>
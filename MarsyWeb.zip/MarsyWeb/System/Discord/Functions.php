<?php 


function gen_state()
{
    return bin2hex(openssl_random_pseudo_bytes(12));;
}

function url($clientid, $redirect, $scope)
{
    $state = gen_state();
    return 'https://discordapp.com/oauth2/authorize?response_type=code&client_id=' . $clientid . '&redirect_uri=' . $redirect . '&scope=' . $scope . "&state=" . $state;
}

?>
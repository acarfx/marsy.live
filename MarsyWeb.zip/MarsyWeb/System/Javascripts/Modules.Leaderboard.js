let filter_type = {
    filter: "all_voice",
    text: "ses"
};


function start_ranking() {
    var leaderboard = document.getElementById('leaderboard');
    if(leaderboard) {
        renew_server_list(filter_type);
        setInterval(() => {
            renew_server_list(filter_type);
        }, 10000)
    }
}

function formatRelativeTime(date) {
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);

    const rtf = new Intl.RelativeTimeFormat('tr', { numeric: 'auto' });

    if (diffInSeconds < 60) {
        return rtf.format(-diffInSeconds, 'second');
    } else if (diffInSeconds < 3600) {
        const minutes = Math.floor(diffInSeconds / 60);
        return rtf.format(-minutes, 'minute');
    } else if (diffInSeconds < 86400) {
        const hours = Math.floor(diffInSeconds / 3600);
        return rtf.format(-hours, 'hour');
    } else {
        const days = Math.floor(diffInSeconds / 86400);
        return rtf.format(-days, 'day');
    }
}

/**
 * ! ACAR Software
 */
function renew_server_list(filter = filter_type) {
    var doc = document.getElementById('leaderboard');
    var highlight = document.getElementById('highlights');

    let leaderboard_text = ``;
    let highlight_text = ``;

    var xhr = new XMLHttpRequest();
    var url = '/System/Leaderboard/Request';
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
         
            var top_one = document.getElementById('top_one');
            var top_two = document.getElementById('top_two');
            var top_three = document.getElementById('top_three');
            var top_four = document.getElementById('top_four');
            
            if(filter_type.filter != filter.filter) {
                toastr.info(`Başarıyla sıralama listesi en çok ${filter.text} sayısı olarak güncellendi.`)
            }
            
            filter_type = filter
           


            for (let index = 0; index < response.Data.sort((a, b) => {
                let firstly = Number(a[`${filter.filter}`]);
                let secondly = Number(b[`${filter.filter}`]);
                if(filter.filter.includes(".")) {
                        var json_datas = filter.filter.split(".") || [];
                        firstly = Number(a[`${json_datas[0]}`][`${json_datas[1]}`]);
                        secondly = Number(b[`${json_datas[0]}`][`${json_datas[1]}`]);
                } 
    
                return secondly - firstly
            }).length; index++) {
                const data = response.Data[index];

                let sira = "";


                if(index == 0) {
                    sira = `<i class="ti ti-medal-2 text-danger"></i>`
                    top_one.src = `${data.guild.iconURL}`
                }

                if(index == 1) {
                    sira = `<i class="ti ti-medal text-warning"></i>`
                    top_two.src = `${data.guild.iconURL}`
                }
                
                if(index == 2) {
                    sira = `<i class="ti ti-ribbon-health text-success"></i>`
                    top_three.src = `${data.guild.iconURL}`
                }

                if(index == 3) {
                    top_four.src = `${data.guild.iconURL}`
                }

                if(!sira) sira = index + 1 

                if(highlight && data.guild.isHighlighted) {
                    highlight_text += `
                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                    
                           <div class="creator-single creator-single-short creator-single-filled mb-30">
                              <div class="creator-wraper">
                                 <div class="creator-inner">
                                    <div class="creator-content pos-rel creator-short-content">
                                                <div class="art-item-single art-item-single-rank">
                        
                                                <div class="art-item-wraper">
                                                <div class="art-item-inner">
                                                <div class="art-item-img pos-rel">
                                  
                                                 <a href="/guild/${data.guild.guildId}"><img loading="lazy" src="${data.guild.iconURL}" alt="${data.guild.name}"></a>
                                             
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                       <div class="creator-info">
                                          <div class="">
                                             <h4 class="artist-name pos-rel" style="font-size: 18px">
                                                ${data.guild.name} ${data.guild.isVerifed ? ` <span class="profile-verification verified">
                                                <i class="fas fa-check"></i>
                                            </span>` : ""}
                                          
                                             </h4>
                                           
                                             <div class="artist-id"><a  href="https://${data.guild.vanity_url ? `discord.gg/${data.guild.vanity_url}` : ""}" >Sende katıl!</a></div>
                                                
                                             <div class="artist-meta-item" style="gap: 10px; display: flex; margin-top: 10px">
                                                        <div class="artist-created">${data.all_voice} <i class="ti ti-microphone"></i></div>
                                                        <div class="artist-created">${NumberToCountString(data.guild.memberCount)} <i class="ti ti-users"></i></div>
                                                        <div class="artist-created">${NumberToCountString(data.guild.rawVotes)} <i class="ti ti-square-rounded-check"></i></div>
                                          
                                                    </div>
                                             </div>
                                          </div>
                                  
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                    
                    `
                }


                leaderboard_text += `
            <div class="rank-list-row align-items-center">
            <div class="rank-list-cell rank-list-cell-assets">
                    <div class="art-item-single art-item-single-rank">
               
                    <div class="art-item-wraper">
                    <div class="art-item-inner">
                    <div class="art-item-img pos-rel">
                  
                    <a href="/guild/${data.guild.guildId}"><img loading="lazy" src="${data.guild.iconURL}" onerror="not_loaded_icon_url(this)" alt="${data.guild.name}"></a>
                                 ${data.guild.isVerifed ? `<div class="profile-verification verified" tabindex="0" data-toggle="tooltip" title="Onaylanmış Sunucu" style="margin-bottom: 5px">
                                                                <i class="fas fa-check"></i>
                                                            </div>` : ``}
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="rank-list-cell rank-list-cell-owner">${data.guild.name}</div>
                 <!-- Ses -->
                <div class="rank-list-cell rank-list-cell-hours rank-list-cell-volume">${data.all_voice} <i class="ti ti-microphone"></i></div>
                 <!-- Kamera -->
                <div class="rank-list-cell rank-list-cell-volume">${data.on_camera} <i class="ti ti-camera"></i></div>
                 <!-- Yayın -->
                <div class="rank-list-cell rank-list-cell-volume">${data.on_stream} <i class="ti ti-screen-share"></i></div>
                 <!-- Mic Kapalı -->
                <div class="rank-list-cell rank-list-cell-volume">${data.mute_voice} <i class="ti ti-microphone-off"></i></div>
                 <!-- Kulaklık Kapalı -->
                <div class="rank-list-cell rank-list-cell-volume">${data.deaf_voice} <i class="ti ti-headphones-off"></i></div>
                 <!-- Bot -->
                <div class="rank-list-cell rank-list-cell-volume">${data.bot_voice}  <i class="ti ti-robot"></i></div>
                 <!-- AFK -->
                <div class="rank-list-cell rank-list-cell-volume">${data.deaf_voice} <i class="ti ti-zzz"></i></div>
                 <!-- Total -->
                <div class="rank-list-cell rank-list-cell-price">${NumberToCountString(data.guild.memberCount)} <i class="ti ti-users"></i></div>
                 <!-- Oy -->
                <div class="rank-list-cell rank-list-cell-hours  rank-list-cell-volume">${NumberToCountString(data.guild.rawVotes)} <i class="ti ti-square-rounded-check"></i></div>  
        </div> 
                ${index == 2 ? `</br>` : ""}
                
        `

            }


             highlight.innerHTML = highlight_text;
             doc.innerHTML = leaderboard_text;
          
        } else {
            
        }
        
    };
    
    xhr.send();
}



/**
 * ! 1000 i 1.0k olarak çıkartır 
 * @param {Number} numara 
 * @returns {String}
 */
function NumberToCountString(numara) {

    if (numara >= 1e12) {
        return (numara / 1e12).toFixed(1) + "Kt"
    } else if (numara >= 1e9) {
        return (numara / 1e9).toFixed(1) + "T"
    } else if (numara >= 1e6) {
    
        return (numara / 1e6).toFixed(1) + "M"
    } else if (numara >= 1e3) {
        return (numara / 1e3).toFixed(1) + "K";
    }
    return numara
}

function not_loaded_icon_url(img) {
    img.src = "https://cdn.discordapp.com/embed/avatars/2.png";
 }